using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;
using Foundation;


namespace AppTypes {
    /// <summary>
    /// Uses an instance of ArrayList to handle its elements.
    /// </summary>
    [DeveloperInfoAttribute("Temitope Oluwole", Date = "04apr08", Title = "AppTypes.Suppliers Class")]
    [CustomDescriptionAttribute("Uses an instance of ArrayList to handle its elements")]
    [Serializable]
    class Suppliers: ICustomCollection, IEnumerable{ 

        #region Fields

        private ArrayList suppliersCollection; 
        private const string typeMismatch = "Type mistmatch!";
        
        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public Suppliers() {

            suppliersCollection = new ArrayList();
        }

        /// <summary>
        /// Default CreateSupplier constructor
        /// </summary>
        /// <returns>An instance of <see cref="AppTypes.Supplier"/></returns>
        public static Supplier CreateSupplier() {
            return new Supplier();
        }

        /// <summary>
        /// Full parameters override CreateSupplier constructor.
        /// </summary>
        /// <param name="ID">Passed ID</param>
        /// <param name="CompanyName">Passed CompanyName</param>
        /// <param name="ContactName">Passed CompanyTitle</param>
        /// <param name="ContactTitle">Passed ContactTitle</param>
        /// <param name="Address">Passed Address</param>
        /// <param name="City">Passed City</param>
        /// <param name="Region">Passed Region</param>
        /// <param name="PostalCode">Passed PostalCode</param>
        /// <param name="Country">Passed Country</param>
        /// <param name="Phone">Passed Phone</param>
        /// <param name="Fax">Passed Fax</param>
        /// <param name="HomePage">Pased HomePage</param>
        /// <param name="Type">Passed Type</param>
        public static Supplier CreateSupplier(int ID, string CompanyName, string ContactName, string ContactTitle,
            string Address, string City, string Region, string PostalCode, string Country,
            string Phone, string Fax, string HomePage, SupplierTypes Type) {

            return new Supplier(ID, CompanyName, ContactName, ContactTitle, Address, City,
                Region, PostalCode, Country, Phone, Fax, HomePage, Type);

        } 
        #endregion

        #region ICustomCollection Members

        /// <summary>
        /// Returns the number of elements currently in the collection.
        /// </summary>
        public int Count {
            get { return suppliersCollection.Count; }
        }

        /// <summary>
        /// Adds an object to the Collection and returns the int value
        /// of the collection index for the object just added.
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>An instance of<see cref="System.Int32"/></returns>
        public int Add(object value) {
            if (value is Supplier) {
                if (suppliersCollection.Contains(value))
                    throw new AppTypesException("Supplier is already in collection.");
                else {
                    suppliersCollection.Add(value);
                    return suppliersCollection.IndexOf(value);
                }	 
	        } else throw new ArgumentException(typeMismatch);
        }

        /// <summary>
        /// Removes all objects from the Collection.
        /// </summary>
        public void Clear() {
            suppliersCollection.Clear();
        }

        /// <summary>
        /// Determines whether the collection contains a specific object.
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        public bool Contains(object value) {
            if (value is Supplier) {
                if (suppliersCollection.Contains(value))
                    throw new AppTypesException("Supplier is already in collection.");
                else {
                    return suppliersCollection.Contains(value);
                }
            } else throw new ArgumentException(typeMismatch);
        }

        /// <summary>
        /// Determines the index of a specific object in the collection.
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>An instance of<see cref="System.Int32"/></returns>
        public int IndexOf(object value) {
            if (value is Supplier) {
                return suppliersCollection.IndexOf(value);
                }
            else throw new ArgumentException(typeMismatch);
        }

        /// <summary>
        /// Inserts an object into the collection at the specified index.
        /// </summary>
        /// <param name="index">index</param>
        /// <param name="value">value</param>
        public void Insert(int index, object value) {
            if (value is Supplier) {
                if (suppliersCollection.Contains(value))
                    throw new AppTypesException("Supplier is already in collection.");
                else {
                    suppliersCollection.Insert(index, value);
                }	 
	        } else throw new ArgumentException(typeMismatch);
        }

        /// <summary>
        /// Removes the first occurence of the specified object from the collection.
        /// </summary>
        /// <param name="value">value</param>
        public void Remove(object value) {
            suppliersCollection.Remove(value);
        }

        /// <summary>
        /// Removes object at specified index.
        /// </summary>
        /// <param name="index">index</param>
        public void RemoveAt(int index) {
            suppliersCollection.RemoveAt(index);
        }

        /// <summary>
        /// Copies item of the collection into an array.
        /// </summary>
        /// <param name="array">array</param>
        public void CopyTo(object[] array) {
            suppliersCollection.CopyTo(array);
        }

        /// <summary>
        /// Sorts the collection using the IComparable interface of each member
        /// of the collection.
        /// </summary>
        public void Sort() {
            suppliersCollection.Sort();
        }

        /// <summary>
        /// Sorts the collection based on the supplied IComparer.
        /// </summary>
        /// <param name="myComparer">IComparer object supplied</param>
        public void Sort(IComparer myComparer) {
            suppliersCollection.Sort(myComparer);
        }

     

        #endregion


        #region Other Properties

        /// <summary>
        /// "this" property
        /// </summary>
        /// <param name="i">index</param>
        /// <returns></returns>
        public object this[int i] {
            get {
                return suppliersCollection[i];
            }
            set {
                suppliersCollection[i] = value;
            }
        } 

        #endregion

        #region Other Methods

        /// <summary>
        /// Serializes the supplied Suppliers instance to the supplied Stream
        /// utilizing a Simple Object Access Protocol (SOAP) formatter.
        /// </summary>
        /// <param name="aSuppliers">aSuppliers</param>
        /// <param name="sToStream">sToStream</param>
        public static void Serialize(Suppliers aSuppliers, System.IO.Stream sToStream) {
        
            IFormatter objFormatterToStream = new SoapFormatter();
            
            objFormatterToStream.Serialize(sToStream, aSuppliers);
            
            sToStream.Close();

        }

        /// <summary>
        /// Deserializes the content of the stream to a new instance of
        /// type Suppliers.
        /// </summary>
        /// <param name="sFromStream"></param>
        /// <returns></returns>
        public static Suppliers Deserialize(System.IO.Stream sFromStream){
        
            IFormatter objFormatterFromStream = new SoapFormatter();
            
            Suppliers aSuppliers = (Suppliers)objFormatterFromStream.Deserialize(sFromStream);
            
            sFromStream.Close();

            return aSuppliers;
            
        }


        #endregion
        
        #region IComparable Members

        public int CompareTo(object obj) {
            if (obj == null) {
                throw new ArgumentNullException ("obj", "Object against which comparison is to be made must be non-null.");
            } else if (!(obj is ArrayList)) {
                throw new ArgumentException("Object against which comparison is to be made must be of type Supplier.",
                    "obj");
            } else return this.CompareTo((ArrayList)obj);
        }

        #endregion

        #region IEnumerable Members
        /// <summary>
        /// Implementation of the IEnumerable interface.
        /// </summary>
        /// <returns>An instance of <see cref="System.Collections.IEnumerator"/></returns>
        public IEnumerator GetEnumerator() {
            
            // Creates instance of private inner class.
            return new SuppliersEnumerator(suppliersCollection);
        }

        /// <summary>
        /// Interates through the collection in reverse
        /// </summary>
        /// <returns></returns>
        public IEnumerable GetReverseEnumerator() {
            
            for (int i = suppliersCollection.Count; i >=0; i--)
            {yield return suppliersCollection[i];}
        }

        /// <summary>
        /// Provides for iterating throught the Suppliers in the collection and
        /// returns only Supplier instances of the matching SupplierType
        /// </summary>
        /// <param name="aSupplierType"></param>
        /// <returns>An instance of<see cref="System.Collections.IEnumerator"/></returns>
        public IEnumerable GetTypeEnumerator(SupplierTypes aSupplierType) {
            foreach (Supplier aSupplier in suppliersCollection) {
                if (aSupplier.Type== aSupplierType) {
                    yield return aSupplier;
                }
            }
        }
        #endregion

        /// <summary>
        /// Private inner class to allow any client enumeration capability
        /// over the Suppliers class private ArrayList collection variable.
        /// </summary>
        private class SuppliersEnumerator : IEnumerator {

            private ArrayList suppliers;
            private int currentIndex=-1;

            /// <summary>
            /// Non-default constuctor.
            /// </summary>
            /// <param name="mySuppliers">mySuppliers</param>
            public SuppliersEnumerator(ArrayList mySuppliers) {
                suppliers = mySuppliers;
            }

            #region IEnumerator Members

            /// <summary>
            /// Returns the current supplier in the ArrayList.
            /// </summary>
            public object Current {
                get { return currentIndex; }
            }

            /// <summary>
            /// Moves to next supplier in the ArrayList.
            /// </summary>
            /// <returns>An instance of<see cref="System.Boolean"/></returns>
            public bool MoveNext() {
              
                if (currentIndex < suppliers.Count) {
                    currentIndex++;
                } return currentIndex < suppliers.Count;
            }

            /// <summary>
            /// Reest current position of index.
            /// </summary>
            public void Reset() {
                currentIndex = -1;
            }

            #endregion


        }
    }
}
