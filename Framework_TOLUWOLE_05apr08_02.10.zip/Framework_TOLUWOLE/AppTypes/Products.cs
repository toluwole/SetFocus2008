using System;
using System.Collections.Generic;
using System.Text;

namespace AppTypes {
    /// <summary>
    /// The Products class will be provided to manage a collection of
    /// Product instances.
    /// </summary>
    [DeveloperInfoAttribute("Temitope Oluwole", Date = "05apr08", Title = "AppTypes.Products Class")]
    [CustomDescriptionAttribute("The Products class will be provided to manage a collection of" +
       "Product instances.")]
    [Serializable]
    class Products: IList<Product> {
        
        #region Fields

        /// <summary>
        /// Field declaration.
        /// </summary>
        protected List<Product> productsCollection;
        
        #endregion

        #region Constructor

        public Products() {
            productsCollection = new List<Product>();
        }
        
        #endregion

        #region Event and Event Method

        /// <summary>
        /// CollectionModified event declared using delegate
        /// type CollectionModifiedHandler.
        /// </summary>
        public static event CollectionModifiedHandler CollectionModified;

        /// <summary>
        /// Event-raising method
        /// </summary>
        /// <param name="mEventArgs">ModificationEventArgs</param>
        public void OnCollectionModified(ModificationEventArgs mEventArgs) {
            if (CollectionModified != null) {
                CollectionModified(this, mEventArgs);
            }
        } 

        #endregion

        #region Other Methods

        /// <summary>
        /// Default sort.
        /// </summary>
        public void Sort() {
            productsCollection.Sort();
        }

        /// <summary>
        /// Sorts the collection based on the supplied IComparer.
        /// </summary>
        /// <param name="myComparer">IComparer object supplied</param>
        public void Sort(IComparer<Product> myComparer) {
            productsCollection.Sort(myComparer);
        }

        /// <summary>
        /// Default CreateProduct constructor.
        /// </summary>
        /// <returns>An instance of <see cref="AppTypes.Product"/></returns>
        public static Product CreateProduct() {
            return new Product();
        }

        /// <summary>
        /// Full override CreateProduct constructor.
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="ProductName">ProductName</param>
        /// <param name="SupplierID">SupplierID</param>
        /// <param name="CategoryID">CategoryID</param>
        /// <param name="QuantityPerUnit">QuantityPerUnit</param>
        /// <param name="UnitPrice">UnitPrice</param>
        /// <param name="UnitsInStock">UnitsInStock</param>
        /// <param name="UnitsOnOrder">UnitsOnOrder</param>
        /// <param name="ReOrderLevel">ReOrderLevel</param>
        /// <returns>An instance of <see cref="AppTypes.Product"/></returns>
        public static Product CreateProduct(int ID, string ProductName, int SupplierID,
            int CategoryID, string QuantityPerUnit, decimal UnitPrice,
            int UnitsInStock, int UnitsOnOrder, int ReOrderLevel) {

            return new Product(ID, ProductName, SupplierID, CategoryID, QuantityPerUnit,
                UnitPrice, UnitsInStock, UnitsOnOrder, ReOrderLevel);
        
        }

        #endregion

        #region IList<Product> Members

        /// <summary>
        /// Determines the index of a specific object in the collection.
        /// </summary>
        /// <param name="item">Product item</param>
        /// <returns>An instance of <see cref="System.Int32"/></returns>
        public int IndexOf(Product item) {
            return productsCollection.IndexOf(item);
        }

        /// <summary>
        /// Inserts an object into the collection at the specified index.
        /// </summary>
        /// <param name="index">index</param>
        /// <param name="item">Product item</param>
        public void Insert(int index, Product item) {
            if (productsCollection.Contains(item)) 
                throw new AppTypesException("Product is already in collection.");
            else {
                productsCollection.Insert(index, item);
            }
        }

        /// <summary>
        /// Removes object at specified index.
        /// </summary>
        /// <param name="index">index</param>
        public void RemoveAt(int index) {
            productsCollection.RemoveAt(index);
        }

        /// <summary>
        /// this property.
        /// </summary>
        /// <param name="index"></param>
        /// <returns>An instance of <see cref="System.Object"/></returns>
        public Product this[int index] {
            get {
                return productsCollection[index];
            }
            set {
                productsCollection[index]=value;
            }
        }

        #endregion

        #region ICollection<Product> Members

        /// <summary>
        /// Adds an object to the Collection. 
        /// </summary>
        /// <param name="item">Product item</param>
        public void Add(Product item) {
            if (productsCollection.Contains(item))
                throw new AppTypesException("Product is already in collection.");            
            else{
                productsCollection.Add(item);
            }
        }

        /// <summary>
        /// Removes all objects from the Collection.
        /// </summary>
        public void Clear() {
            productsCollection.Clear();
        }

        /// <summary>
        /// Determines whether the collection contains a specific object.
        /// </summary>
        /// <param name="item">Product item</param>
        /// <returns>An instance of <see cref="System.Boolean"/></returns>
        public bool Contains(Product item) {
            if (productsCollection.Contains(item)) 
                throw new AppTypesException("Product is already in collection.");            
            else{
                return productsCollection.Contains(item);
            }
        }

        /// <summary>
        /// Copies item of the collection into an array.
        /// </summary>
        /// <param name="array">array</param>
        /// <param name="arrayIndex">array index.</param>
        public void CopyTo(Product[] array, int arrayIndex) {
            productsCollection.CopyTo(array, arrayIndex);
        }

        /// <summary>
        /// Returns the number of elements currently in the collection.
        /// </summary>
        public int Count {
            get { return productsCollection.Count; }
        }

        /// <summary>
        /// IsReadyOnly property.
        /// </summary>
        public bool IsReadOnly {
            get { return false; }
        }

        /// <summary>
        /// Removes an item from the collection.
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool Remove(Product item) {
            return productsCollection.Remove(item);
        }

        #endregion

        #region IEnumerable<Product> Members

        /// <summary>
        /// IEnumerator_Product GetEnumerator implementation.
        /// </summary>
        /// <returns></returns>
        public IEnumerator<Product> GetEnumerator() {
            foreach (Product aProduct in productsCollection) {
                yield return aProduct;
            }
        }

        #endregion

        #region IEnumerable Members

        /// <summary>
        /// IEnumerator GetEnumerator implementation.
        /// </summary>
        /// <returns></returns>
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() {
            for (int i = 0; i < productsCollection.Count; i++) {
                yield return productsCollection[i];
            }
        }

        #endregion
    }
}
