using System;
using System.Collections.Generic;
using System.Text;

namespace AppTypes {
    /// <summary>
    /// Custom description attribute to document classes.
    /// </summary>
    [AttributeUsage(AttributeTargets.All, AllowMultiple=false)]
    class CustomDescriptionAttribute: Attribute {

        #region Fields

        /// <summary>
        /// Required positional field.
        /// </summary>
        private string description;

        #endregion

        #region Properties

        /// <summary>
        /// Required positional property
        /// </summary>
        public string Description {
            get { return description; }
            set { description = value; }
        }   

        #endregion

        #region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Description">Description</param>
        public CustomDescriptionAttribute(string Description) {
            this.Description = Description;
        }

        #endregion
    }
}
