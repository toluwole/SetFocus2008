using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Services.Protocols;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//using TO.LibraryBusiness;
//using TO.LibraryEntities;
using System.Drawing;
using System.Text;
using System.IO;
using LibraryWR;

public partial class EnrollMemberForm : System.Web.UI.Page {

    #region MyEvents

    /// <summary>
    /// Event triggered when the page is loaded
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Event data</param>
    protected void Page_Load(object sender, EventArgs e) {

        try {
            // create a Dataset containing the data from the States.xml file
            //DataSet ds = StatesData.GetStates();

            DataSet ds = new DataSet();
          
            string filepath = System.IO.Path.GetDirectoryName(Server.MapPath(Request.Path))+
                @"..\..\TOLibraryPhase4\";

            // read xml into dataset
            ds.ReadXml(filepath + "States.xml", XmlReadMode.InferSchema);

            // connects datasource to the first table in dataset
            this.dropdownlistState.DataSource = ds.Tables["state"];

            // Displays the states' Abbreviations...
            this.dropdownlistState.DataTextField = "Abbreviation";

            // ... and also use the states' Abbreviations as the value member of the ComboBox
            this.dropdownlistState.DataValueField = "Abbreviation";

            // bind the ds to the dropdownlist
            this.dropdownlistState.DataBind();

            // Hides Juvenile Member objects on page load.
            textboxMemberID2.Visible = false;
            labelMemberID2.Visible = false;
            labelJuvenileMember.Visible = false;
            textboxDateOfBirth.Visible = false;
            labelDateOfBirth.Visible = false;


        } catch (FileNotFoundException fne) {

            this.labelMemberAlert2.Text = "message board:\n " + fne.Message;
            // Brightens the text color.
            this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
        } catch (HttpException httpe) {

            this.labelMemberAlert2.Text = "message board:\n " + httpe.Message;
            // Brightens the text color.
            this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
        }

    }


    /// <summary>
    /// Event for when Enroll Member button is clicked.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Event info.</param>
    protected void buttonEnrollMember_Click(object sender, EventArgs e) {
        if (reqfldValidatorStreet.IsValid==true) {

            try {
                // Creates the object that provides data.
                //LibraryBusinessLayer lbl = new LibraryBusinessLayer();

                // Creates instance of proxy object.
                LibraryWR.Service myLibraryService = new LibraryWR.Service();

                if (checkboxJuvenileMember.Checked == true) {

                    // Casts text of MemberID to short
                    short validAdultMemberID = Convert.ToInt16(this.textboxMemberID2.Text);

                    DateTime validDateOfBirth = Convert.ToDateTime(this.textboxDateOfBirth.Text);

                    // Adds Juvenile Member.
                    JuvenileMember enrolledJuvenile = myLibraryService.wsAddJuvenileMember(
                       validAdultMemberID,
                       this.textboxFirstName2.Text,
                       this.textboxLastName2.Text,
                       this.textboxMiddleInit2.Text,
                       validDateOfBirth);

                    //LibraryEntities.JuvenileMember enrolledJuvenile = lbl.AddJuvenileMember(
                        //validAdultMemberID,
                        //this.textboxFirstName2.Text,
                        //this.textboxLastName2.Text,
                        //this.textboxMiddleInit2.Text,
                        //validDateOfBirth);

           

                    // Displays added member's Member ID.
                    DisplayInMessageBoard(this.textboxFirstName2.Text +
                        " " + this.textboxLastName2.Text + "'s Member ID is " +
                        enrolledJuvenile.memberid);

                } else {

                    // Adds Adult Member.
                    AdultMember enrolledAdult = myLibraryService.wsAddAdultMember(
                        this.textboxFirstName2.Text,
                        this.textboxLastName2.Text,
                        this.textboxMiddleInit2.Text,
                        this.textboxStreet2.Text,
                        this.textboxCity2.Text,
                        this.dropdownlistState.Text,
                        this.textboxZipCode2.Text,
                        this.textboxPhone2.Text);

                    //LibraryEntities.AdultMember enrolledAdult = lbl.AddAdultMember(
                    //    this.textboxFirstName2.Text,
                    //    this.textboxLastName2.Text,
                    //    this.textboxMiddleInit2.Text,
                    //    this.textboxStreet2.Text,
                    //    this.textboxCity2.Text,
                    //    this.dropdownlistState.Text,
                    //    this.textboxZipCode2.Text,
                    //    this.textboxPhone2.Text);

                    // Displays added member's Member ID.
                    DisplayInMessageBoard(this.textboxFirstName2.Text +
                        " " + this.textboxLastName2.Text + "'s Member ID is " +
                        enrolledAdult.memberid);
                }


            } catch (FormatException fe) {

                DisplayInMessageBoard("\n" + fe.Message);

            } catch (ArgumentOutOfRangeException ae) {

                DisplayInMessageBoard("\n" + ae.Message);

            } catch (SoapException se) {

                DisplayInMessageBoard("\n" + se.Message + " " +
                    se.InnerException.Message + ".");

            } catch (Exception ex) {

                DisplayInMessageBoard("\n" + ex.Message);
            }
        }
    }

    /// <summary>
    /// Validation test for First Name
    /// </summary>
    /// <param name="source">Event causing</param>
    /// <param name="args">Event data</param>
    protected void fnameCustomValidator_ServerValidate(object source, ServerValidateEventArgs args) {

        // Makes sure First Name is entered.
        if (this.textboxFirstName2.Text == "") {

            args.IsValid = false;
    
        } else {

            // Places text of First Name into an array.
            char[] myArrayFirstName = this.textboxFirstName2.Text.ToCharArray();

            // Checks if any part of First Name is not alphabetic.
            for (int i = 0; i < myArrayFirstName.Length; i++) {
                if (!Char.IsLetter(myArrayFirstName[i])) {

                    args.IsValid = false;
                }

                // Provides error if first character is not uppercase
                if (this.textboxFirstName2.Text.Substring(0, 1).Equals(
                   this.textboxFirstName2.Text.Substring(0, 1).ToLower())) {

                    args.IsValid = false;
                }
            }

            args.IsValid = true;
        }
    }



    /// <summary>
    /// Validation test for Last Name
    /// </summary>
    /// <param name="source">Event causing object</param>
    /// <param name="args">Event data</param>
    protected void lnameCustomValidator_ServerValidate(object source, ServerValidateEventArgs args) {

        // Makes sure Last Name is entered.  
        if (this.textboxLastName2.Text == "") {
            args.IsValid=false;
            this.labelMemberAlert2.Text ="This is a required field.";
            this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;

        } else {
            
            // Places text of First Name into an array.
            char[] myArrayLastName = this.textboxLastName2.Text.ToCharArray();

            // Checks if any part of First Name is not alphabetic.
            for (int i = 0; i < myArrayLastName.Length; i++) {
                if (!Char.IsLetter(myArrayLastName[i])) {
                    args.IsValid = false;
                    this.labelMemberAlert2.Text =
                        "Last name must be alphabetic, and the first letter upper case.";
                    this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
                }
                // Provides error if first character is not uppercase
                if (this.textboxLastName2.Text.Substring(0, 1).Equals(
                   this.textboxLastName2.Text.Substring(0, 1).ToLower())) {

                    args.IsValid = false;
                    this.labelMemberAlert2.Text ="Last name must be alphabetic, and the first letter upper case.";
                    this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
                }
            }

            args.IsValid = true;
        }
    }

    /// <summary>
    /// Check that if entered, Middle Initial is one character and upper case.
    /// </summary>
    /// <param name="source">Event causing object</param>
    /// <param name="args">Object info.</param>
    protected void minitCustomValidator_ServerValidate(object source, ServerValidateEventArgs args) {
        if (this.textboxMiddleInit2.Text.Length == 1) {
            try {
                if (Char.IsLetter(Convert.ToChar(this.textboxMiddleInit2.Text)) &&
                    this.textboxMiddleInit2.Text.Equals(this.textboxMiddleInit2.Text.ToUpper())) {
                } else {
                    args.IsValid = false;
                    this.textboxMiddleInit2.Text="Middle initial must be alphabetic, and upper case.";
                    this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
                }
            } catch (FormatException) {
                args.IsValid = false;
                this.textboxMiddleInit2.Text="Middle initial must be alphabetic";
                this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
            }
        }
    }

    /// <summary>
    /// Validation test for City entry
    /// </summary>
    /// <param name="source">Event causing object</param>
    /// <param name="args">Event data</param>
    protected void cityCustomValidator_ServerValidate(object source, ServerValidateEventArgs args) {

        if (checkboxJuvenileMember.Checked != true) {
            if (this.textboxCity2.Text == "") {
                args.IsValid=false;
                this.textboxCity2.Text="This is a required field.";
                this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
            } else {

                // Places text of City into an array.
                char[] myArrayCity = this.textboxCity2.Text.ToCharArray();

                // Checks if any part of City is not alphabetic.
                for (int i = 0; i < myArrayCity.Length; i++) {
                    if (!Char.IsLetter(myArrayCity[i])) {
                        args.IsValid = false;
                        this.labelMemberAlert2.Text=
                            "City must be alphabetic, and the first letter upper case.";
                    }
                    // Provides error if first character is not uppercase
                    if (this.textboxCity2.Text.Substring(0, 1).Equals(
                       this.textboxCity2.Text.Substring(0, 1).ToLower())) {

                        args.IsValid = false;
                        this.labelMemberAlert2.Text=
                            "City must be alphabetic, and the first letter upper case.";
                        this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
                    }
                }
                args.IsValid = true;
            }
        }
    }

    /// <summary>
    /// Checks that, Zip Code is in ##### or #####-#### format.
    /// </summary>
    /// <param name="source">Event causing object</param>
    /// <param name="args">Event info.</param>
    protected void zipCustomValidator_ServerValidate(object source, ServerValidateEventArgs args) {

        // Validates only if Adult member is being added.
        if (checkboxJuvenileMember.Checked != true) {
            try {
                // Checks the text formatting
                Convert.ToInt32(this.textboxZipCode2.Text.Substring(0, 5));
                if ((this.textboxZipCode2.Text.Substring(0, 5)) == (this.textboxZipCode2.Text.Trim())) {
                } else if (this.textboxZipCode2.Text.Substring(5, 1) == "-") {
                    Convert.ToInt16(this.textboxZipCode2.Text.Substring(6, 4));
                }
                args.IsValid = true;
            } catch (FormatException) {
                args.IsValid = false;
                this.labelMemberAlert2.Text=
                    "Zip Code must be in ##### or #####-#### format, where # is a digit from " +
                    "0 through 9";
                this.labelZipCode2.ForeColor = SystemColors.ActiveCaption;
            } catch (ArgumentOutOfRangeException) {
                args.IsValid = false;
                this.labelMemberAlert2.Text=
                    "Zip Code must be in ##### or #####-#### format, where # is a digit from " +
                    "0 through 9";
                this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
            }
        }
                    
    }

    /// <summary>
    /// Checks that if entered, Telephone is in (###)###-#### format.
    /// </summary>
    /// <param name="source">Event causing object</param>
    /// <param name="args">Event data</param>
    protected void phoneCustomValidator_ServerValidate(object source, ServerValidateEventArgs args) {

        // Checks is anything is entered into the field.
        if (this.textboxPhone2.Text.Length >= 1) {
            try {
                // Checks the text formatting.
                if ((this.textboxPhone2.Text.Substring(0, 1) == "(") &&
                    (this.textboxPhone2.Text.Substring(4, 1) == ")") &&
                    (this.textboxPhone2.Text.Substring(8, 1) == "-")) {
                    try {
                        Convert.ToInt16(this.textboxPhone2.Text.Substring(1, 3));
                        Convert.ToInt16(this.textboxPhone2.Text.Substring(5, 3));
                        Convert.ToInt16(this.textboxPhone2.Text.Substring(9, 4));
                        args.IsValid = true;
                    } catch (FormatException) {
                        args.IsValid = false;
                        this.labelMemberAlert2.Text =
                            "Phone number must be in (###)###-#### format, where # is a digit from " +
                            "0 through 9";
                        this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
                    } catch (ArgumentOutOfRangeException) {
                        args.IsValid = false;
                        this.labelMemberAlert2.Text=
                            "Phone number must be in (###)###-#### format, where # is a digit from " +
                            "0 through 9";
                        this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
                    }
                } else {
                    args.IsValid = false;
                    this.labelMemberAlert2.Text=
                        "Phone number must be in (###)###-#### format, where # is a digit from " +
                        "0 through 9";
                    this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
                }
            } catch (ArgumentOutOfRangeException) {
                args.IsValid = false;
                this.labelMemberAlert2.Text=
                    "Phone number must be in (###)###-#### format, where # is a digit from " +
                    "0 through 9";
                this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
            }

        }
    }

    /// <summary>
    /// Checks that, Juvenile Date of Birth is in MM/DD/YYYY format,
    /// and no more than eighteen years prior to the current date.
    /// </summary>
    /// <param name="source">Event causing object</param>
    /// <param name="args">Event data</param>
    protected void dateobCustomValidator_ServerValidate(object source, ServerValidateEventArgs args) {

        // Validates only if Juvenile member is being added.
        if (this.checkboxJuvenileMember.Checked == true) {
            try {
                // Check that date entered is in the correct format.
                DateTime myJuvenileDOB = Convert.ToDateTime(this.textboxDateOfBirth.Text);

                // Checks that date length reflects MM/DD/YYYY versus other (e.g. M/D/YY)
                if (this.textboxDateOfBirth.Text.Length == 10) {
                    // Checks that date entered no more than eighteen years
                    // prior to the current date.
                    if (myJuvenileDOB.AddYears(18) > DateTime.Today) {
                        args.IsValid = true;
                    } else {
                        args.IsValid = false;
                        this.labelMemberAlert2.Text=
                            "Member is over 18 years of age, and cannot be a juvenile member";
                        this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
                    }
                } else {
                    args.IsValid = false;
                    this.labelMemberAlert2.Text=
                        "Date must be in in MM/DD/YYYY format";
                    this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
                }

            } catch (FormatException) {
                args.IsValid = false;
                this.labelMemberAlert2.Text=
                    "Date must be in in MM/DD/YYYY format";
                this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
            } catch (InvalidCastException) {
                args.IsValid = false;
                this.labelMemberAlert2.Text=
                    "Date must be in in MM/DD/YYYY format";
                this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
            }
        } else {
            args.IsValid = false;
            this.labelMemberAlert2.Text=
                "Date must be in in MM/DD/YYYY format";
            this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
        }
    }

    /// <summary>
    /// Event handler for the Juvenile member checkbox
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Event info</param>
    protected void checkboxJuvenileMember_CheckedChanged(object sender, EventArgs e) {

         // Determines state of check box.
            if (checkboxJuvenileMember.Checked) {

                // Hides non-required and non-option fields.
                textboxExpiryDate2.Visible = false;
                labelExpiryDate2.Visible = false;
                textboxStreet2.Visible = false;
                labelStreet2.Visible = false;
                reqfldValidatorStreet.Enabled = false;
                reqfldValidatorStreet.Enabled = false;
                textboxCity2.Visible = false;
                labelCity2.Visible = false;
                reqfldValidatorCity.Enabled = false;
                regexpValidatorCity.Enabled = false;
                dropdownlistState.Visible = false;
                labelState2.Visible = false;
                textboxZipCode2.Visible = false;
                labelZipCode2.Visible = false;
                reqfldValidatorZipCode.Enabled = false;
                regexpValidatorZipCode.Enabled = false;
                textboxPhone2.Visible = false;
                labelPhone2.Visible = false;
                
                regexpValidatorPhone.Enabled = false;

                // Shows required and optional fields.
                textboxMemberID2.Visible = true;
                rangevalidatorMemberID2.Enabled = true;
                reqfldvalidatorMemberID2.Enabled = true;                
                labelMemberID2.Visible = true;
                labelJuvenileMember.Visible = true;
                textboxDateOfBirth.Visible = true;
                labelDateOfBirth.Visible = true;
                reqfieldValidatorDOB.Enabled = true;
                regexpValidatorDOB.Enabled = true;
                
            } else {

                // Hides non-required and non-option fields.
                textboxMemberID2.Visible = false;
                rangevalidatorMemberID2.Enabled = false;
                reqfldvalidatorMemberID2.Enabled = false;
                reqfldValidatorStreet.Enabled = false;
                labelMemberID2.Visible = false;
                labelJuvenileMember.Visible = false;
                textboxDateOfBirth.Visible = false;
                labelDateOfBirth.Visible = false;
                reqfieldValidatorDOB.Enabled = false;
                regexpValidatorDOB.Enabled = false;

                // Shows required and optional fields.
                textboxExpiryDate2.Visible = true;
                labelExpiryDate2.Visible = true;
                textboxStreet2.Visible = true;
                labelStreet2.Visible = true;
                reqfldValidatorStreet.Enabled = true;
                regexpValidatorStreet.Enabled = true;
                textboxCity2.Visible = true;
                labelCity2.Visible = true;
                regexpValidatorCity.Enabled = true;
                reqfldValidatorCity.Enabled = true;
                dropdownlistState.Visible = true;
                labelState2.Visible = true;
                textboxZipCode2.Visible = true;
                labelZipCode2.Visible = true;
                reqfldValidatorZipCode.Enabled = true;
                regexpValidatorZipCode.Enabled = true;
                textboxPhone2.Visible = true;
                labelPhone2.Visible = true;
                regexpValidatorPhone.Enabled = true;

            }

    }

    #endregion

    #region MyMethods

    /// <summary>
    /// Changes the Enroll Member form's messageboard label text.
    /// </summary>
    /// <param name="myCaption">String representing text to change.</param>
    private void DisplayInMessageBoard(string myCaption) {
        this.labelMemberAlert2.Text = "message board:\n " + myCaption;
        // Brightens the text color.
        this.labelMemberAlert2.ForeColor = SystemColors.ActiveCaption;
    }


    #endregion


}
