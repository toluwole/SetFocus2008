using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TO.LibraryBusiness;
using TO.LibraryEntities;
//using SetFocus.Library.Entities;


namespace TO.LibraryWinClient {
    /// <summary>
    /// Class used to build ViewMemberForm.
    /// </summary>
    public partial class ViewMemberForm : Form {
        /// <summary>
        /// View Member form.
        /// </summary>
        public ViewMemberForm() {
            InitializeComponent();
        }


        #region MyEvents

        /// <summary>
        /// Event handler for when View Member button is clicked.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void buttonViewMemberInfo_Click(object sender, EventArgs e) {

            // Validates all controls on the View Member form
            if (!this.ValidateChildren(ValidationConstraints.Visible)) {

                // Keeps View Member form open if controls do not validate.
                this.DialogResult = DialogResult.None;

            } else {

                // Casts text of MemberID to short
                short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

                // Creates the object that provides data.
                LibraryBusinessLayer lbl = new LibraryBusinessLayer();

                try {
                    // Gets member data.
                    TO.LibraryEntities.LibraryEntities.Member foundMember = lbl.GetInformation(validMemberID);

                    // Populates View Member form with property values.
                    this.textboxExpiryDate.Text = foundMember.ExpirationDate.ToString("d");
                    this.textboxFirstName.Text = foundMember.FirstName;
                    this.textboxMiddleInit.Text = foundMember.MiddleInitial;
                    this.textboxLastName.Text = foundMember.LastName;
                    this.textboxStreet.Text = foundMember.Street;
                    this.textboxCity.Text = foundMember.City;
                    this.textboxState.Text = foundMember.State;
                    this.textboxZipCode.Text = foundMember.ZipCode;
                    this.textboxPhone.Text = foundMember.PhoneNumber;

                    // Enables Check Out Item button if Disabled.
                    if (this.buttonCheckOutItem.Enabled == false) {
                        this.buttonCheckOutItem.Enabled = true;
                    }

                    // Hides Check Out Item text box objects if visible.
                    if (this.textboxISBN.Visible == true) {

                        this.textboxISBN.Visible = false;
                        this.textboxCopyNumber.Visible = false;
                    }

                    // Alerts user if Member card is expired highlighting expired date.
                    if (foundMember.ExpirationDate <= DateTime.Now) {
                        this.labelMemberAlert.Text = "message board:\n\n " + this.textboxFirstName.Text + " " +
                        this.textboxLastName.Text + "'s card has expired.";
                        this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;
                        this.textboxExpiryDate.ReadOnly = false;
                        this.textboxExpiryDate.BackColor = SystemColors.InactiveCaptionText;
                        this.textboxExpiryDate.ReadOnly = true;

                        // Enables Check Out Item button.
                        this.buttonCheckOutItem.Enabled = true;

                    } else {
                        this.labelMemberAlert.Text = "message board";
                        this.labelMemberAlert.ForeColor = SystemColors.ButtonShadow;
                        this.textboxExpiryDate.ReadOnly = false;
                        this.textboxExpiryDate.BackColor = SystemColors.Control;
                        this.textboxExpiryDate.ReadOnly = true;

                    }

                    // Gets member's checked out items data
                    ItemsDataSet foundItemsDataSet = lbl.GetViewMemberGrid(validMemberID);

                    // Populates View Member form data grid with items.
                    //this.bindingsourceMemberItems.DataSource = foundItemsDataSet;
                    //I added this.  DJL
                    datagridviewItemsOnLoan.DataSource = foundItemsDataSet.Items;

                    // Bind the data

                    //this.bindingsourceViewMember.DataSource = foundMember;

                    //this.datagridviewItemsOnLoan.DataSource = foundItemsDataSet.Items;

                } catch (FormatException fe) {

                    DisplayInMessageBoard("\n" + fe.Message);

                } catch (ArgumentOutOfRangeException ae) {

                    DisplayInMessageBoard("\n" + ae.Message);

                } catch (LibraryException le) {

                    DisplayInMessageBoard("\n" + le.Message + " " +
                        le.LibraryErrorCode.ToString() + ".");

                } catch (Exception ex) {

                    DisplayInMessageBoard("\n" + ex.Message);
                }
            }
        }

        /// <summary>
        /// Validation test for Member ID.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Data for cancelable event</param>
        private void textboxMemberID_Validating(object sender, CancelEventArgs e) {

            // Attempts to parse Member ID text for valid Member ID number
            // and traps exceptions due to format of entry or if entry is out
            // of range.
            try {
                short.Parse(textboxMemberID.Text);

            } catch (FormatException) {
                e.Cancel = true;
                errorproviderViewMember.SetError(textboxMemberID,
                    "Member ID must be numeric.");

            } catch (OverflowException) {
                e.Cancel = true;
                errorproviderViewMember.SetError(textboxMemberID,
                    "Member ID must be a number from 1 to 32767.");

            }

        }

        /// <summary>
        /// Event handler for valid Member ID entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxMemberID_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderViewMember.SetError((Control)sender, string.Empty);
        }

        private void textboxExpiryDate_Validating(object sender, CancelEventArgs e) {

            // Alerts user if Member card is expired highlighting expired date.
            //try {
            //if (this.textboxExpiryDate.Text == "") {
            //    this.labelMemberAlert.Text = "message board:\n\nEnter Member ID " +
            //       "and click View Member Information button.";
            //    this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;
            //    e.Cancel = true;
            //    errorproviderViewMember.SetError(textboxExpiryDate,
            //    "Enter Member ID and click View Member Information button.");
            //} else {
            //    if (DateTime.Parse(this.textboxExpiryDate.Text) <= DateTime.Now) {
            //        this.labelMemberAlert.Text = "message board:\n\n " + this.textboxFirstName.Text + " " +
            //            this.textboxLastName.Text + "'s card has expired!";
            //        this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;
            //        this.textboxExpiryDate.ReadOnly = false;
            //        this.textboxExpiryDate.BackColor = SystemColors.InactiveCaptionText;
            //        this.textboxExpiryDate.ReadOnly = true;
            //        e.Cancel = true;
            //        errorproviderViewMember.SetError(textboxExpiryDate,
            //        "Member card expired.");
            //    }

            //} catch (FormatException) {
            //    // Prompts user to enter a Member ID and click View Member if 
            //    // the Expiry Date field is invalid.
            //    e.Cancel = true;
            //    // clear out errors on a given control
            //    //errorproviderViewMember.SetError((Control)sender, string.Empty);
            //    // Sets status.
            //    this.labelMemberAlert.Text = "message board:\n\nEnter Member ID " +
            //            "and click View Member Information button_TEST.";
            //    this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;

            //}
        }

        private void textboxExpiryDate_Validated(object sender, EventArgs e) {
            //// clear out errors on a given control
            //errorproviderViewMember.SetError((Control)sender, string.Empty);
            //this.labelMemberAlert.Text = "message board";
            //this.labelMemberAlert.ForeColor = SystemColors.ButtonShadow;
            //this.textboxExpiryDate.ReadOnly = false;
            //this.textboxExpiryDate.BackColor = SystemColors.Control;
            //this.textboxExpiryDate.ReadOnly = true;
        }

        /// <summary>
        /// Event handler for when the View Member form loads.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void ViewMemberForm_Load(object sender, EventArgs e) {

            // Hides Check Out Item text box objects on form load.
            this.textboxISBN.Visible = false;
            this.textboxCopyNumber.Visible = false;



        }

        /// <summary>
        /// Event handler for when the Check Out Item button is clicked.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void buttonCheckOutItem_Click(object sender, EventArgs e) {
            
            // Makes sure the the member ID entered matches the member data
            // in case the user has entered a new Member ID but has not 
            // clicked the View Member Information button to update the form
            buttonViewMemberInfo_Click(sender, e);

            // Re-validates that the member record is valid for item check out.
            buttonCheckOutItem_MouseHover(sender, e);

            
            // Validates all controls on the View Member form
            if (!this.ValidateChildren(ValidationConstraints.Visible)) {

                // Keeps View Member form open if controls do not validate.
                this.DialogResult = DialogResult.None;

            } else {
                try {
                    // Casts text of Member ID to short.
                    short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

                    // Casts text of Copy Number to int.
                    int validISBN = Convert.ToInt32(this.textboxISBN.Text);

                    // Casts text of Copy Number to short.
                    short validCopyNumber = Convert.ToInt16(this.textboxCopyNumber.Text);

                    

                    // Creates the object that provides data.
                    LibraryBusinessLayer lbl = new LibraryBusinessLayer();

                    //// Gets item data.
                    //TO.LibraryEntities.LibraryEntities.Item foundItem = lbl.GetItemInfo(validISBN,validCopyNumber);

                    //// Get item.
                    //StringBuilder myPreCheckOutItem = new StringBuilder ("Item found: ");
                    //myPreCheckOutItem.Append(foundItem.ISBN+",");
                    //myPreCheckOutItem.Append(foundItem.CopyNumber+",");
                    //myPreCheckOutItem.Append(foundItem.Title+",");
                    //myPreCheckOutItem.Append(foundItem.Author);

                    //// Display's item on messageboard.
                    //DisplayInMessageBoard(myPreCheckOutItem.ToString());

                    // Checks to see if user wants to check item out. 
                    // If user says no, operation is cancelled.
                    // If user says yes, checks if book is listed as on-loan
                    // If on-loan, let user check item in first before checking out.
                    // If not on-loan let's user check out.
                    if (MessageBox.Show("Do you still want to check out this item?",
                        "Item Check Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {

                        DisplayInMessageBoard("Attempting to check out item.");

                        try {

                            // Attempts to checkout item.
                            lbl.GetCheckOutItem(validMemberID, validISBN, validCopyNumber);

                            // Refreshes Member information.
                            buttonViewMemberInfo_Click(sender, e);
                                                        
                            DisplayInMessageBoard("Item checked out.");

                        } catch (ArgumentOutOfRangeException ae) {

                            DisplayInMessageBoard(ae.Message);

                        } catch (LibraryException le) {

                            DisplayInMessageBoard(le.Message + " " +
                               le.LibraryErrorCode.ToString() + " by Member " +
                               le.OtherMemberID + ".");

                            if (MessageBox.Show("Would you like to check in this item first?",
                        "Item Check Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {

                                // Attempts to check in item.
                                lbl.SetCheckInItem(validISBN, validCopyNumber);

                                // Attempts to check out item.
                                lbl.GetCheckOutItem(validMemberID, validISBN, validCopyNumber);

                                // Refreshes Member information.
                                buttonViewMemberInfo_Click(sender, e);

                                DisplayInMessageBoard("Item checked in, and then checked out.");

                            } else {
                                DisplayInMessageBoard("Item not checked out.");
                            }
                        } catch (Exception ex) {

                            DisplayInMessageBoard("\n" + ex.Message);
                        }
                         

                    } else {
                        DisplayInMessageBoard("Item not checked out.");
                    }
   

                } catch (FormatException fe) {

                    DisplayInMessageBoard("\n" + fe.Message);
                
                } catch (ArgumentOutOfRangeException ae) {

                    DisplayInMessageBoard(ae.Message);

                } catch (LibraryException le) {

                    DisplayInMessageBoard("\n" + le.Message + " " +
                       le.LibraryErrorCode.ToString() + ".");

                } catch (Exception ex) {

                    DisplayInMessageBoard("\n" + ex.Message);
                }
            }
        }

        /// <summary>
        /// Event handler for when the mouse pointer is over the Check Out Item button.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void buttonCheckOutItem_MouseHover(object sender, EventArgs e) {
            // Validates all controls on the View Member form
            if (!this.ValidateChildren(ValidationConstraints.Visible)) {

                // Keeps View Member form open if controls do not validate.
                this.DialogResult = DialogResult.None;
                DisplayInMessageBoard("Correct visible input error.");

                // Disables Check Out Item button.
                this.buttonCheckOutItem.Enabled = false;

                // Check if Expiry Date field is blank.
            } else if (this.textboxExpiryDate.Text == "") {

                // Keeps View Member form open if controls do not validate.
                this.DialogResult = DialogResult.None;
                this.labelMemberAlert.Text = "message board:\n\n Enter Member ID " +
                   "and click View Member Information button.";
                this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;

                // Disables Check Out Item button.
                this.buttonCheckOutItem.Enabled = false;


                // Check if Member's card has expired.
            } else if (this.textboxExpiryDate.BackColor == SystemColors.InactiveCaptionText) {

                // Keeps View Member form open if controls do not validate.
                this.DialogResult = DialogResult.None;
                this.labelMemberAlert.Text = "message board:\n\n Member card expired. " +
                    "Please renew for check out.";
                this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;

                // Disables Check Out Item button.
                this.buttonCheckOutItem.Enabled = false;

                // Allows item check out if Member is not at capacity regading
                // items on loan.
            } else {

                // Number of items member can check out.
                int bookCheckOutable = 4 - datagridviewItemsOnLoan.RowCount;

                // Lets user know how many items member can check out.
                if (bookCheckOutable == 0) {
                    DisplayInMessageBoard("Member cannot check out anymore items.");

                    // Disables Check Out Item button.
                    this.buttonCheckOutItem.Enabled = false;
                } else {

                    // Shows ISBN and Copy Number text box objects.
                    this.textboxISBN.Visible = true;
                    this.textboxCopyNumber.Visible = true;
                    DisplayInMessageBoard("Member can check out up to " + bookCheckOutable +
                        " item(s). Enter ISBN and Copy Number below.");

                }
            }
        }

        /// <summary>
        /// Event handler for when the Member ID textbox is modified.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxMemberID_ModifiedChanged(object sender, EventArgs e) {
            //// Runs the View Member Info click event.
            //buttonViewMemberInfo_Click(sender, e);
        }

        /// <summary>
        /// Event handler for when text is typed in the Member ID textbox.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxMemberID_KeyDown(object sender, KeyEventArgs e) {
            // Enables Check Out Item button if Disabled.
            if (this.buttonCheckOutItem.Enabled == false) {
                this.buttonCheckOutItem.Enabled = true;
            }
        }

        /// <summary>
        /// Validation test for item ISBN.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Data for cancelable event</param>
        private void textboxISBN_Validating(object sender, CancelEventArgs e) {

            // Attempts to parse item ISBN text for valid item ISBN number
            // and traps exceptions due to format of entry or if entry is out
            // of range.
            try {
                int.Parse(textboxISBN.Text);

            } catch (FormatException) {
                e.Cancel = true;
                errorproviderViewMember.SetError(textboxISBN,
                    "ISBN must be numeric.");

            } catch (OverflowException) {
                e.Cancel = true;
                errorproviderViewMember.SetError(textboxISBN,
                    "ISBN ID must be a number from 1 to 9999999999999.");
            }
        }

        /// <summary>
        /// Event handler for valid Member ID entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxISBN_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderViewMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Event handler for when text is typed in the ISBN textbox.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxISBN_KeyDown(object sender, KeyEventArgs e) {
            // Enables Check Out Item button if Disabled.
            if (this.buttonCheckOutItem.Enabled == false) {
                this.buttonCheckOutItem.Enabled = true;
            }

            // Enables Check In Item button if Disabled.
            if (this.buttonCheckInItems.Enabled == false) {
                this.buttonCheckInItems.Enabled = true;
            }
        }


        /// <summary>
        /// Validation test for item Copy Number.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Data for cancelable event</param>
        private void textboxCopyNumber_Validating(object sender, CancelEventArgs e) {
            // Attempts to parse item Copy Number text for valid item Copy number
            // and traps exceptions due to format of entry or if entry is out
            // of range.
            try {
                short.Parse(textboxCopyNumber.Text);

            } catch (FormatException) {
                e.Cancel = true;
                errorproviderViewMember.SetError(textboxCopyNumber,
                    "Copy Number must be numeric.");

            } catch (OverflowException) {
                e.Cancel = true;
                errorproviderViewMember.SetError(textboxCopyNumber,
                    "Copy Number must be a number from 1 to 32767.");
            }
        }

        /// <summary>
        /// Event handler for valid Member ID entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxCopyNumber_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderViewMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Event handler for when text is typed in the Copy Number textbox.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxCopyNumber_KeyDown(object sender, KeyEventArgs e) {
            // Enables Check Out Item button if Disabled.
            if (this.buttonCheckOutItem.Enabled == false) {
                this.buttonCheckOutItem.Enabled = true;
            }

            // Enables Check In Item button if Disabled.
            if (this.buttonCheckInItems.Enabled == false) {
                this.buttonCheckInItems.Enabled = true;
            }
        }
       


        /// <summary>
        /// Event handler for when the mouse pointer is over the Check In Item button.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void buttonCheckInItems_MouseHover(object sender, EventArgs e) {

            // Hides Member ID text box and label until needed.
            this.labelMemberID.Hide();
            this.textboxMemberID.Hide();
            this.textboxMemberID.Text="1";

            // Shows ISBN and Copy Number text box objects.
            this.textboxISBN.Visible = true;
            this.textboxCopyNumber.Visible = true;

            DisplayInMessageBoard("Enter ISBN and Copy Number below.");

             
        }
        
        /// <summary>
        /// Event handler for when the Check In Item button is clicked.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void buttonCheckInItems_Click(object sender, EventArgs e) {
            // Validates all controls on the View Member form
            if (!this.ValidateChildren(ValidationConstraints.Visible)) {

                // Keeps View Member form open if controls do not validate.
                this.DialogResult = DialogResult.None;

            } else {
                try {
                    // Casts text of Member ID to short.
                    //short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

                    // Casts text of Copy Number to int.
                    int validISBN = Convert.ToInt32(this.textboxISBN.Text);

                    // Casts text of Copy Number to short.
                    short validCopyNumber = Convert.ToInt16(this.textboxCopyNumber.Text);


                    // Creates the object that provides data.
                    LibraryBusinessLayer lbl = new LibraryBusinessLayer();

                    // Gets item data.
                    TO.LibraryEntities.LibraryEntities.Item foundItem = lbl.GetItemInfo(validISBN, validCopyNumber);

                    // Throw LibraryException if item not on loan, and
                    // If on loan, checks item in.
                    if (foundItem.MemberNumber == 0) {
                        
                        // Shows Member ID text box and label.
                        this.textboxMemberID.Text = "";
                        this.labelMemberID.Show();
                        this.textboxMemberID.Show();

                        // Disables Check Out Item button.
                        this.buttonCheckOutItem.Enabled = true;

                        throw new LibraryException(ErrorCode.ItemNotOnLoan);

                    } else {
                        // Hides Member ID text box and label.
                        this.labelMemberID.Hide();
                        this.textboxMemberID.Hide();

                        // Places Member ID into text box after converting.
                        this.textboxMemberID.Text = Convert.ToString(foundItem.MemberNumber);

                        // Shows Member ID text box and label.
                        this.labelMemberID.Show();
                        this.textboxMemberID.Show();

                        // Shows item and member info based on ISBN and Copy Number if 
                        // item is on loan.
                        buttonViewMemberInfo_Click(sender, e);

                        // Get item.
                        StringBuilder myPreCheckInItem = new StringBuilder("");
                        //myPreCheckInItem.Append(foundItem.ISBN + ",");
                        //myPreCheckInItem.Append(foundItem.CopyNumber + ",");
                        //myPreCheckInItem.Append(foundItem.Title + ",");
                        //myPreCheckInItem.Append(foundItem.Author);

                        myPreCheckInItem.Append(validISBN + ",");
                        myPreCheckInItem.Append(validCopyNumber + ",");
                        myPreCheckInItem.Append(foundItem.Title + ",");
                        myPreCheckInItem.Append(foundItem.Author);

                        if (MessageBox.Show("Would you like to check in "+myPreCheckInItem+"?",
                            "Item Check In", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {

                            // Attempts to check in item.
                            lbl.SetCheckInItem(validISBN, validCopyNumber);

                            // Refreshes Member information.
                            buttonViewMemberInfo_Click(sender, e);

                            DisplayInMessageBoard("Item checked in.");
                        }
                    }


                } catch (ArgumentOutOfRangeException ae) {

                    DisplayInMessageBoard(ae.Message);

                } catch (LibraryException le) {

                    DisplayInMessageBoard(le.Message + " " +
                               le.LibraryErrorCode.ToString());
                } catch (Exception ex) {

                    DisplayInMessageBoard("\n" + ex.Message);
                }
            }
        }



#endregion

        #region MyMethods

        /// <summary>
        /// Changes the View Member form's messageboard label text.
        /// </summary>
        /// <param name="myCaption">String representing text to change.</param>
        private void DisplayInMessageBoard (string myCaption){
            this.labelMemberAlert.Text = "message board:\n " + myCaption;
            // Brightens the text color.
            this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;
        }

        #endregion

                  
    }
 
}