using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using TO.LibraryBusiness;
using TO.LibraryEntities;
using TO.LibraryDataAccess;
using System.Xml.Serialization;

// Library Phase 4 Web Service.
[WebService(Description="Basic Service", Namespace="http://www.dalelagbaja.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    public Service () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }


    #region MyMethods
    /// <summary>
    /// Changes client messageboard label text.
    /// </summary>
    /// <param name="myCaption">Message to return.</param>
    /// <returns>an instance of<see cref="System.String"/>Mesage to display in client</returns>
    [WebMethod]
    public string DisplayInMessageBoard(string myCaption) {

        // Creation of message to return to client
        string returnMessage = "message board:\n " + myCaption;

        return returnMessage;
    }

    /// <summary>
    /// Checks out item whose ISBN and copy number are specified to the
    /// Member whose member ID is specified.
    /// </summary>
    /// <param name="memberID">Member ID of member checking out item.</param>
    /// <param name="itemISBN">ISBN of item being checked out.</param>
    /// <param name="itemCopyNumber">Copy Number of item being checked out.</param>
    [WebMethod]
    public void wsGetCheckOutItem(short memberID, int itemISBN, short itemCopyNumber) {

        try {

            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Call to business layer.
            lbl.GetCheckOutItem(memberID, itemISBN, itemCopyNumber);

        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode,SoapException.ClientFaultCode,
                Context.Request.Url.AbsoluteUri,
                le);
        }
    }

    /// <summary>
    /// Checks in item whose ISBN and copy number are specified.
    /// </summary>
    /// <param name="itemISBN">ISBN of item being checked in.</param>
    /// <param name="itemCopyNumber">Copy Number of item being checked out.</param>
    [WebMethod]
    public void wsSetCheckInItem(int itemISBN, short itemCopyNumber) {

        try {
            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Call to business layer.
            lbl.SetCheckInItem(itemISBN, itemCopyNumber);
        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode, SoapException.ClientFaultCode,
                Context.Request.Url.AbsoluteUri,
                le);

        }
    }

    /// <summary>
    /// Adds an adult member to the database.
    /// </summary>
    /// <param name="adultFirstName">Adult First Name</param>
    /// <param name="adultLastName">Adult Last Name</param>
    /// <param name="adultMidInit">Adult Middle Initial</param>
    /// <param name="street">Street</param>
    /// <param name="city">City</param>
    /// <param name="state">State</param>
    /// <param name="zipCode">Zip Code</param>
    /// <param name="phoneNumber">Phone Number</param>
    /// <returns>An instance of<see cref="TO.LibraryEntities.LibraryEntities.AdultMember"/>Adult Member</returns>
    [WebMethod]
    public LibraryEntities.AdultMember wsAddAdultMember(string adultFirstName,
        string adultLastName, string adultMidInit,
        string street, string city, string state,
        string zipCode, string phoneNumber) {

        try {
            LibraryEntities.AdultMember wsAdultMember = new LibraryEntities.AdultMember();

            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Call to business layer.
            wsAdultMember = lbl.AddAdultMember(adultFirstName, adultLastName, adultMidInit,
                street, city, state, zipCode, phoneNumber);

            return wsAdultMember;

        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode, SoapException.ClientFaultCode,
              Context.Request.Url.AbsoluteUri,
              le);
        
        }
    }

    /// <summary>
    /// Add a juvenile member to the database.
    /// </summary>
    /// <param name="adultMemberID">Sponsoring Adult Member ID</param>
    /// <param name="juvenileFirstName">Juvenile Fist Name</param>
    /// <param name="juvenileLastName">Juvenile Last Name</param>
    /// <param name="juvenileMidInit">Juvenile Middle Initial</param>
    /// <param name="birthDate">Birth Date</param>
    /// <returns>An instance of<see cref="TO.LibraryEntities.LibraryEntities.JuvenileMember"/>Juvenile Member</returns>
    [WebMethod]
    public LibraryEntities.JuvenileMember wsAddJuvenileMember(short adultMemberID,
        string juvenileFirstName, string juvenileLastName,
        string juvenileMidInit, DateTime birthDate) {

        try {

            LibraryEntities.JuvenileMember wsJuvenileMember = new LibraryEntities.JuvenileMember();

            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Call to business layer.
            wsJuvenileMember = lbl.AddJuvenileMember(adultMemberID, juvenileFirstName, juvenileLastName,
                juvenileMidInit, birthDate);

            return wsJuvenileMember;
        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode, SoapException.ClientFaultCode,
                Context.Request.Url.AbsoluteUri,
                le);
        }
    }

    /// <summary>
    /// Gets member information based on valid member ID.
    /// </summary>
    /// <param name="memberId">Member ID used to return member info.</param>
    /// <returns>An instance of<see cref="TO.LibraryEntities.LibraryEntities.Member"/>Member Info.</returns>
    [WebMethod]
    [XmlInclude(typeof(TO.LibraryEntities.LibraryEntities.AdultMember))]
    [XmlInclude(typeof(TO.LibraryEntities.LibraryEntities.JuvenileMember))] 
    public LibraryEntities.Member wsGetInformation(short memberid) {

        try {
            LibraryEntities.Member wsMember = new LibraryEntities.Member();

            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Call to business layer.
            wsMember = lbl.GetInformation(memberid);

            return wsMember;
        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode, SoapException.ClientFaultCode,
                Context.Request.Url.AbsoluteUri,
                le);
        }
    }

    /// <summary>
    /// Checks if a member is a juvenile.
    /// </summary>
    /// <param name="memberId">Member ID used to return member info.</param>
    /// <returns>An instance of<see cref="System.Boolean"/>Is juvenile status</returns>
    [WebMethod]
    public bool wsIsJuvenile(short memberID) {

        try {
            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Call to business layer.
            bool wsIsJuv = lbl.IsJuvenile(memberID);

            return wsIsJuv;
        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode, SoapException.ClientFaultCode,
                Context.Request.Url.AbsoluteUri,
                le);
        }
    }


    /// <summary>
    /// Converts a juvenile member to an adult member
    /// </summary>
    /// <param name="memberId">Member ID</param>
    [WebMethod]
    public void wsMakeAdult(LibraryEntities.Member memberID) {

        try {
            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Call to business layer.
            lbl.MakeAdult(memberID);
        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode, SoapException.ClientFaultCode,
                Context.Request.Url.AbsoluteUri,
                le);
        }
    }

    /// <summary>
    /// Gets list of Member items on loan for use on presentation layer.
    /// </summary>
    /// <param name="memberID">Member ID used to return checked out items.</param>
    /// <returns>An instance of<see cref="TO.LibraryEntities.ItemsDataSet"/>ItemsDataSet</returns>
    [WebMethod]
    public ItemsDataSet wsGetViewMemberGrid(short memberID) {

        try {
            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Call to business layer.
            ItemsDataSet wsGridDataSet = lbl.GetViewMemberGrid(memberID);

            return wsGridDataSet;
        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode, SoapException.ClientFaultCode,
                Context.Request.Url.AbsoluteUri,
                le);
        }
    }

    /// <summary>
    /// Gets item information based on valid ISBN and Copy Number.
    /// </summary>
    /// <param name="itemISBN">Item ISBN</param>
    /// <param name="itemCopyNumber">Copy Number</param>
    /// <returns>An instance of<see cref="TO.LibraryEntities.LibraryEntities.Item"/>Item</returns>
    [WebMethod]
    public LibraryEntities.Item wsGetItemInfo(int itemISBN, short itemCopyNumber) {

        try {
            LibraryEntities.Item wsItem = new LibraryEntities.Item();

            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            wsItem = lbl.GetItemInfo(itemISBN, itemCopyNumber);

            // Call to business layer.
            return wsItem;
        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode, SoapException.ClientFaultCode,
                Context.Request.Url.AbsoluteUri,
                le);
        }
    
    }

    /// <summary>
    /// Renew member's card expiry date.
    /// </summary>
    /// <param name="memberId">Member ID used to return member info.</param>
    [WebMethod]
    public void wsSetExpiryDate(short memberId) {

        try {
            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Call to business layer.
            lbl.SetExpiryDate(memberId);
        } catch (LibraryException le) {

            throw new SoapException(le.LibraryErrorCode, SoapException.ClientFaultCode,
                Context.Request.Url.AbsoluteUri,
                le);
        }
    }

    #endregion

}
