using System;
using System.Collections.Generic;
using System.Text;

namespace AppTypes {
    /// <summary>
    /// Defines a custom exception that may be thrown from various 
    /// classes in the AppTypes namespace.
    /// </summary>
    [DeveloperInfoAttribute("Temitope Oluwole", Date = "29mar08", Title = "AppTypes.AppTypesException Class")]
    [CustomDescriptionAttribute("Defines a custom exception that may be thrown from various" +
        "classes in the AppTypes namespace")]
    [Serializable]
    public class AppTypesException : Exception {



        #region Fields
        /// <summary>
        /// Read-only field declaration.
        /// </summary>
        private string lineNumber;
        
        #endregion



        #region Properties
        
        /// <summary>
        /// Read-only property declaration.
        /// </summary>
        public string LineNumber {

            get { return lineNumber; }
        }  


        #endregion

        /// <summary>
        /// Default constructor.
        /// </summary>
        public AppTypesException():base() {

        }

        /// <summary>
        /// Constructor accepts a string message.
        /// </summary>
        public AppTypesException(string eMessage): base(eMessage) {

        }
        /// <summary>
        /// Constructor accepts a string message and an inner exception
        /// </summary>
        /// <param name="eMessage">Exception message.</param>
        /// <param name="eInner">Inner exception.</param>
        public AppTypesException(string eMessage, Exception eInner):
            base(eMessage, eInner) {

            // Parse the results of the ToString() of the innerException argument
            // to extract the line number at which the exception occurred, and then
            // populates the lineNumber field.
            lineNumber = "Exception at Line Number: {0}" + eInner.ToString();
            
        }

        

    }
}
