using System;
using System.Collections.Generic;
using System.Text;

namespace AppTypes {
    /// <summary>
    /// An enum used to indicate the success or failure of an attempt to modify
    /// the collection.
    /// </summary>
    [DeveloperInfoAttribute("Temitope Oluwole", Date = "04mar08", Title = "AppTypes.ModificationEventStatus Enum")]
    [CustomDescriptionAttribute("An enum used to indicate the success or failure of an attempt to modify" +
     "the collection.")]
    [Serializable]
    public enum ModificationEventStatus {

        /// <summary>
        /// Unsuccessful ModificationEventStatus
        /// </summary>
        unsuccessful,
        /// <summary>
        /// Successful ModificationEventStatus
        /// </summary>
        successful,
    }
}
