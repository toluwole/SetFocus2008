using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation {
    /// <summary>
    /// This interface details required properties for 
    /// abstractions with a mailing address.
    /// </summary>
    interface IAddress {

        #region Properties

        /// <summary>
        /// Read and write Interface properties
        /// </summary>
        string Address { get;set;}
        string City { get;set;}
        string Region { get; set;}
        string PostalCode { get;set;}

        #endregion

    }
}
