using System;
using System.Collections.Generic;
using System.Text;

namespace TO.LibraryEntities {
    /// <summary>
    /// Business Class Objects
    /// </summary>
    public class LibraryEntities {
        /// <summary>
        /// Represents a member of the library. 
        /// </summary>
        public class Member {

            #region MyFields
            /// <summary>
            /// Field properties.
            /// </summary>
            private string city;
            private DateTime expirationDate;
            private string firstName;
            private string lastName;
            private short memberID;
            private string middleInitial;
            private string phoneNumber;
            private string state;
            private string street;
            private string zipCode;

            #endregion
            #region MyProperties
            /// <summary>
            /// Gets of sets the member's city of residence.
            /// </summary>
            public string City {
                get { return city; }
                set { city = value; }
            }

            /// <summary>
            /// Gets or sets the member's membership expiration date.
            /// </summary>
            public DateTime ExpirationDate {
                get { return expirationDate; }
                set { expirationDate = value; }
            }

            /// <summary>
            /// Gets or sets the member's first name.
            /// </summary>
            public string FirstName {
                get { return firstName; }
                set { firstName = value; }
            }

            /// <summary>
            /// Gets or sets the member's last name.
            /// </summary>
            public string LastName {
                get { return lastName; }
                set { lastName = value; }
            }

            /// <summary>
            /// Gets or sets the member's MemberID.
            /// </summary>
            public short MemberID {
                get { return memberID; }
                set { memberID = value; }
            }

            /// <summary>
            /// Gets or sets the member's middle initial. 
            /// </summary>
            public string MiddleInitial {
                get { return middleInitial; }
                set { middleInitial = value; }
            }

            /// <summary>
            /// Gets or sets the member's phone number. 
            /// </summary>
            public string PhoneNumber {
                get { return phoneNumber; }
                set { phoneNumber = value; }
            }

            /// <summary>
            /// Gets or sets the member's state of residence. 
            /// </summary>
            public string State {
                get { return state; }
                set { state = value; }
            }

            /// <summary>
            /// Gets or sets the member's street address. 
            /// </summary>
            public string Street {
                get { return street; }
                set { street = value; }
            }

            /// <summary>
            /// Gets or sets the member's ZIP code. 
            /// </summary>
            public string ZipCode {
                get { return zipCode; }
                set { zipCode = value; }
            }
            #endregion

            #region MyMethods

            /// <summary>
            /// Initializes a new instance of the Member class. 
            /// </summary>
            public Member() {

            }
            #endregion
        }

        /// <summary>
        /// Represents an adult member of the library. 
        /// </summary>
        public class AdultMember : Member {

            /// <summary>
            /// Initializes a new instance of the AdultMember class.
            /// </summary>
            public AdultMember() {

            }
        }

        /// <summary>
        /// Represents a member of the library who is below the age of eighteen. 
        /// </summary>
        public class JuvenileMember : Member {

            #region MyFields
            /// <summary>
            /// Field declarations.
            /// </summary>
            private short adultMemberID;
            private DateTime birthDate;
            #endregion

            #region MyProperties
            /// <summary>
            /// Gets or sets the sponsoring adult member ID. 
            /// </summary>
            public short AdultMemberID {
                get { return adultMemberID; }
                set { adultMemberID = value; }
            }

            /// <summary>
            /// Gets or sets the juvenile member's birth date. 
            /// </summary>
            public DateTime BirthDate {
                get { return birthDate; }
                set { birthDate = value; }
            }
            #endregion

            #region MyMethods
            /// <summary>
            /// Initializes a new instance of the JuvenileMember class. 
            /// </summary>
            public JuvenileMember() {

            }
            #endregion
        }

        /// <summary>
        /// Represents an item (a book) in the library. 
        /// </summary>
        public class Item {

            #region MyFields

            /// <summary>
            /// Field declarations.
            /// </summary>
            private string author;
            private DateTime checkoutDate;
            private short copyNumber;
            private DateTime dueDate;
            private int isbn;
            private short memberNumber;
            private string title;

            #endregion

            #region MyProperties

            /// <summary>
            /// Gets the author of the item. 
            /// </summary>
            public string Author {
                get { return author; }
                set { author = value; }
            }

            /// <summary>
            /// Gets the checkout date of the item, or the earliest
            /// date value possible, if the item is not on loan. 
            /// </summary>
            public DateTime CheckoutDate {
                get { return checkoutDate; }
                set { checkoutDate = value; }
            }

            /// <summary>
            /// Gets the copy number of the item. 
            /// </summary>
            public Int16 CopyNumber {
                get { return copyNumber; }
                set { copyNumber = value; }
            }

            /// <summary>
            /// Gets the due date of the item, or the earliest 
            /// date value possible, if the item is not on loan. 
            /// </summary>
            public DateTime DueDate {
                get { return dueDate; }
                set { dueDate = value; }
            }

            /// <summary>
            /// Gets the ISBN of the item.
            /// </summary>
            public Int32 ISBN {
                get { return isbn; }
                set { isbn = value; }
            }

            /// <summary>
            /// Gets the member number of the member to whom the 
            /// item is on loan, or zero, if the item is not on loan. 
            /// </summary>
            public Int16 MemberNumber {
                get { return memberNumber; }
                set { memberNumber = value; }
            }

            /// <summary>
            /// Gets the title of the item. 
            /// </summary>
            public string Title {
                get { return title; }
                set { title = value; }
            }

            #endregion

            #region MyMethods
            /// <summary>
            /// Initializes a new Item object. 
            /// </summary>
            /// <param name="isbn">The ISBN of the item</param>
            /// <param name="copy_no">The copy number of the item</param>
            /// <param name="title">The title of the item</param>
            /// <param name="author">The author of the item</param>
            /// <param name="member_no">The member to whom the item is on loan, or zero, if the item is not on loan</param>
            /// <param name="out_date">The checkout date for the item, or the earliest date value possible, if the item is not on loan</param>
            /// <param name="due_date">The due date for the item, or the earliest date value possible, if the item is not on loan</param>
            public Item(Int32 isbn, Int16 copy_no, string title,
                string author, Int16 member_no, DateTime out_date,
                DateTime due_date) 
            {
                this.isbn = isbn;
                this.copyNumber = copy_no;
                this.title = title;
                this.author = author;
                this.memberNumber = member_no;
                this.checkoutDate = out_date;
                this.dueDate = due_date;
            }

            /// <summary>
            /// Default constructor
            /// </summary>
            public Item() {

            }
            #endregion
        }

    }
}
