using System;
using System.Collections.Generic;
using System.Text;

namespace AppTypes {

    /// <summary>
    /// A class used to communicate details about the event raised.
    /// </summary>
    [DeveloperInfoAttribute("Temitope Oluwole", Date = "04mar08", Title = "AppTypes.ModificationEventArgs Class")]
    [CustomDescriptionAttribute("A class used to communicate details about the event raised.")]
    [Serializable]
    class ModificationEventArgs : EventArgs {

        #region Fields

        /// <summary>
        /// Field declarations.
        /// </summary>
        private ModificationEventStatus modificationEventsStatus;
        private object modifiedObjectReference; 

        #endregion

        #region Properties

        /// <summary>
        /// Read-only ModificationEventStatus property.
        /// </summary>
        public ModificationEventStatus ModificationEventsStatus {
            get { return modificationEventsStatus; }
        }

        /// <summary>
        /// Read-only ModifiedObjectRefence.
        /// </summary>
        public object ModifiedObjectReference {
            get { return modifiedObjectReference; }
        } 

        #endregion

        /// <summary>
        /// Default constructor.
        /// </summary>
        public ModificationEventArgs() {

        }

        /// <summary>
        /// Constructor setting ModificationEventsStatus and
        /// ModifiedObjectRefence with supplied values.
        /// </summary>
        /// <param name="mEventStatus">ModificationEventsStatus</param>
        /// <param name="mObjectReference">ModifiedObjectReference</param>
        public ModificationEventArgs(ModificationEventStatus mEventStatus, 
            object mObjectReference) {

            modificationEventsStatus = mEventStatus;
            modifiedObjectReference = mObjectReference;
        }
        

    }
}
