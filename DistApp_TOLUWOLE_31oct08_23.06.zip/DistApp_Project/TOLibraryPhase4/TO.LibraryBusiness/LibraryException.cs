using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace TO.LibraryBusiness {
    /// <summary>
    /// The exception that is thrown when 
    /// a non-fatal application error occurs 
    /// in the Library application. 
    /// </summary>
    [Serializable]
    public class LibraryException:Exception {

        #region MyFields

        /// <summary>
        /// Field declarations.
        /// </summary>
        private string libraryErrorCode;
        private short otherMemberID;

        #endregion

        #region MyProperties
        /// <summary>
        /// Gets the value of the ErrorCode value that was set when this
        /// exception was created. This value indicates the reason for the
        /// exception being thrown. 
        /// </summary>
        public string LibraryErrorCode {
            get { return libraryErrorCode; }
        }

        /// <summary>
        /// Gets the value of the OtherMemberID value that was set when this
        /// exception was created. This value will be the member ID of the 
        /// member to whom an item is already on loan when an attempt is made 
        /// to check the item out, if the ErrorCode value is set to 
        /// ErrorCode.ItemAlreadyOnLoan.
        /// </summary>
        public short OtherMemberID {
            get { return otherMemberID; }
            set { otherMemberID = value; }
        }

        #endregion

        #region MyMethods

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="info"></param>
        ///// <param name="context"></param>
        //public override void GetObjectData(SerializationInfo info, StreamingContext context) {
        //    base.GetObjectData(info, context);
        //}

        #endregion

        #region MyConstructors

        /// <summary>
        /// Initializes a new instance of the LibraryException class. 
        /// </summary>
        public LibraryException():base() {

        }

        /// <summary>
        /// Initializes a new instance of the LibraryException class 
        /// with a specified ErrorCode. 
        /// </summary>
        /// <param name="myErrorCode">Specified Error Code</param>
        public LibraryException(ErrorCode myErrorCode):base() {

        }

        /// <summary>
        /// Initializes a new instance of the LibraryException class 
        /// with a specified ErrorCode and a specified error message. 
        /// </summary>
        /// <param name="myErrorCode">Specified Error Code</param>
        /// <param name="errorMessage">Specified error message</param>
        public LibraryException(ErrorCode myErrorCode,string errorMessage):base(errorMessage) {

        }

        /// <summary>
        /// Initializes a new instance of the LibraryException class with a specified 
        /// ErrorCode, a specified error message, and a reference to the inner exception 
        /// that is the cause of this exception 
        /// </summary>
        /// <param name="myErrorCode">Specified Error Code</param>
        /// <param name="errorMessage">Specified error message</param>
        /// <param name="innerErrorMessage">Inner exception message</param>
        public LibraryException(ErrorCode myErrorCode,string errorMessage,
            Exception innerErrorMessage
            ):base(errorMessage,innerErrorMessage) {

        }

        /// <summary>
        /// Initializes a new instance of the LibraryException class that indicates 
        /// an item is already on loan to another member when an attempt is made to 
        /// check out the item. The ErrorCode will be set implicitly to 
        /// ErrorCode.ItemAlreadyOnLoan.  
        /// </summary>
        /// <param name="otherMemberID">Other MemberID</param>
        /// <param name="errorMessage">Specified error message</param>
        public LibraryException(Int16 otherMemberID, string errorMessage):base() {
            
            libraryErrorCode = ErrorCode.ItemAlreadyOnLoan.ToString();
        }

        /// <summary>
        /// Initializes a new instance of the LibraryException class with a 
        /// specified error message. 
        /// </summary>
        /// <param name="errorMessage">Specified error message</param>
        public LibraryException(string errorMessage):base() {

        }

        /// <summary>
        /// Initializes a new instance of the LibraryException class with a 
        /// specified error message and a reference to the inner exception that 
        /// is the cause of this exception. 
        /// </summary>
        /// <param name="errorMessage">Specified error message</param>
        /// <param name="innerErrorMessage">Inner exception message</param>
        public LibraryException(string errorMessage, Exception innerErrorMessage)
            : base(errorMessage, innerErrorMessage) {

        }

        /// <summary>
        /// Initializes a new instance of the LibraryException class with serialized data. 
        /// </summary>
        /// <param name="info">Info</param>
        /// <param name="context">Context</param>
        public LibraryException(SerializationInfo info, StreamingContext context):base() {

        }
        #endregion

      

    }

    /// <summary>
    /// The error codes that can be returned in a LibraryException.
    /// </summary>
    public enum ErrorCode {

        /// <summary>
        /// No error code has been provided. 
        /// </summary>
        None,

        /// <summary>
        /// A generic exception was thrown. Check the exception 
        /// message and the inner exception for details. 
        /// </summary>
        GenericException,

        /// <summary>
        /// No Item with the specified ISBN and copy number was found.
        /// </summary>
        ItemNotFound,

        /// <summary>
        /// No member with the specified member number was found.
        /// </summary>
        NoSuchMember,

        /// <summary>
        /// Item with the specified ISBN and copy number is not on 
        /// loan currently.
        /// </summary>
        ItemNotOnLoan,

        /// <summary>
        /// Failed to check in specified item. 
        /// </summary>
        CheckInFailed,

        /// <summary>
        /// Item with the specified ISBN and copy number is already on 
        /// loan to another member. Check the OtherMemberID property of 
        /// the LibraryException to obtain the member ID of the member to 
        /// whom the item is on loan currently. 
        /// </summary>
        ItemAlreadyOnLoan,

        /// <summary>
        /// Failed to check out specified item. 
        /// </summary>
        CheckOutFailed,

        /// <summary>
        /// Failed to add new adult member.
        /// </summary>
        AddAdultFailed,

        /// <summary>
        /// No sponsoring adult member record could be found while trying 
        /// to add a new juvenile member.
        /// </summary>
        MissingAdultMember,

        /// <summary>
        /// Failed to add new juvenile member.
        /// </summary>
        AddJuvenileFailed
    }
}
