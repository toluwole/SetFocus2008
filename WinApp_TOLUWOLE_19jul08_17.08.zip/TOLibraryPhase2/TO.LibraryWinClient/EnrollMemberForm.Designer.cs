namespace TO.LibraryWinClient {
    partial class EnrollMemberForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.groupboxMemberExp = new System.Windows.Forms.GroupBox();
            this.textboxExpiryDate = new System.Windows.Forms.TextBox();
            this.labelExpiryDate = new System.Windows.Forms.Label();
            this.textboxMemberID = new System.Windows.Forms.TextBox();
            this.labelMemberID = new System.Windows.Forms.Label();
            this.groupboxMemberName = new System.Windows.Forms.GroupBox();
            this.labelMiddleInit = new System.Windows.Forms.Label();
            this.textboxMiddleInit = new System.Windows.Forms.TextBox();
            this.textboxLastName = new System.Windows.Forms.TextBox();
            this.labelLastName = new System.Windows.Forms.Label();
            this.textboxFirstName = new System.Windows.Forms.TextBox();
            this.labelFirstName = new System.Windows.Forms.Label();
            this.groupboxAddress = new System.Windows.Forms.GroupBox();
            this.textboxPhone = new System.Windows.Forms.TextBox();
            this.labelPhone = new System.Windows.Forms.Label();
            this.textboxZipCode = new System.Windows.Forms.TextBox();
            this.labelZipCode = new System.Windows.Forms.Label();
            this.comboboxState = new System.Windows.Forms.ComboBox();
            this.labelState = new System.Windows.Forms.Label();
            this.textboxCity = new System.Windows.Forms.TextBox();
            this.labelCity = new System.Windows.Forms.Label();
            this.textboxStreet = new System.Windows.Forms.TextBox();
            this.labelStreet = new System.Windows.Forms.Label();
            this.checkboxJuvenileMember = new System.Windows.Forms.CheckBox();
            this.groupboxJuvenile = new System.Windows.Forms.GroupBox();
            this.textboxDateOfBirth = new System.Windows.Forms.TextBox();
            this.labelDateOfBirth = new System.Windows.Forms.Label();
            this.labelJuvenileMiddleInitial = new System.Windows.Forms.Label();
            this.textboxJuvenileMidInitial = new System.Windows.Forms.TextBox();
            this.textboxJuvenileLastName = new System.Windows.Forms.TextBox();
            this.labelJuvenileLastName = new System.Windows.Forms.Label();
            this.textboxJuvenileFirstName = new System.Windows.Forms.TextBox();
            this.labelJuvenileFirstName = new System.Windows.Forms.Label();
            this.buttonEnrollMember = new System.Windows.Forms.Button();
            this.labelMemberAlert = new System.Windows.Forms.Label();
            this.errorproviderEnrollMember = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupboxMemberExp.SuspendLayout();
            this.groupboxMemberName.SuspendLayout();
            this.groupboxAddress.SuspendLayout();
            this.groupboxJuvenile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorproviderEnrollMember)).BeginInit();
            this.SuspendLayout();
            // 
            // groupboxMemberExp
            // 
            this.groupboxMemberExp.Controls.Add(this.textboxExpiryDate);
            this.groupboxMemberExp.Controls.Add(this.labelExpiryDate);
            this.groupboxMemberExp.Controls.Add(this.textboxMemberID);
            this.groupboxMemberExp.Controls.Add(this.labelMemberID);
            this.groupboxMemberExp.Location = new System.Drawing.Point(6, 1);
            this.groupboxMemberExp.Name = "groupboxMemberExp";
            this.groupboxMemberExp.Size = new System.Drawing.Size(394, 42);
            this.groupboxMemberExp.TabIndex = 0;
            this.groupboxMemberExp.TabStop = false;
            // 
            // textboxExpiryDate
            // 
            this.textboxExpiryDate.Location = new System.Drawing.Point(272, 14);
            this.textboxExpiryDate.Name = "textboxExpiryDate";
            this.textboxExpiryDate.ReadOnly = true;
            this.textboxExpiryDate.Size = new System.Drawing.Size(100, 20);
            this.textboxExpiryDate.TabIndex = 3;
            // 
            // labelExpiryDate
            // 
            this.labelExpiryDate.AutoSize = true;
            this.labelExpiryDate.Location = new System.Drawing.Point(182, 16);
            this.labelExpiryDate.Name = "labelExpiryDate";
            this.labelExpiryDate.Size = new System.Drawing.Size(79, 13);
            this.labelExpiryDate.TabIndex = 2;
            this.labelExpiryDate.Text = "Expiration Date";
            // 
            // textboxMemberID
            // 
            this.textboxMemberID.Location = new System.Drawing.Point(71, 14);
            this.textboxMemberID.Name = "textboxMemberID";
            this.textboxMemberID.Size = new System.Drawing.Size(105, 20);
            this.textboxMemberID.TabIndex = 1;
            this.textboxMemberID.Visible = false;
            this.textboxMemberID.Validated += new System.EventHandler(this.textboxMemberID_Validated);
            this.textboxMemberID.Validating += new System.ComponentModel.CancelEventHandler(this.textboxMemberID_Validating);
            // 
            // labelMemberID
            // 
            this.labelMemberID.AutoSize = true;
            this.labelMemberID.Location = new System.Drawing.Point(10, 17);
            this.labelMemberID.Name = "labelMemberID";
            this.labelMemberID.Size = new System.Drawing.Size(59, 13);
            this.labelMemberID.TabIndex = 0;
            this.labelMemberID.Text = "Member ID";
            this.labelMemberID.Visible = false;
            // 
            // groupboxMemberName
            // 
            this.groupboxMemberName.Controls.Add(this.labelMiddleInit);
            this.groupboxMemberName.Controls.Add(this.textboxMiddleInit);
            this.groupboxMemberName.Controls.Add(this.textboxLastName);
            this.groupboxMemberName.Controls.Add(this.labelLastName);
            this.groupboxMemberName.Controls.Add(this.textboxFirstName);
            this.groupboxMemberName.Controls.Add(this.labelFirstName);
            this.groupboxMemberName.Location = new System.Drawing.Point(6, 43);
            this.groupboxMemberName.Name = "groupboxMemberName";
            this.groupboxMemberName.Size = new System.Drawing.Size(394, 59);
            this.groupboxMemberName.TabIndex = 1;
            this.groupboxMemberName.TabStop = false;
            // 
            // labelMiddleInit
            // 
            this.labelMiddleInit.AutoSize = true;
            this.labelMiddleInit.Location = new System.Drawing.Point(214, 14);
            this.labelMiddleInit.Name = "labelMiddleInit";
            this.labelMiddleInit.Size = new System.Drawing.Size(65, 13);
            this.labelMiddleInit.TabIndex = 5;
            this.labelMiddleInit.Text = "Middle Initial";
            // 
            // textboxMiddleInit
            // 
            this.textboxMiddleInit.Location = new System.Drawing.Point(185, 9);
            this.textboxMiddleInit.MaxLength = 1;
            this.textboxMiddleInit.Name = "textboxMiddleInit";
            this.textboxMiddleInit.Size = new System.Drawing.Size(23, 20);
            this.textboxMiddleInit.TabIndex = 4;
            this.textboxMiddleInit.Validated += new System.EventHandler(this.textboxMiddleInit_Validated);
            this.textboxMiddleInit.Validating += new System.ComponentModel.CancelEventHandler(this.textboxMiddleInit_Validating);
            // 
            // textboxLastName
            // 
            this.textboxLastName.Location = new System.Drawing.Point(71, 33);
            this.textboxLastName.Name = "textboxLastName";
            this.textboxLastName.Size = new System.Drawing.Size(109, 20);
            this.textboxLastName.TabIndex = 3;
            this.textboxLastName.Validated += new System.EventHandler(this.textboxLastName_Validated);
            this.textboxLastName.Validating += new System.ComponentModel.CancelEventHandler(this.textboxLastName_Validating);
            // 
            // labelLastName
            // 
            this.labelLastName.AutoSize = true;
            this.labelLastName.Location = new System.Drawing.Point(9, 36);
            this.labelLastName.Name = "labelLastName";
            this.labelLastName.Size = new System.Drawing.Size(58, 13);
            this.labelLastName.TabIndex = 2;
            this.labelLastName.Text = "Last Name";
            // 
            // textboxFirstName
            // 
            this.textboxFirstName.Location = new System.Drawing.Point(71, 9);
            this.textboxFirstName.Name = "textboxFirstName";
            this.textboxFirstName.Size = new System.Drawing.Size(109, 20);
            this.textboxFirstName.TabIndex = 1;
            this.textboxFirstName.Validated += new System.EventHandler(this.textboxFirstName_Validated);
            this.textboxFirstName.Validating += new System.ComponentModel.CancelEventHandler(this.textboxFirstName_Validating);
            // 
            // labelFirstName
            // 
            this.labelFirstName.AutoSize = true;
            this.labelFirstName.Location = new System.Drawing.Point(9, 14);
            this.labelFirstName.Name = "labelFirstName";
            this.labelFirstName.Size = new System.Drawing.Size(57, 13);
            this.labelFirstName.TabIndex = 0;
            this.labelFirstName.Text = "First Name";
            // 
            // groupboxAddress
            // 
            this.groupboxAddress.Controls.Add(this.textboxPhone);
            this.groupboxAddress.Controls.Add(this.labelPhone);
            this.groupboxAddress.Controls.Add(this.textboxZipCode);
            this.groupboxAddress.Controls.Add(this.labelZipCode);
            this.groupboxAddress.Controls.Add(this.comboboxState);
            this.groupboxAddress.Controls.Add(this.labelState);
            this.groupboxAddress.Controls.Add(this.textboxCity);
            this.groupboxAddress.Controls.Add(this.labelCity);
            this.groupboxAddress.Controls.Add(this.textboxStreet);
            this.groupboxAddress.Controls.Add(this.labelStreet);
            this.groupboxAddress.Location = new System.Drawing.Point(6, 102);
            this.groupboxAddress.Name = "groupboxAddress";
            this.groupboxAddress.Size = new System.Drawing.Size(394, 87);
            this.groupboxAddress.TabIndex = 2;
            this.groupboxAddress.TabStop = false;
            // 
            // textboxPhone
            // 
            this.textboxPhone.Location = new System.Drawing.Point(71, 63);
            this.textboxPhone.MaxLength = 13;
            this.textboxPhone.Name = "textboxPhone";
            this.textboxPhone.Size = new System.Drawing.Size(109, 20);
            this.textboxPhone.TabIndex = 9;
            this.textboxPhone.Validated += new System.EventHandler(this.textboxPhone_Validated);
            this.textboxPhone.Validating += new System.ComponentModel.CancelEventHandler(this.textboxPhone_Validating);
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Location = new System.Drawing.Point(9, 66);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(58, 13);
            this.labelPhone.TabIndex = 8;
            this.labelPhone.Text = "Telephone";
            // 
            // textboxZipCode
            // 
            this.textboxZipCode.Location = new System.Drawing.Point(291, 35);
            this.textboxZipCode.MaxLength = 10;
            this.textboxZipCode.Name = "textboxZipCode";
            this.textboxZipCode.Size = new System.Drawing.Size(78, 20);
            this.textboxZipCode.TabIndex = 7;
            this.textboxZipCode.Validated += new System.EventHandler(this.textboxZipCode_Validated);
            this.textboxZipCode.Validating += new System.ComponentModel.CancelEventHandler(this.textboxZipCode_Validating);
            // 
            // labelZipCode
            // 
            this.labelZipCode.AutoSize = true;
            this.labelZipCode.Location = new System.Drawing.Point(263, 39);
            this.labelZipCode.Name = "labelZipCode";
            this.labelZipCode.Size = new System.Drawing.Size(22, 13);
            this.labelZipCode.TabIndex = 6;
            this.labelZipCode.Text = "Zip";
            // 
            // comboboxState
            // 
            this.comboboxState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboboxState.FormattingEnabled = true;
            this.comboboxState.Location = new System.Drawing.Point(196, 35);
            this.comboboxState.Name = "comboboxState";
            this.comboboxState.Size = new System.Drawing.Size(61, 21);
            this.comboboxState.TabIndex = 5;
            // 
            // labelState
            // 
            this.labelState.AutoSize = true;
            this.labelState.Location = new System.Drawing.Point(162, 39);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(32, 13);
            this.labelState.TabIndex = 4;
            this.labelState.Text = "State";
            // 
            // textboxCity
            // 
            this.textboxCity.Location = new System.Drawing.Point(55, 36);
            this.textboxCity.Name = "textboxCity";
            this.textboxCity.Size = new System.Drawing.Size(102, 20);
            this.textboxCity.TabIndex = 3;
            this.textboxCity.Validated += new System.EventHandler(this.textboxCity_Validated);
            this.textboxCity.Validating += new System.ComponentModel.CancelEventHandler(this.textboxCity_Validating);
            // 
            // labelCity
            // 
            this.labelCity.AutoSize = true;
            this.labelCity.Location = new System.Drawing.Point(10, 39);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(24, 13);
            this.labelCity.TabIndex = 2;
            this.labelCity.Text = "City";
            // 
            // textboxStreet
            // 
            this.textboxStreet.Location = new System.Drawing.Point(55, 12);
            this.textboxStreet.Name = "textboxStreet";
            this.textboxStreet.Size = new System.Drawing.Size(132, 20);
            this.textboxStreet.TabIndex = 1;
            this.textboxStreet.Validated += new System.EventHandler(this.textboxStreet_Validated);
            this.textboxStreet.Validating += new System.ComponentModel.CancelEventHandler(this.textboxStreet_Validating);
            // 
            // labelStreet
            // 
            this.labelStreet.AutoSize = true;
            this.labelStreet.Location = new System.Drawing.Point(10, 15);
            this.labelStreet.Name = "labelStreet";
            this.labelStreet.Size = new System.Drawing.Size(35, 13);
            this.labelStreet.TabIndex = 0;
            this.labelStreet.Text = "Street";
            // 
            // checkboxJuvenileMember
            // 
            this.checkboxJuvenileMember.AutoSize = true;
            this.checkboxJuvenileMember.Location = new System.Drawing.Point(13, 196);
            this.checkboxJuvenileMember.Name = "checkboxJuvenileMember";
            this.checkboxJuvenileMember.Size = new System.Drawing.Size(169, 17);
            this.checkboxJuvenileMember.TabIndex = 3;
            this.checkboxJuvenileMember.Text = "Check to add juvenile member";
            this.checkboxJuvenileMember.UseVisualStyleBackColor = true;
            this.checkboxJuvenileMember.CheckedChanged += new System.EventHandler(this.checkboxJuvenileMember_CheckedChanged);
            // 
            // groupboxJuvenile
            // 
            this.groupboxJuvenile.Controls.Add(this.textboxDateOfBirth);
            this.groupboxJuvenile.Controls.Add(this.labelDateOfBirth);
            this.groupboxJuvenile.Controls.Add(this.labelJuvenileMiddleInitial);
            this.groupboxJuvenile.Controls.Add(this.textboxJuvenileMidInitial);
            this.groupboxJuvenile.Controls.Add(this.textboxJuvenileLastName);
            this.groupboxJuvenile.Controls.Add(this.labelJuvenileLastName);
            this.groupboxJuvenile.Controls.Add(this.textboxJuvenileFirstName);
            this.groupboxJuvenile.Controls.Add(this.labelJuvenileFirstName);
            this.groupboxJuvenile.Location = new System.Drawing.Point(6, 219);
            this.groupboxJuvenile.Name = "groupboxJuvenile";
            this.groupboxJuvenile.Size = new System.Drawing.Size(396, 58);
            this.groupboxJuvenile.TabIndex = 4;
            this.groupboxJuvenile.TabStop = false;
            this.groupboxJuvenile.Text = "Juvenile Member";
            this.groupboxJuvenile.Visible = false;
            // 
            // textboxDateOfBirth
            // 
            this.textboxDateOfBirth.Location = new System.Drawing.Point(80, 19);
            this.textboxDateOfBirth.MaxLength = 10;
            this.textboxDateOfBirth.Name = "textboxDateOfBirth";
            this.textboxDateOfBirth.Size = new System.Drawing.Size(100, 20);
            this.textboxDateOfBirth.TabIndex = 7;
            this.textboxDateOfBirth.Visible = false;
            this.textboxDateOfBirth.Validated += new System.EventHandler(this.textboxDateOfBirth_Validated);
            this.textboxDateOfBirth.Validating += new System.ComponentModel.CancelEventHandler(this.textboxDateOfBirth_Validating);
            // 
            // labelDateOfBirth
            // 
            this.labelDateOfBirth.AutoSize = true;
            this.labelDateOfBirth.Location = new System.Drawing.Point(8, 22);
            this.labelDateOfBirth.Name = "labelDateOfBirth";
            this.labelDateOfBirth.Size = new System.Drawing.Size(66, 13);
            this.labelDateOfBirth.TabIndex = 6;
            this.labelDateOfBirth.Text = "Date of Birth";
            this.labelDateOfBirth.Visible = false;
            // 
            // labelJuvenileMiddleInitial
            // 
            this.labelJuvenileMiddleInitial.AutoSize = true;
            this.labelJuvenileMiddleInitial.Location = new System.Drawing.Point(292, 22);
            this.labelJuvenileMiddleInitial.Name = "labelJuvenileMiddleInitial";
            this.labelJuvenileMiddleInitial.Size = new System.Drawing.Size(17, 13);
            this.labelJuvenileMiddleInitial.TabIndex = 5;
            this.labelJuvenileMiddleInitial.Text = "mi";
            this.labelJuvenileMiddleInitial.Visible = false;
            // 
            // textboxJuvenileMidInitial
            // 
            this.textboxJuvenileMidInitial.Location = new System.Drawing.Point(263, 19);
            this.textboxJuvenileMidInitial.MaxLength = 1;
            this.textboxJuvenileMidInitial.Name = "textboxJuvenileMidInitial";
            this.textboxJuvenileMidInitial.Size = new System.Drawing.Size(23, 20);
            this.textboxJuvenileMidInitial.TabIndex = 4;
            this.textboxJuvenileMidInitial.Visible = false;
            this.textboxJuvenileMidInitial.Validated += new System.EventHandler(this.textboxJuvenileMidInitial_Validated);
            this.textboxJuvenileMidInitial.Validating += new System.ComponentModel.CancelEventHandler(this.textboxJuvenileMidInitial_Validating);
            // 
            // textboxJuvenileLastName
            // 
            this.textboxJuvenileLastName.Location = new System.Drawing.Point(246, 19);
            this.textboxJuvenileLastName.Name = "textboxJuvenileLastName";
            this.textboxJuvenileLastName.Size = new System.Drawing.Size(11, 20);
            this.textboxJuvenileLastName.TabIndex = 3;
            this.textboxJuvenileLastName.Visible = false;
            this.textboxJuvenileLastName.Validated += new System.EventHandler(this.textboxJuvenileLastName_Validated);
            this.textboxJuvenileLastName.Validating += new System.ComponentModel.CancelEventHandler(this.textboxJuvenileLastName_Validating);
            // 
            // labelJuvenileLastName
            // 
            this.labelJuvenileLastName.AutoSize = true;
            this.labelJuvenileLastName.Location = new System.Drawing.Point(225, 22);
            this.labelJuvenileLastName.Name = "labelJuvenileLastName";
            this.labelJuvenileLastName.Size = new System.Drawing.Size(15, 13);
            this.labelJuvenileLastName.TabIndex = 2;
            this.labelJuvenileLastName.Text = "ln";
            this.labelJuvenileLastName.Visible = false;
            // 
            // textboxJuvenileFirstName
            // 
            this.textboxJuvenileFirstName.Location = new System.Drawing.Point(208, 19);
            this.textboxJuvenileFirstName.Name = "textboxJuvenileFirstName";
            this.textboxJuvenileFirstName.Size = new System.Drawing.Size(11, 20);
            this.textboxJuvenileFirstName.TabIndex = 1;
            this.textboxJuvenileFirstName.Visible = false;
            this.textboxJuvenileFirstName.Validated += new System.EventHandler(this.textboxJuvenileFirstName_Validated);
            this.textboxJuvenileFirstName.Validating += new System.ComponentModel.CancelEventHandler(this.textboxJuvenileFirstName_Validating);
            // 
            // labelJuvenileFirstName
            // 
            this.labelJuvenileFirstName.AutoSize = true;
            this.labelJuvenileFirstName.Location = new System.Drawing.Point(186, 22);
            this.labelJuvenileFirstName.Name = "labelJuvenileFirstName";
            this.labelJuvenileFirstName.Size = new System.Drawing.Size(16, 13);
            this.labelJuvenileFirstName.TabIndex = 0;
            this.labelJuvenileFirstName.Text = "fn";
            this.labelJuvenileFirstName.Visible = false;
            // 
            // buttonEnrollMember
            // 
            this.buttonEnrollMember.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonEnrollMember.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.buttonEnrollMember.Location = new System.Drawing.Point(409, 8);
            this.buttonEnrollMember.Name = "buttonEnrollMember";
            this.buttonEnrollMember.Size = new System.Drawing.Size(182, 22);
            this.buttonEnrollMember.TabIndex = 5;
            this.buttonEnrollMember.Text = "Enroll Member Information";
            this.buttonEnrollMember.UseVisualStyleBackColor = false;
            this.buttonEnrollMember.Click += new System.EventHandler(this.buttonEnrollMember_Click);
            // 
            // labelMemberAlert
            // 
            this.labelMemberAlert.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMemberAlert.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.labelMemberAlert.Location = new System.Drawing.Point(409, 43);
            this.labelMemberAlert.Name = "labelMemberAlert";
            this.labelMemberAlert.Size = new System.Drawing.Size(182, 146);
            this.labelMemberAlert.TabIndex = 6;
            this.labelMemberAlert.Text = "message board";
            // 
            // errorproviderEnrollMember
            // 
            this.errorproviderEnrollMember.ContainerControl = this;
            // 
            // EnrollMemberForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 339);
            this.Controls.Add(this.labelMemberAlert);
            this.Controls.Add(this.buttonEnrollMember);
            this.Controls.Add(this.groupboxJuvenile);
            this.Controls.Add(this.checkboxJuvenileMember);
            this.Controls.Add(this.groupboxAddress);
            this.Controls.Add(this.groupboxMemberName);
            this.Controls.Add(this.groupboxMemberExp);
            this.Name = "EnrollMemberForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "EnrollMemberForm";
            this.groupboxMemberExp.ResumeLayout(false);
            this.groupboxMemberExp.PerformLayout();
            this.groupboxMemberName.ResumeLayout(false);
            this.groupboxMemberName.PerformLayout();
            this.groupboxAddress.ResumeLayout(false);
            this.groupboxAddress.PerformLayout();
            this.groupboxJuvenile.ResumeLayout(false);
            this.groupboxJuvenile.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorproviderEnrollMember)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupboxMemberExp;
        private System.Windows.Forms.Label labelExpiryDate;
        private System.Windows.Forms.TextBox textboxMemberID;
        private System.Windows.Forms.Label labelMemberID;
        private System.Windows.Forms.TextBox textboxExpiryDate;
        private System.Windows.Forms.GroupBox groupboxMemberName;
        private System.Windows.Forms.TextBox textboxLastName;
        private System.Windows.Forms.Label labelLastName;
        private System.Windows.Forms.TextBox textboxFirstName;
        private System.Windows.Forms.Label labelFirstName;
        private System.Windows.Forms.Label labelMiddleInit;
        private System.Windows.Forms.TextBox textboxMiddleInit;
        private System.Windows.Forms.GroupBox groupboxAddress;
        private System.Windows.Forms.Label labelStreet;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.TextBox textboxCity;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.TextBox textboxStreet;
        private System.Windows.Forms.ComboBox comboboxState;
        private System.Windows.Forms.TextBox textboxZipCode;
        private System.Windows.Forms.Label labelZipCode;
        private System.Windows.Forms.TextBox textboxPhone;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.CheckBox checkboxJuvenileMember;
        private System.Windows.Forms.GroupBox groupboxJuvenile;
        private System.Windows.Forms.Label labelJuvenileFirstName;
        private System.Windows.Forms.TextBox textboxJuvenileLastName;
        private System.Windows.Forms.Label labelJuvenileLastName;
        private System.Windows.Forms.TextBox textboxJuvenileFirstName;
        private System.Windows.Forms.TextBox textboxJuvenileMidInitial;
        private System.Windows.Forms.Label labelDateOfBirth;
        private System.Windows.Forms.Label labelJuvenileMiddleInitial;
        private System.Windows.Forms.TextBox textboxDateOfBirth;
        private System.Windows.Forms.Button buttonEnrollMember;
        private System.Windows.Forms.Label labelMemberAlert;
        private System.Windows.Forms.ErrorProvider errorproviderEnrollMember;
    }
}