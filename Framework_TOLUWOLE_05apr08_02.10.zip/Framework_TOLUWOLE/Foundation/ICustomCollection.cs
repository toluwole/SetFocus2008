using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;


namespace Foundation {
    /// <summary>
    /// This interface is provided as a contract to guarantee that
    /// certain basic collection functionality will be available in 
    /// collection classes to built
    /// </summary>
    public interface ICustomCollection {

        #region Properties

        /// <summary>
        /// Returns the number of elements currently in the collection.
        /// </summary>
        int Count { get;} 

        #endregion

        #region Methods

        /// <summary>
        /// Adds an object to the Collection and returns the int value
        /// of the collection index for the object just added.
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>An instance of<see cref="System.Int32"/></returns>
        int Add(object value);

        /// <summary>
        /// Removes all objects from the Collection.
        /// </summary>
        void Clear();

        /// <summary>
        /// Determines whether the collection contains a specific object.
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        bool Contains(object value);

        /// <summary>
        /// Determines the index of a specific object in the collection.
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>An instance of<see cref="System.Int32"/></returns>
        int IndexOf(object value);

        /// <summary>
        /// Inserts an object into the collection at the specified index.
        /// </summary>
        /// <param name="index">index</param>
        /// <param name="value">value</param>
        void Insert(int index, object value);

        /// <summary>
        /// Removes the first occurence of the specified object from the collection.
        /// </summary>
        /// <param name="value">value</param>
        void Remove(object value);

        /// <summary>
        /// Removes object at specified index.
        /// </summary>
        /// <param name="index">index</param>
        void RemoveAt(int index);

        /// <summary>
        /// Copies item of the collection into an array.
        /// </summary>
        /// <param name="array">array</param>
        void CopyTo(object[] array);

        /// <summary>
        /// Sorts the collection using the IComparable interface of each member
        /// of the collection.
        /// </summary>
        void Sort();

        /// <summary>
        /// Sorts the collection based on the supplied IComparer.
        /// </summary>
        /// <param name="myComparer">IComparer object supplied</param>
        void Sort(IComparer myComparer);

        /// <summary>
        /// Used to retrieve or replace the object at the specified index.
        /// </summary>
        /// <param name="i">index</param>
        /// <returns>An instance of<see cref="System.Object"/></returns>
        object this[int i] {get;set;}
        
        #endregion
    }
}
