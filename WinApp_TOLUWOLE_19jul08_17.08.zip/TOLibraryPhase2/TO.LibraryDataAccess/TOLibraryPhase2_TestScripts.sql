/* TEST SCRIPTS - 07JUL08 */

USE library;

/* Test for AddAdultMember stored procedure */

DECLARE @ReturnValue1 smallint;
DECLARE @ReturnValue2 datetime;
--DECLARE @ReturnValue3 smallint;
BEGIN TRY
EXEC AddAdultMember 'Tope', 'Oluwole','O', '234 Main Street', 
	'Anytown', 'MA', '02345', '(555)555-5555', @ReturnValue1 OUTPUT,
	@ReturnValue2 OUTPUT;

END TRY
BEGIN CATCH
	PRINT 'Test AddAdultMember: FAIL -- CAUGHT Exception';
	PRINT 'Error Message: ' + ERROR_MESSAGE();
	PRINT 'Line Number: ' + CAST(ERROR_LINE() as varchar);
END CATCH
IF ( SELECT COUNT(*) 
     FROM member AS m INNER JOIN adult AS a ON m.member_no = a.member_no
     WHERE m.member_no = @ReturnValue1) = 1
      PRINT 'Test AddAdultMember: PASS -- ReturnValue = ' + CAST(@ReturnValue1 AS varchar);
ELSE
      PRINT 'Test AddAdultMember: FAIL -- ReturnValue = ' + CAST(@ReturnValue1 AS varchar);

SELECT * FROM member AS m INNER JOIN adult AS a ON
	m.member_no = a.member_no WHERE m.member_no = @ReturnValue1;

--SELECT * FROM member WHERE member_no IN ('10005', '10008', '10009');

--DELETE FROM adult WHERE member_no = '10011'
--DELETE FROM member WHERE member_no = '10011'

GO


/* Test for AddJuvenileMember stored procedure */
BEGIN TRY
DECLARE @Street varchar(15);
DECLARE @City varchar(15);
DECLARE @State char(2);
DECLARE @ZipCode char(10);
DECLARE @PhoneNumber char(13);
DECLARE @MyJuv smallint;
DECLARE @ExpDate datetime;

EXEC AddJuvenileMember 'Frank','Oluwole', NULL, '10011', '08/29/1999',
	@Street OUTPUT,
	@City OUTPUT,
	@State OUTPUT,
	@ZipCode OUTPUT,
	@PhoneNumber OUTPUT,
	@MyJuv OUTPUT,
	@ExpDate OUTPUT

END TRY
BEGIN CATCH
	PRINT 'Test AddJuvenileMember: FAIL -- CAUGHT Exception';
	PRINT 'Error Message: ' + ERROR_MESSAGE();
	PRINT 'Line Number: ' + CAST(ERROR_LINE() as varchar);
END CATCH
IF ( SELECT COUNT(*) 
     FROM member AS m INNER JOIN juvenile AS j ON m.member_no = j.member_no
     WHERE m.member_no = @MyJuv) = 1
      PRINT 'Test AddAdultMember: PASS -- ReturnValue = ' + CAST(@MyJuv AS varchar);
ELSE
      PRINT 'Test AddAdultMember: FAIL -- ReturnValue = ' + CAST(@MyJuv AS varchar);

SELECT * FROM member AS m INNER JOIN juvenile AS j ON
	m.member_no = j.member_no WHERE m.member_no = @MyJuv;

--SELECT * FROM member WHERE member_no IN ('10005', '10008', '10009');

--DELETE FROM juvenile WHERE member_no = 10012;
--DELETE FROM member WHERE member_no = 10012;

GO

/* Test for GetMember stored procedure */
USE library;

BEGIN TRY
DECLARE @MemberID smallint;
DECLARE @FirstName varchar(15);
DECLARE @LastName varchar(15);
DECLARE @MiddleInitial char(1);
DECLARE @Street varchar(15);
DECLARE @City varchar(15);
DECLARE @State char(2);
DECLARE @ZipCode char(10);
DECLARE @PhoneNumber char(13);
DECLARE @ExpDate datetime;

SET @MemberID = '10003';

EXEC GetMember @MemberID,
	@FirstName OUTPUT,
	@LastName OUTPUT,
	@MiddleInitial OUTPUT,
	@Street OUTPUT,
	@City OUTPUT,
	@State OUTPUT,
	@ZipCode OUTPUT,
	@PhoneNumber OUTPUT,
	@ExpDate OUTPUT

END TRY
BEGIN CATCH
	PRINT 'Test GetMember: FAIL -- CAUGHT Exception';
	PRINT 'Error Message: ' + ERROR_MESSAGE();
	PRINT 'Line Number: ' + CAST(ERROR_LINE() as varchar);
END CATCH
IF ( SELECT DISTINCT COUNT(@MemberID) 
     FROM member AS m 
     WHERE m.member_no = @MemberID) = 1

      PRINT 'Test GetMember: PASS -- ReturnValue = ' + CAST(@FirstName AS varchar)
		+ CAST(@LastName AS varchar) + CAST(@Street AS varchar)
ELSE
      PRINT 'Test GetMember: FAIL -- ReturnValue = ' + CAST(@FirstName AS varchar);

SELECT DISTINCT COUNT(@MemberID) AS Totalt
     FROM member AS m 
     WHERE m.member_no = @MemberID;

GO

/* Test for GetItem stored procedure */
USE library;

BEGIN TRY
DECLARE @Isbn int;
DECLARE @CopyNo smallint;
DECLARE @TitleNo int;
DECLARE @Title varchar(63);
DECLARE @Author varchar(31);
DECLARE @Translation char(8);
DECLARE @Cover char(8);
DECLARE @Loanable char(1);
DECLARE @MemberID smallint;
DECLARE @OutDate datetime;
DECLARE @DueDate datetime;

SET @Isbn = 63;
SET @CopyNo = 1;

EXEC GetItem @Isbn,
	@CopyNo,
	@TitleNo OUTPUT,
	@Title OUTPUT,
	@Author OUTPUT,
	@Translation OUTPUT,
	@Cover OUTPUT,
	@Loanable OUTPUT,
	@MemberID OUTPUT,
	@OutDate OUTPUT,
	@DueDate OUTPUT

END TRY
BEGIN CATCH
	PRINT 'Test GetItem: FAIL -- CAUGHT Exception';
	PRINT 'Error Message: ' + ERROR_MESSAGE();
	PRINT 'Line Number: ' + CAST(ERROR_LINE() as varchar);
END CATCH
IF ( SELECT COUNT(@Title)
     FROM title INNER JOIN item 
	ON title.title_no = item.title_no INNER JOIN loan
	ON item.title_no = loan.title_no
	WHERE item.isbn = @Isbn AND loan.isbn = @Isbn AND loan.copy_no = @CopyNo ) = 1

      PRINT 'Test GetItem: PASS -- ReturnValue = ' + CAST(@Title AS varchar)
		+ CAST(@Translation AS char) + CAST(@MemberID AS varchar)
ELSE
      PRINT 'Test GetItem: FAIL -- ReturnValue = ' + CAST(@Title AS varchar)
		+ CAST(@Translation AS char) + CAST(@MemberID AS varchar);

SELECT DISTINCT title.title_no, title.title, title.author, item.isbn, loan.copy_no,
	item.translation, item.cover, item.loanable, loan.member_no, loan.out_date, loan.due_date
     FROM title INNER JOIN item 
	ON title.title_no = item.title_no INNER JOIN loan
	ON item.title_no = loan.title_no
WHERE item.isbn = @Isbn AND loan.isbn = @Isbn 
ORDER BY item.isbn
--	WHERE item.isbn = @Isbn AND loan.isbn = @Isbn AND loan.copy_no = @CopyNo
GO

/* Test for GetItems stored procedure */
USE library;

BEGIN TRY
DECLARE @MemberID smallint;
DECLARE @Isbn int;
DECLARE @CopyNo smallint;
DECLARE @Title varchar(63);
DECLARE @Author varchar(31);
DECLARE @OutDate datetime;
DECLARE @DueDate datetime;

DECLARE @MyCount smallint;
SET @MemberID = 2;

EXEC GetItems 
	@MemberID,
	@Isbn OUTPUT,
	@CopyNo OUTPUT,
	@Author OUTPUT,
	@Title OUTPUT,
	@OutDate OUTPUT,
	@DueDate OUTPUT

END TRY
BEGIN CATCH
	PRINT 'Test GetItems: FAIL -- CAUGHT Exception';
	PRINT 'Error Message: ' + ERROR_MESSAGE();
	PRINT 'Line Number: ' + CAST(ERROR_LINE() as varchar);
END CATCH
IF ( SELECT COUNT(@Title)
		FROM loan INNER JOIN title 
		ON loan.title_no = title.title_no
		WHERE loan.member_no = @MemberID ) <= 4
	BEGIN

		SELECT @MyCount = COUNT(@Title) 
		FROM loan INNER JOIN title 
		ON loan.title_no = title.title_no
		WHERE loan.member_no = @MemberID

		PRINT 'Test GetItems: PASS -- ReturnValue = ' + CAST(@MyCount AS varchar)
	END
ELSE
	BEGIN	
		SELECT @MyCount = COUNT(@Title)
		FROM loan INNER JOIN title 
		ON loan.title_no = title.title_no
		WHERE loan.member_no = @MemberID
		PRINT 'Test GetItems: FAIL -- ReturnValue = ' + CAST(@MyCount AS varchar)
	END

		SELECT DISTINCT
			loan.isbn, 
			title.author, 
			title.title,
			loan.copy_no, 
			loan.out_date, 
			loan.due_date
		FROM loan INNER JOIN title 
		ON loan.title_no = title.title_no
		WHERE loan.member_no = 2


--		SELECT * 
--		FROM loan 
--		ORDER BY member_no
GO


USE library;

/* Test for CheckInItem stored procedure */

DECLARE @Isbn int;
DECLARE @CopyNo smallint;

SET @Isbn = 3;
SET @CopyNo = 1;

BEGIN TRY
EXEC CheckInItem @Isbn, @CopyNo;

END TRY
BEGIN CATCH
	PRINT 'Test CheckInItem: FAIL -- CAUGHT Exception';
	PRINT 'Error Message: ' + ERROR_MESSAGE();
	PRINT 'Line Number: ' + CAST(ERROR_LINE() as varchar);
END CATCH

--DELETE FROM loanhist WHERE 
--isbn = 3 AND copy_no = 1 AND title_no = 1 AND member_no = 325
--
--
--INSERT INTO loan (isbn, copy_no, title_no, member_no, out_date, due_date)
--	VALUES ('3','1','1','325','04/14/2008', '04/28/2008')

SELECT * FROM loan WHERE isbn = 3 AND copy_no = 1 AND title_no = 1 AND member_no = 325
SELECT * FROM loanhist
WHERE isbn = 3 AND copy_no = 1 AND title_no = 1 AND member_no = 325
GO

USE library;

/* Test for CheckOutItem stored procedure */

DECLARE @MemberID smallint;
DECLARE @Isbn int;
DECLARE @CopyNo smallint;

SET @MemberID = 325;
SET @Isbn = 3;
SET @CopyNo = 1;

BEGIN TRY
EXEC CheckOutItem @MemberID, @Isbn, @CopyNo;

END TRY
BEGIN CATCH
	PRINT 'Test CheckInItem: FAIL -- CAUGHT Exception';
	PRINT 'Error Message: ' + ERROR_MESSAGE();
	PRINT 'Line Number: ' + CAST(ERROR_LINE() as varchar);
END CATCH

--DELETE FROM loan WHERE 
--isbn = 3 AND copy_no = 1 AND title_no = 1 AND member_no = 325


SELECT * FROM loan WHERE isbn = 3 AND copy_no = 1 AND title_no = 1 AND member_no = 325

SELECT GETDATE() AS OutDate,
	DATEADD(week, 2, GETDATE()),
	copy.title_no
FROM copy
WHERE isbn = 3 AND copy_no = 1

GO