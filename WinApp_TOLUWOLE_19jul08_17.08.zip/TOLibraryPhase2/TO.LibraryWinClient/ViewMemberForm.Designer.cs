namespace TO.LibraryWinClient {
    partial class ViewMemberForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            this.textboxMemberID = new System.Windows.Forms.TextBox();
            this.labelMemberID = new System.Windows.Forms.Label();
            this.textboxExpiryDate = new System.Windows.Forms.TextBox();
            this.labelExpiryDate = new System.Windows.Forms.Label();
            this.textboxFirstName = new System.Windows.Forms.TextBox();
            this.textboxMiddleInit = new System.Windows.Forms.TextBox();
            this.textboxLastName = new System.Windows.Forms.TextBox();
            this.groupboxMemberExp = new System.Windows.Forms.GroupBox();
            this.labelStreet = new System.Windows.Forms.Label();
            this.textboxStreet = new System.Windows.Forms.TextBox();
            this.labelCity = new System.Windows.Forms.Label();
            this.textboxCity = new System.Windows.Forms.TextBox();
            this.labelState = new System.Windows.Forms.Label();
            this.textboxZipCode = new System.Windows.Forms.TextBox();
            this.labelZipCode = new System.Windows.Forms.Label();
            this.labelPhone = new System.Windows.Forms.Label();
            this.textboxPhone = new System.Windows.Forms.TextBox();
            this.groupboxAddress = new System.Windows.Forms.GroupBox();
            this.textboxState = new System.Windows.Forms.TextBox();
            this.labelMiddleInit = new System.Windows.Forms.Label();
            this.labelLastName = new System.Windows.Forms.Label();
            this.labelFirstName = new System.Windows.Forms.Label();
            this.groupboxMemberName = new System.Windows.Forms.GroupBox();
            this.buttonViewMemberInfo = new System.Windows.Forms.Button();
            this.datagridviewItemsOnLoan = new System.Windows.Forms.DataGridView();
            this.isbnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.copynoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.authorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.outdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.duedateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemsDataSet = new TO.LibraryEntities.ItemsDataSet();
            this.labelMemberAlert = new System.Windows.Forms.Label();
            this.buttonCheckInItems = new System.Windows.Forms.Button();
            this.errorproviderViewMember = new System.Windows.Forms.ErrorProvider(this.components);
            this.buttonCheckOutItem = new System.Windows.Forms.Button();
            this.textboxISBN = new System.Windows.Forms.TextBox();
            this.textboxCopyNumber = new System.Windows.Forms.TextBox();
            this.groupboxMemberExp.SuspendLayout();
            this.groupboxAddress.SuspendLayout();
            this.groupboxMemberName.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewItemsOnLoan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorproviderViewMember)).BeginInit();
            this.SuspendLayout();
            // 
            // textboxMemberID
            // 
            this.textboxMemberID.Location = new System.Drawing.Point(81, 15);
            this.textboxMemberID.Name = "textboxMemberID";
            this.textboxMemberID.Size = new System.Drawing.Size(105, 20);
            this.textboxMemberID.TabIndex = 3;
            this.textboxMemberID.Validated += new System.EventHandler(this.textboxMemberID_Validated);
            this.textboxMemberID.Validating += new System.ComponentModel.CancelEventHandler(this.textboxMemberID_Validating);
            this.textboxMemberID.ModifiedChanged += new System.EventHandler(this.textboxMemberID_ModifiedChanged);
            this.textboxMemberID.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textboxMemberID_KeyDown);
            // 
            // labelMemberID
            // 
            this.labelMemberID.AutoSize = true;
            this.labelMemberID.Location = new System.Drawing.Point(10, 17);
            this.labelMemberID.Name = "labelMemberID";
            this.labelMemberID.Size = new System.Drawing.Size(59, 13);
            this.labelMemberID.TabIndex = 2;
            this.labelMemberID.Text = "Member ID";
            // 
            // textboxExpiryDate
            // 
            this.textboxExpiryDate.Location = new System.Drawing.Point(272, 14);
            this.textboxExpiryDate.Name = "textboxExpiryDate";
            this.textboxExpiryDate.ReadOnly = true;
            this.textboxExpiryDate.Size = new System.Drawing.Size(100, 20);
            this.textboxExpiryDate.TabIndex = 5;
            this.textboxExpiryDate.Validated += new System.EventHandler(this.textboxExpiryDate_Validated);
            this.textboxExpiryDate.Validating += new System.ComponentModel.CancelEventHandler(this.textboxExpiryDate_Validating);
            // 
            // labelExpiryDate
            // 
            this.labelExpiryDate.AutoSize = true;
            this.labelExpiryDate.Location = new System.Drawing.Point(182, 16);
            this.labelExpiryDate.Name = "labelExpiryDate";
            this.labelExpiryDate.Size = new System.Drawing.Size(79, 13);
            this.labelExpiryDate.TabIndex = 4;
            this.labelExpiryDate.Text = "Expiration Date";
            // 
            // textboxFirstName
            // 
            this.textboxFirstName.Location = new System.Drawing.Point(77, 51);
            this.textboxFirstName.Name = "textboxFirstName";
            this.textboxFirstName.ReadOnly = true;
            this.textboxFirstName.Size = new System.Drawing.Size(109, 20);
            this.textboxFirstName.TabIndex = 7;
            // 
            // textboxMiddleInit
            // 
            this.textboxMiddleInit.Location = new System.Drawing.Point(196, 51);
            this.textboxMiddleInit.Name = "textboxMiddleInit";
            this.textboxMiddleInit.ReadOnly = true;
            this.textboxMiddleInit.Size = new System.Drawing.Size(23, 20);
            this.textboxMiddleInit.TabIndex = 8;
            // 
            // textboxLastName
            // 
            this.textboxLastName.Location = new System.Drawing.Point(77, 73);
            this.textboxLastName.Name = "textboxLastName";
            this.textboxLastName.ReadOnly = true;
            this.textboxLastName.Size = new System.Drawing.Size(109, 20);
            this.textboxLastName.TabIndex = 9;
            // 
            // groupboxMemberExp
            // 
            this.groupboxMemberExp.BackColor = System.Drawing.SystemColors.Control;
            this.groupboxMemberExp.Controls.Add(this.labelMemberID);
            this.groupboxMemberExp.Controls.Add(this.labelExpiryDate);
            this.groupboxMemberExp.Location = new System.Drawing.Point(6, 1);
            this.groupboxMemberExp.Name = "groupboxMemberExp";
            this.groupboxMemberExp.Size = new System.Drawing.Size(394, 42);
            this.groupboxMemberExp.TabIndex = 1;
            this.groupboxMemberExp.TabStop = false;
            // 
            // labelStreet
            // 
            this.labelStreet.AutoSize = true;
            this.labelStreet.Location = new System.Drawing.Point(14, 115);
            this.labelStreet.Name = "labelStreet";
            this.labelStreet.Size = new System.Drawing.Size(35, 13);
            this.labelStreet.TabIndex = 0;
            this.labelStreet.Text = "Street";
            // 
            // textboxStreet
            // 
            this.textboxStreet.Location = new System.Drawing.Point(54, 112);
            this.textboxStreet.Name = "textboxStreet";
            this.textboxStreet.ReadOnly = true;
            this.textboxStreet.Size = new System.Drawing.Size(132, 20);
            this.textboxStreet.TabIndex = 11;
            // 
            // labelCity
            // 
            this.labelCity.AutoSize = true;
            this.labelCity.Location = new System.Drawing.Point(9, 38);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(24, 13);
            this.labelCity.TabIndex = 0;
            this.labelCity.Text = "City";
            // 
            // textboxCity
            // 
            this.textboxCity.Location = new System.Drawing.Point(54, 134);
            this.textboxCity.Name = "textboxCity";
            this.textboxCity.ReadOnly = true;
            this.textboxCity.Size = new System.Drawing.Size(102, 20);
            this.textboxCity.TabIndex = 12;
            // 
            // labelState
            // 
            this.labelState.AutoSize = true;
            this.labelState.Location = new System.Drawing.Point(162, 137);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(32, 13);
            this.labelState.TabIndex = 0;
            this.labelState.Text = "State";
            // 
            // textboxZipCode
            // 
            this.textboxZipCode.Location = new System.Drawing.Point(294, 134);
            this.textboxZipCode.Name = "textboxZipCode";
            this.textboxZipCode.ReadOnly = true;
            this.textboxZipCode.Size = new System.Drawing.Size(78, 20);
            this.textboxZipCode.TabIndex = 16;
            // 
            // labelZipCode
            // 
            this.labelZipCode.AutoSize = true;
            this.labelZipCode.Location = new System.Drawing.Point(269, 138);
            this.labelZipCode.Name = "labelZipCode";
            this.labelZipCode.Size = new System.Drawing.Size(22, 13);
            this.labelZipCode.TabIndex = 0;
            this.labelZipCode.Text = "Zip";
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Location = new System.Drawing.Point(14, 159);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(58, 13);
            this.labelPhone.TabIndex = 0;
            this.labelPhone.Text = "Telephone";
            // 
            // textboxPhone
            // 
            this.textboxPhone.Location = new System.Drawing.Point(77, 156);
            this.textboxPhone.Name = "textboxPhone";
            this.textboxPhone.ReadOnly = true;
            this.textboxPhone.Size = new System.Drawing.Size(109, 20);
            this.textboxPhone.TabIndex = 17;
            // 
            // groupboxAddress
            // 
            this.groupboxAddress.Controls.Add(this.textboxState);
            this.groupboxAddress.Controls.Add(this.labelCity);
            this.groupboxAddress.Location = new System.Drawing.Point(6, 99);
            this.groupboxAddress.Name = "groupboxAddress";
            this.groupboxAddress.Size = new System.Drawing.Size(394, 87);
            this.groupboxAddress.TabIndex = 12;
            this.groupboxAddress.TabStop = false;
            // 
            // textboxState
            // 
            this.textboxState.Location = new System.Drawing.Point(190, 35);
            this.textboxState.Name = "textboxState";
            this.textboxState.ReadOnly = true;
            this.textboxState.Size = new System.Drawing.Size(37, 20);
            this.textboxState.TabIndex = 28;
            // 
            // labelMiddleInit
            // 
            this.labelMiddleInit.AutoSize = true;
            this.labelMiddleInit.Location = new System.Drawing.Point(219, 14);
            this.labelMiddleInit.Name = "labelMiddleInit";
            this.labelMiddleInit.Size = new System.Drawing.Size(65, 13);
            this.labelMiddleInit.TabIndex = 9;
            this.labelMiddleInit.Text = "Middle Initial";
            // 
            // labelLastName
            // 
            this.labelLastName.AutoSize = true;
            this.labelLastName.Location = new System.Drawing.Point(9, 36);
            this.labelLastName.Name = "labelLastName";
            this.labelLastName.Size = new System.Drawing.Size(58, 13);
            this.labelLastName.TabIndex = 10;
            this.labelLastName.Text = "Last Name";
            // 
            // labelFirstName
            // 
            this.labelFirstName.AutoSize = true;
            this.labelFirstName.Location = new System.Drawing.Point(9, 14);
            this.labelFirstName.Name = "labelFirstName";
            this.labelFirstName.Size = new System.Drawing.Size(57, 13);
            this.labelFirstName.TabIndex = 4;
            this.labelFirstName.Text = "First Name";
            // 
            // groupboxMemberName
            // 
            this.groupboxMemberName.Controls.Add(this.labelFirstName);
            this.groupboxMemberName.Controls.Add(this.labelLastName);
            this.groupboxMemberName.Controls.Add(this.labelMiddleInit);
            this.groupboxMemberName.Location = new System.Drawing.Point(6, 40);
            this.groupboxMemberName.Name = "groupboxMemberName";
            this.groupboxMemberName.Size = new System.Drawing.Size(394, 61);
            this.groupboxMemberName.TabIndex = 6;
            this.groupboxMemberName.TabStop = false;
            // 
            // buttonViewMemberInfo
            // 
            this.buttonViewMemberInfo.BackColor = System.Drawing.SystemColors.Control;
            this.buttonViewMemberInfo.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonViewMemberInfo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonViewMemberInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonViewMemberInfo.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.buttonViewMemberInfo.Location = new System.Drawing.Point(417, 8);
            this.buttonViewMemberInfo.Name = "buttonViewMemberInfo";
            this.buttonViewMemberInfo.Size = new System.Drawing.Size(182, 22);
            this.buttonViewMemberInfo.TabIndex = 19;
            this.buttonViewMemberInfo.Text = "View Member Information";
            this.buttonViewMemberInfo.UseVisualStyleBackColor = false;
            this.buttonViewMemberInfo.Click += new System.EventHandler(this.buttonViewMemberInfo_Click);
            // 
            // datagridviewItemsOnLoan
            // 
            this.datagridviewItemsOnLoan.AllowUserToAddRows = false;
            this.datagridviewItemsOnLoan.AllowUserToDeleteRows = false;
            this.datagridviewItemsOnLoan.AllowUserToOrderColumns = true;
            this.datagridviewItemsOnLoan.AutoGenerateColumns = false;
            this.datagridviewItemsOnLoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewItemsOnLoan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.isbnDataGridViewTextBoxColumn,
            this.copynoDataGridViewTextBoxColumn,
            this.titleDataGridViewTextBoxColumn,
            this.authorDataGridViewTextBoxColumn,
            this.outdateDataGridViewTextBoxColumn,
            this.duedateDataGridViewTextBoxColumn});
            this.datagridviewItemsOnLoan.DataSource = this.itemsBindingSource;
            this.datagridviewItemsOnLoan.Location = new System.Drawing.Point(6, 192);
            this.datagridviewItemsOnLoan.Name = "datagridviewItemsOnLoan";
            this.datagridviewItemsOnLoan.ReadOnly = true;
            this.datagridviewItemsOnLoan.Size = new System.Drawing.Size(593, 133);
            this.datagridviewItemsOnLoan.TabIndex = 22;
            // 
            // isbnDataGridViewTextBoxColumn
            // 
            this.isbnDataGridViewTextBoxColumn.DataPropertyName = "isbn";
            this.isbnDataGridViewTextBoxColumn.HeaderText = "ISBN";
            this.isbnDataGridViewTextBoxColumn.Name = "isbnDataGridViewTextBoxColumn";
            this.isbnDataGridViewTextBoxColumn.ReadOnly = true;
            this.isbnDataGridViewTextBoxColumn.Width = 50;
            // 
            // copynoDataGridViewTextBoxColumn
            // 
            this.copynoDataGridViewTextBoxColumn.DataPropertyName = "copy_no";
            this.copynoDataGridViewTextBoxColumn.HeaderText = "Copy#";
            this.copynoDataGridViewTextBoxColumn.Name = "copynoDataGridViewTextBoxColumn";
            this.copynoDataGridViewTextBoxColumn.ReadOnly = true;
            this.copynoDataGridViewTextBoxColumn.Width = 40;
            // 
            // titleDataGridViewTextBoxColumn
            // 
            this.titleDataGridViewTextBoxColumn.DataPropertyName = "title";
            this.titleDataGridViewTextBoxColumn.HeaderText = "Title";
            this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
            this.titleDataGridViewTextBoxColumn.ReadOnly = true;
            this.titleDataGridViewTextBoxColumn.Width = 140;
            // 
            // authorDataGridViewTextBoxColumn
            // 
            this.authorDataGridViewTextBoxColumn.DataPropertyName = "author";
            this.authorDataGridViewTextBoxColumn.HeaderText = "author";
            this.authorDataGridViewTextBoxColumn.Name = "authorDataGridViewTextBoxColumn";
            this.authorDataGridViewTextBoxColumn.ReadOnly = true;
            this.authorDataGridViewTextBoxColumn.Width = 120;
            // 
            // outdateDataGridViewTextBoxColumn
            // 
            this.outdateDataGridViewTextBoxColumn.DataPropertyName = "out_date";
            this.outdateDataGridViewTextBoxColumn.HeaderText = "Out Date";
            this.outdateDataGridViewTextBoxColumn.Name = "outdateDataGridViewTextBoxColumn";
            this.outdateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // duedateDataGridViewTextBoxColumn
            // 
            this.duedateDataGridViewTextBoxColumn.DataPropertyName = "due_date";
            this.duedateDataGridViewTextBoxColumn.HeaderText = "Due Date";
            this.duedateDataGridViewTextBoxColumn.Name = "duedateDataGridViewTextBoxColumn";
            this.duedateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // itemsBindingSource
            // 
            this.itemsBindingSource.DataMember = "Items";
            this.itemsBindingSource.DataSource = this.itemsDataSet;
            // 
            // itemsDataSet
            // 
            this.itemsDataSet.DataSetName = "ItemsDataSet";
            this.itemsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // labelMemberAlert
            // 
            this.labelMemberAlert.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMemberAlert.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.labelMemberAlert.Location = new System.Drawing.Point(417, 33);
            this.labelMemberAlert.Name = "labelMemberAlert";
            this.labelMemberAlert.Size = new System.Drawing.Size(182, 78);
            this.labelMemberAlert.TabIndex = 20;
            this.labelMemberAlert.Text = "message board";
            // 
            // buttonCheckInItems
            // 
            this.buttonCheckInItems.BackColor = System.Drawing.SystemColors.Control;
            this.buttonCheckInItems.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonCheckInItems.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCheckInItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCheckInItems.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.buttonCheckInItems.Location = new System.Drawing.Point(417, 162);
            this.buttonCheckInItems.Name = "buttonCheckInItems";
            this.buttonCheckInItems.Size = new System.Drawing.Size(182, 24);
            this.buttonCheckInItems.TabIndex = 22;
            this.buttonCheckInItems.Text = "Check In Item";
            this.buttonCheckInItems.UseVisualStyleBackColor = false;
            this.buttonCheckInItems.Click += new System.EventHandler(this.buttonCheckInItems_Click);
            this.buttonCheckInItems.MouseHover += new System.EventHandler(this.buttonCheckInItems_MouseHover);
            // 
            // errorproviderViewMember
            // 
            this.errorproviderViewMember.ContainerControl = this;
            // 
            // buttonCheckOutItem
            // 
            this.buttonCheckOutItem.BackColor = System.Drawing.SystemColors.Control;
            this.buttonCheckOutItem.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonCheckOutItem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCheckOutItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCheckOutItem.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.buttonCheckOutItem.Location = new System.Drawing.Point(417, 137);
            this.buttonCheckOutItem.Name = "buttonCheckOutItem";
            this.buttonCheckOutItem.Size = new System.Drawing.Size(182, 22);
            this.buttonCheckOutItem.TabIndex = 22;
            this.buttonCheckOutItem.Text = "Check Out Item";
            this.buttonCheckOutItem.UseVisualStyleBackColor = false;
            this.buttonCheckOutItem.Click += new System.EventHandler(this.buttonCheckOutItem_Click);
            this.buttonCheckOutItem.MouseHover += new System.EventHandler(this.buttonCheckOutItem_MouseHover);
            // 
            // textboxISBN
            // 
            this.textboxISBN.Location = new System.Drawing.Point(417, 114);
            this.textboxISBN.Name = "textboxISBN";
            this.textboxISBN.Size = new System.Drawing.Size(119, 20);
            this.textboxISBN.TabIndex = 21;
            this.textboxISBN.Validated += new System.EventHandler(this.textboxISBN_Validated);
            this.textboxISBN.Validating += new System.ComponentModel.CancelEventHandler(this.textboxISBN_Validating);
            this.textboxISBN.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textboxISBN_KeyDown);
            // 
            // textboxCopyNumber
            // 
            this.textboxCopyNumber.Location = new System.Drawing.Point(542, 114);
            this.textboxCopyNumber.Name = "textboxCopyNumber";
            this.textboxCopyNumber.Size = new System.Drawing.Size(57, 20);
            this.textboxCopyNumber.TabIndex = 22;
            this.textboxCopyNumber.Validated += new System.EventHandler(this.textboxCopyNumber_Validated);
            this.textboxCopyNumber.Validating += new System.ComponentModel.CancelEventHandler(this.textboxCopyNumber_Validating);
            this.textboxCopyNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textboxCopyNumber_KeyDown);
            // 
            // ViewMemberForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 337);
            this.Controls.Add(this.textboxCopyNumber);
            this.Controls.Add(this.textboxISBN);
            this.Controls.Add(this.buttonCheckOutItem);
            this.Controls.Add(this.buttonCheckInItems);
            this.Controls.Add(this.labelMemberAlert);
            this.Controls.Add(this.datagridviewItemsOnLoan);
            this.Controls.Add(this.buttonViewMemberInfo);
            this.Controls.Add(this.textboxPhone);
            this.Controls.Add(this.labelPhone);
            this.Controls.Add(this.labelZipCode);
            this.Controls.Add(this.textboxZipCode);
            this.Controls.Add(this.labelState);
            this.Controls.Add(this.textboxCity);
            this.Controls.Add(this.textboxStreet);
            this.Controls.Add(this.labelStreet);
            this.Controls.Add(this.textboxLastName);
            this.Controls.Add(this.textboxMiddleInit);
            this.Controls.Add(this.textboxFirstName);
            this.Controls.Add(this.textboxExpiryDate);
            this.Controls.Add(this.textboxMemberID);
            this.Controls.Add(this.groupboxMemberExp);
            this.Controls.Add(this.groupboxMemberName);
            this.Controls.Add(this.groupboxAddress);
            this.Name = "ViewMemberForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = " View Member";
            this.Load += new System.EventHandler(this.ViewMemberForm_Load);
            this.groupboxMemberExp.ResumeLayout(false);
            this.groupboxMemberExp.PerformLayout();
            this.groupboxAddress.ResumeLayout(false);
            this.groupboxAddress.PerformLayout();
            this.groupboxMemberName.ResumeLayout(false);
            this.groupboxMemberName.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewItemsOnLoan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorproviderViewMember)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textboxMemberID;
        private System.Windows.Forms.Label labelMemberID;
        private System.Windows.Forms.TextBox textboxExpiryDate;
        private System.Windows.Forms.Label labelExpiryDate;
        private System.Windows.Forms.TextBox textboxFirstName;
        private System.Windows.Forms.TextBox textboxMiddleInit;
        private System.Windows.Forms.TextBox textboxLastName;
        private System.Windows.Forms.GroupBox groupboxMemberExp;
        private System.Windows.Forms.Label labelStreet;
        private System.Windows.Forms.TextBox textboxStreet;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.TextBox textboxCity;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.TextBox textboxZipCode;
        private System.Windows.Forms.Label labelZipCode;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.TextBox textboxPhone;
        private System.Windows.Forms.GroupBox groupboxAddress;
        private System.Windows.Forms.Label labelMiddleInit;
        private System.Windows.Forms.Label labelLastName;
        private System.Windows.Forms.Label labelFirstName;
        private System.Windows.Forms.GroupBox groupboxMemberName;
        private System.Windows.Forms.Button buttonViewMemberInfo;
        private System.Windows.Forms.DataGridView datagridviewItemsOnLoan;
        private System.Windows.Forms.Label labelMemberAlert;
        private System.Windows.Forms.Button buttonCheckInItems;
        private System.Windows.Forms.BindingSource itemsBindingSource;
        private TO.LibraryEntities.ItemsDataSet itemsDataSet;
        private System.Windows.Forms.DataGridViewTextBoxColumn isbnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn copynoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn authorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn outdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn duedateDataGridViewTextBoxColumn;
        private System.Windows.Forms.ErrorProvider errorproviderViewMember;
        private System.Windows.Forms.TextBox textboxState;
        private System.Windows.Forms.Button buttonCheckOutItem;
        private System.Windows.Forms.TextBox textboxCopyNumber;
        private System.Windows.Forms.TextBox textboxISBN;
    }
}