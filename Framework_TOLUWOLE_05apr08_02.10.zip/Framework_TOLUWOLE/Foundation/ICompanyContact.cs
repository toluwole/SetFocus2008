using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation {
 
    /// <summary>
    /// This interface details required properties for 
    /// abstractions where a contact is available.
    /// </summary>
    interface ICompanyContact {

        #region Properties

        /// <summary>
        /// Read and write Interface property ID.
        /// </summary>
        int ID { get;set;}
        /// <summary>
        /// Read and write Interface property CompanyName.
        /// </summary>
        string CompanyName { get;set;}
        /// <summary>
        /// Read and write Interface property ContactName.
        /// </summary>
        string ContactName { get;set;}
        /// <summary>
        /// Read and write Interface property ContactTitle.
        /// </summary>
        string ContactTitle { get;set;}

        #endregion
    }
}
