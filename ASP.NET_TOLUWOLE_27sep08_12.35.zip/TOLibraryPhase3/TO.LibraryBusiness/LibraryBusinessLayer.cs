using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.IO;
using TO.LibraryEntities;
using TO.LibraryDataAccess;


namespace TO.LibraryBusiness {
    /// <summary>
    /// Business layer for library solution
    /// </summary>
    public class LibraryBusinessLayer {


        #region Fields

        /// <summary>
        /// View Member column fields
        /// </summary>
        private string columnTitle;
        private string columnAuthor;
        private string columnISBN;
        private string columnCopyNumber;
        private string columnCheckOutDate;
        private string columnDueDate;

        #endregion

        #region Constructors

        /// <summary>
        ///  Default constructor
        /// </summary>
        public LibraryBusinessLayer() {

        }

        #endregion

        #region Properties
        
        /// <summary>
        /// View Member columnTitle property.
        /// </summary>
        public string ColumnTitle {
            get { return columnTitle; }
            set { columnTitle = value; }
        }

        /// <summary>
        /// View Member ColumnAuthor property.
        /// </summary>
        public string ColumnAuthor {
            get { return columnAuthor; }
            set { columnAuthor = value; }
        }

        /// <summary>
        /// View Member ColumnISBN property.
        /// </summary>
        public string ColumnISBN {
            get { return columnISBN; }
            set { columnISBN = value; }
        }

        /// <summary>
        /// View Member ColumnCopyNumber property.
        /// </summary>
        public string ColumnCopyNumber {
            get { return columnCopyNumber; }
            set { columnCopyNumber = value; }
        }
        #endregion

        /// <summary>
        /// View Member ColumnCheckOutDate property.
        /// </summary>
        public string ColumnCheckOutDate {
            get { return columnCheckOutDate; }
            set { columnCheckOutDate = value; }
        }

        /// <summary>
        /// View Member ColumnDueDate property.
        /// </summary>
        public string ColumnDueDate {
            get { return columnDueDate; }
            set { columnDueDate = value; }
        }

        #region Events
        
        #endregion

        #region Methods

        /// <summary>
        /// Gets member information based on valid member ID.
        /// </summary>
        /// <param name="memberId">Member ID used to return member info.</param>
        /// <returns></returns>
        public TO.LibraryEntities.LibraryEntities.Member GetInformation(short memberId)
        {

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess();

            // Calls the GetMember() method and passes a member id.

            TO.LibraryEntities.LibraryEntities.Member myMember = lda.GetMember(memberId);
            
            // Returns existing member.
            return myMember;
         
        }

        /// <summary>
        /// Checks if a member is a juvenile.
        /// </summary>
        /// <param name="memberId">Member ID used to return member info.</param>
        public bool IsJuvenile(short memberId) {

            int memberAge = 0;

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess();

            // Calls the CheckIDJuvenile() method and returns true or false.
            memberAge = lda.CheckIDJuvenile(memberId);

            // Evaluates age for adult membership.
            if (memberAge>=18) {
                return true;
            } else {
                return false;
            }

        }

        /// <summary>
        /// Converts a juvenile member to an adult member
        /// </summary>
        /// <param name="memberId">Member ID</param>
        public void MakeAdult(TO.LibraryEntities.LibraryEntities.Member memberId) {

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess();

            // Calls the Juvenile2Adult() method and passes a member id.
            lda.Juvenile2Adult(memberId);
        }

        /// <summary>
        /// Renew member's card expiry date.
        /// </summary>
        /// <param name="memberId">Member ID used to return member info.</param>
        public void SetExpiryDate(short memberId) {

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess();

            // Calls the RenewCard() method and passes a member id.
            lda.RenewCard(memberId);

        }

        /// <summary>
        /// Gets item information based on valid ISBN and Copy Number.
        /// </summary>
        /// <param name="itemISBN">Item ISBN</param>
        /// <param name="itemCopyNumber">Copy Number</param>
        /// <returns>An instance of<see cref="TO.LibraryEntities.LibraryEntities.Item"/></returns>
        public TO.LibraryEntities.LibraryEntities.Item GetItemInfo(int itemISBN, short itemCopyNumber) {

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess();

            TO.LibraryEntities.LibraryEntities.Item myItem = lda.GetItem(itemISBN, itemCopyNumber);

            // Return existing item.
            return myItem;
        
        }

        /// <summary>
        /// Gets list of Member items on loan for use on presentation layer.
        /// </summary>
        /// <param name="memberID">Member ID used to return checked out items.</param>
        /// <returns>An instance of<see cref="TO.LibraryEntities.ItemsDataSet"/></returns>
        public ItemsDataSet GetViewMemberGrid(short memberID) {

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess(); 
    
            // Calls the GetItems() method and passes a member id.
            ItemsDataSet myItemsDataSet = lda.GetItems(memberID);

            // Returns the retrieved member.
            return myItemsDataSet;
        }

        /// <summary>
        /// Checks out item whose ISBN and copy number are specified to the
        /// Member whose member ID is specified.
        /// </summary>
        /// <param name="memberID">Member ID of member checking out item.</param>
        /// <param name="itemISBN">ISBN of item being checked out.</param>
        /// <param name="itemCopyNumber">Copy Number of item being checked out.</param>
        public void GetCheckOutItem(short memberID, int itemISBN, short itemCopyNumber) {

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess();

            // Checks out item.
            lda.CheckOutItem(memberID, itemISBN, itemCopyNumber);
        
        }

        /// <summary>
        /// Checks in item whose ISBN and copy number are specified.
        /// </summary>
        /// <param name="itemISBN">ISBN of item being checked in.</param>
        /// <param name="itemCopyNumber">Copy Number of item being checked out.</param>
        public void SetCheckInItem(int itemISBN, short itemCopyNumber) {

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess();

            // Checks in item
            lda.CheckInItem(itemISBN, itemCopyNumber);
        }

        /// <summary>
        /// Adds an adult member to the database.
        /// </summary>
        /// <param name="adultFirstName">Adult First Name</param>
        /// <param name="adultLastName">Adult Last Name</param>
        /// <param name="adultMidInit">Adult Middle Initial</param>
        /// <param name="street">Street</param>
        /// <param name="city">City</param>
        /// <param name="state">State</param>
        /// <param name="zipCode">Zip Code</param>
        /// <param name="phoneNumber">Phone Number</param>
        /// <returns>An instance of<see cref="TO.LibraryEntities.LibraryEntities.AdultMember"/></returns>
        public TO.LibraryEntities.LibraryEntities.AdultMember AddAdultMember(string adultFirstName,
            string adultLastName, string adultMidInit, 
            string street, string city, string state,
            string zipCode,string phoneNumber) {

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess();

            // Create object representing member to be added.
            TO.LibraryEntities.LibraryEntities.AdultMember myMember = new TO.LibraryEntities.LibraryEntities.AdultMember();

            // Fill member properties.
            myMember.FirstName = adultFirstName;
            myMember.LastName = adultLastName;
            myMember.MiddleInitial = adultMidInit;
            myMember.Street = street;
            myMember.City = city;
            myMember.State = state;
            myMember.ZipCode = zipCode;
            myMember.PhoneNumber = phoneNumber;
            
            // Adds new member.
            lda.AddMember(myMember);

            // Returns new adult member added.
            return myMember;
        }

        /// <summary>
        /// Add a juvenile member to the database.
        /// </summary>
        /// <param name="adultMemberID">Sponsoring Adult Member ID</param>
        /// <param name="juvenileFirstName">Juvenile Fist Name</param>
        /// <param name="juvenileLastName">Juvenile Last Name</param>
        /// <param name="juvenileMidInit">Juvenile Middle Initial</param>
        /// <param name="birthDate">Birth Date</param>
        /// <returns>An instance of<see cref="TO.LibraryEntities.LibraryEntities.JuvenileMember"/></returns>
        public TO.LibraryEntities.LibraryEntities.JuvenileMember AddJuvenileMember(short adultMemberID,
            string juvenileFirstName, string juvenileLastName, 
            string juvenileMidInit, DateTime birthDate) {

            // Create a library data access object
            TO.LibraryDataAccess.LibraryDataAccess lda = new TO.LibraryDataAccess.LibraryDataAccess();

            // Create object representing member to be added.
            TO.LibraryEntities.LibraryEntities.JuvenileMember myMember = new TO.LibraryEntities.LibraryEntities.JuvenileMember();

            // Fill member properties.
            myMember.AdultMemberID = adultMemberID;
            myMember.FirstName = juvenileFirstName;
            myMember.LastName = juvenileLastName;
            myMember.MiddleInitial = juvenileMidInit;
            myMember.BirthDate = birthDate;

            // Adds new member.
            lda.AddMember(myMember);

            // Returns new juvenile member added.
            return myMember;
        }
        #endregion



        
    }
    /// <summary>
    /// Class to build States data list.
    /// </summary>
    public static class StatesData {

        /// <summary>
        /// Method that retrieve the dataset of states.
        /// </summary>
        /// <returns>An instance of <see cref="System.Data.DataSet"/></returns>
        public static DataSet GetStates() {
            // create a new dataset
            DataSet ds = new DataSet("StatesData");

            // read the data from the xml file...
            // note: look at Solution Explorer and bring up 
            // the properties for the states.xml file in the properties
            // window. notice that there is a setting to copy the file
            // to the output directory. this insures thet the states.xml
            // file is in the same folder as the executable.

            
            try {
                //ds.ReadXml("States.xml");
                // find the file path for States.xml

                string filepath = System.IO.Path.GetDirectoryName(@"/TOLibraryPhase3/Bin/");

                // read xml into dataset
                ds.ReadXml(filepath + "States.xml", XmlReadMode.InferSchema);
               

            } catch (FileNotFoundException) {
                
                throw;
            }
            
            return ds;
        }
    }
}
