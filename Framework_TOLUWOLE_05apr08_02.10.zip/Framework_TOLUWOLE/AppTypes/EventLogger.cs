using System;
using System.Collections.Generic;
using System.Text;

namespace AppTypes {
    /// <summary>
    /// Handles CollectionModified events raised by the product class.
    /// </summary>
    class EventLogger {

        #region Fields

        /// <summary>
        /// Field declaration.
        /// </summary>
        private string lastEventDetails = ""; 

        #endregion

        /// <summary>
        /// Override of ToString method.
        /// </summary>
        /// <returns>An instance of <see cref="System.String"/></returns>
        public override string ToString() {
            return lastEventDetails;
        }

        /// <summary>
        /// Registers to receive CollectionModified events from
        /// the supplied Products instance.
        /// </summary>
        /// <param name="p"></param>
        public void Register(Products p) {
            
        }

        /// <summary>
        /// Informs the provided Products class that it willl no
        /// longer handle CollectionModified events.
        /// </summary>
        /// <param name="p"></param>
        public void ClearRegistration(Products p) {
        }

    }
}
