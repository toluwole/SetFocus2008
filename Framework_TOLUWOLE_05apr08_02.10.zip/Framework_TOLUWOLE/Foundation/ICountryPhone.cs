using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation {
    /// <summary>
    /// This interface details required properties for 
    /// abstractions with phone numbers.
    /// </summary>
    interface ICountryPhone {

        #region Properties

        /// <summary>
        /// Read and write Interface properties
        /// </summary>
        string Country { get;set;}
        string Phone { get;set;}
        string Fax { get;set;}

        #endregion
    }
}
