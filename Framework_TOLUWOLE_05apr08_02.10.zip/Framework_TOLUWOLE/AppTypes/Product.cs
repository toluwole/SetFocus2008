using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Foundation;
using DataAccess;


namespace AppTypes {

    /// <summary>
    /// Responsible for representing the various products and services
    /// bought or sold by the company.
    /// </summary>
    [DeveloperInfoAttribute("Temitope Oluwole", Date = "04mar08", Title = "AppTypes.Product Class")]
    [CustomDescriptionAttribute("Responsible for representing the various products and services" +
      "bought or sold by the company.")]
    [Serializable]
    class Product: IComparable<Product> {

        #region Fields and Properties

        /// <summary>
        /// Field declaration.
        /// </summary>
        int id;

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public int ID {
            get { return id; }
            set {
                if ((value >= 1) && (value <= 9999))
                    id = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a value from 1 to 9999 for ID.");
            }
        }

        /// <summary>
        /// Field declaration.
        /// </summary>
        string productName;

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string ProductName {
            get { return productName; }
            set {
                if (value == null)
                    throw new NullReferenceException("ProductName cannot be null");
                if ((value.Length >= 1) && (value.Length <= 40))
                    productName = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a ProductName of at least one " +
                    "character and no longer than 40.");
            }
        }

        /// <summary>
        /// Field declarations.
        /// </summary>
        int supplierID, categoryID;

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual int SupplierID {
            get { return supplierID; }
            set {
                if ((value >= 1) && (value <= 99999))
                    supplierID = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a value from 1 to 99999 for SupplierID.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual int CategoryID {
            get { return categoryID; }
            set {
                if (value >=1)
                    categoryID = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a CategoryID of at least 1 " +
                    "or greater.");
            }
        }

        /// <summary>
        /// Field declaration.
        /// </summary>
        string quantityPerUnit;

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string QuantityPerUnit {
            get { return quantityPerUnit; }
            set {
                if (value == null)
                    throw new NullReferenceException("QuantityPerUnit cannot be null");
                if ((value.Length >= 1) && (value.Length <= 20))
                    quantityPerUnit = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a QuantityPerUnit of at least one " +
                    "character and no longer than 20.");
            }
        }

        /// <summary>
        /// Field declaration.
        /// </summary>
        decimal unitPrice;

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual decimal UnitPrice {
            get { return unitPrice; }
            set {
                if (value >= 0)
                    unitPrice = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a UnitPrice of at least 0 " +
                    "or greater.");
            }
        }

        /// <summary>
        /// Field declarations.
        /// </summary>
        int unitsInStock, unitsOnOrder, reOrderLevel;

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual int UnitsInStock {
            get { return unitsInStock; }
            set {
                if (value >= 0)
                    unitsInStock = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a UnitsInStock of at 0 " +
                    "or greater.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual int UnitsOnOrder {
            get { return unitsOnOrder; }
            set {
                if (value >= 0)
                    unitsOnOrder = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a UnitsOnOrder of at 0 " +
                    "or greater.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual int ReOrderLevel {
            get { return reOrderLevel; }
            set {
                if (value >= 0)
                    reOrderLevel = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a ReOrderLevel of at 0 " +
                    "or greater.");
            }
        } 
        #endregion

        #region Constructors


        /// <summary>
        /// Default constructor.
        /// </summary>
        public Product() {

        }

        /// <summary>
        /// Full parameters constructor
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="ProductName">ProductName</param>
        /// <param name="SupplierID">SupplierID</param>
        /// <param name="CategoryID">CategoryID</param>
        /// <param name="QuantityPerUnit">QuantityPerUnit</param>
        /// <param name="UnitPrice">UnitPrice</param>
        /// <param name="UnitsInStock">UnitsInStock</param>
        /// <param name="UnitsOnOrder">UnitsOnOrder</param>
        /// <param name="ReOrderLevel">ReOrderLevel</param>
        public Product(int ID, string ProductName, int SupplierID,int CategoryID, 
            string QuantityPerUnit, decimal UnitPrice, int UnitsInStock,
            int UnitsOnOrder, int ReOrderLevel) {

            this.ID = ID;
            this.ProductName = ProductName;
            this.SupplierID = SupplierID;
            this.CategoryID = CategoryID;
            this.QuantityPerUnit = QuantityPerUnit;
            this.UnitPrice = UnitPrice;
            this.UnitsInStock = UnitsInStock;
            this.UnitsOnOrder = UnitsOnOrder;
            this.ReOrderLevel = ReOrderLevel;
        }

        /// <summary>
        /// Constructor with ProductStruct parameter
        /// </summary>
        /// <param name="p">p</param>
        public Product(ProductStruct p) {

        }

        #endregion


        #region Methods

        /// <summary>
        /// Override of ToString method using StringBuilder.
        /// </summary>
        /// <returns>An instance of <see cref="System.String"/></returns>
        public override string ToString() {

            StringBuilder anSB = new StringBuilder("ProductID:");
            anSB.Append(ID);
            anSB.Append(" ProductName:");
            anSB.Append(ProductName);
            anSB.Append(" CategoryID:");
            anSB.Append(CategoryID);
            anSB.Append(" SupplierID:");
            anSB.Append(SupplierID);

            return anSB.ToString();
        }

        /// <summary>
        /// Provides an enumerator that allows for easy enumeration over
        /// a set of string values that provide information about the 
        /// current Product object.
        /// </summary>
        /// <returns>An instance of<see cref="System.String"/></returns>
        public IEnumerable PropertyAndValuesCollection() {
            yield return "ID: " + this.ID.ToString();
            yield return "ProductName: " + this.ProductName;
            yield return "SupplierID: " + this.SupplierID.ToString();
            yield return "CategoryID: " + this.CategoryID.ToString(); ;
            yield return "QuantityPerUnit: " + this.QuantityPerUnit;
            yield return String.Format("UnitPrice: {0:c}", this.UnitPrice);
            yield return "UnitsInStock: " + this.UnitsInStock.ToString();
            yield return "UnitsOnOrder: " + this.UnitsOnOrder.ToString();
            yield return "ReOrderLevel: " + this.ReOrderLevel.ToString();

        }

        /// <summary>
        /// Overrides the Equals methods to return true if the two objects
        /// have the same ID.
        /// </summary>
        /// <param name="obj">object to be compared</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        public override bool Equals(object obj) {
            //returns false if obj is null or is a type mismatch.
            if (obj == null || GetType() != obj.GetType()) return false;
            // explictly cast obj for comparision.
            Product p = (Product)obj;
            return this.ID == p.ID;
        }

        /// <summary>
        /// Overloading == operator using the Equals method.
        /// </summary>
        /// <param name="p1">Product to compare</param>
        /// <param name="p2">Product compared to</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        static public bool operator ==(Product p1, Product p2) {
            // Return false if p1 is null.
            if ((object)p1 == null) return false;
            // Equals method compares.
            return p1.Equals(p2);
        }

        /// <summary>
        /// Overloading != operator using the Equals method.
        /// </summary>
        /// <param name="p1">Product to compare</param>
        /// <param name="p2">Product compared to</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        static public bool operator !=(Product p1, Product p2) {
            // Return true if p1 is null.
            if ((object)p1 == null) return true;
            // Equals method compares.
            return !p1.Equals(p2);
        }

        /// <summary>
        /// Overloading greater-than operator using the Equals method.
        /// </summary>
        /// <param name="p1">Product to compare</param>
        /// <param name="p2">Product compared to</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        static public bool operator >(Product p1, Product p2) {
            // Return true if p2 is null.
            if ((object)p2 == null || p1.ID > p2.ID ) return true;
            else return false;
        }

        /// <summary>
        /// Overloading less-than operator using the Equals method.
        /// </summary>
        /// <param name="p1">Product to compare</param>
        /// <param name="p2">Product compared to</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        static public bool operator <(Product p1, Product p2) {
            // Return true if p1 is null.
            if ((object)p1 == null || p1.ID < p2.ID) return true;
            else return false;
        }

        /// <summary>
        /// Overloading greater-than-or-equal-to operator using the Equals method.
        /// </summary>
        /// <param name="p1">Product to compare</param>
        /// <param name="p2">Product compared to</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        static public bool operator >=(Product p1, Product p2) {
            // Return true if p2 is null.
            if (((object)p2 == null) || (p1.ID > p2.ID) || (p1.ID == p2.ID)) return true;
            else return false;
        }

        /// <summary>
        /// Overloading less-than-or-equal-to operator using the Equals method.
        /// </summary>
        /// <param name="p1">Product to compare</param>
        /// <param name="p2">Product compared to</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        static public bool operator <=(Product p1, Product p2) {
            // Return true if p2 is null.
            if (((object)p1 == null) || (p1.ID < p2.ID) || (p1.ID == p2.ID)) return true;
            else return false;
        }

        /// <summary>
        /// Explicit conversion operator capable of converting a Product
        /// into a DataAccess.ProductStruct.
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static explicit operator ProductStruct(Product p) {

            string cSupplierID = p.SupplierID.ToString();
            string cCategoryID = p.CategoryID.ToString();

            return new ProductStruct(p.ID, p.ProductName,cSupplierID,cCategoryID,
                p.QuantityPerUnit,p.UnitPrice, p.UnitsInStock,
                p.UnitsOnOrder, p.ReOrderLevel);

        }

        /// <summary>
        /// Returns the ID property value of the Product object.
        /// </summary>
        /// <returns>An instance of<see cref="System.Int32"/></returns>
        public override int GetHashCode() {
            return this.ID;
        }
        #endregion

        /// <summary>
        /// Inner class that implements the generic IComparer_Product interface
        /// Sorting on SupplierID, ascending.
        /// </summary>
        private class SortBySupplierID: IComparer<Product> {
            #region IComparer<Product> Members

            /// <summary>
            /// Implementation of Compare method.
            /// </summary>
            /// <param name="x">x</param>
            /// <param name="y">y</param>
            /// <returns>An instance of <see cref="System.Int32"/></returns>
            public int Compare(Product x, Product y) {

                    return x.SupplierID.CompareTo(y.SupplierID);   
            }
            #endregion
            
        }

        /// <summary>
        /// Inner class that implements the generic IComparer_Product interface
        /// Sorting on CategoryID, ascending.
        /// </summary>
        private class SortByCatergoryID : IComparer<Product> {
                #region IComparer<Product> Members

            /// <summary>
            /// Implementation of Compare method.
            /// </summary>
            /// <param name="x">x</param>
            /// <param name="y">y</param>
            /// <returns>An instance of <see cref="System.Int32"/></returns>
            public int Compare(Product x, Product y) {

                    return x.CategoryID.CompareTo(y.CategoryID);
          
            }

            #endregion
        }
        

        #region IComparable<Product> Members

        /// <summary>
        /// Implementation of CompareTo method.
        /// </summary>
        /// <param name="other">other</param>
        /// <returns>An instance of <see cref="System.Int32"/></returns>
        public int CompareTo(Product other) {
            if (other==null) {
                throw new ArgumentNullException("other", "Object against which comparison is to be made must be non-null.");
            } else if (!(other is Product)) {
                throw new ArgumentException("Object against which comparison is to be made must be of type Product.",
                    "other");
            } else return this.SupplierID.CompareTo(other.SupplierID);
        }

        #endregion

        #region Static Sort Methods

        /// <summary>
        /// Static sort method.
        /// </summary>
        /// <returns>An instance of System.Collections.Generic.IComparer_Product</returns>
        public static IComparer<Product> GetSortBySupplierID() {

            return new SortBySupplierID();
        }

        /// <summary>
        /// Static sort method.
        /// </summary>
        /// <returns>An instance of System.Collections.Generic.IComparer_Product</returns>
        public static IComparer<Product> GetSortByCategoryID() {

            return new SortByCatergoryID();

        }
           
        #endregion
    }
}
