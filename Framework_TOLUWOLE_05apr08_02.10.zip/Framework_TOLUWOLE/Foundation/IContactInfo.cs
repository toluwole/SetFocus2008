using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation {
    /// <summary>
    /// This interface consolidates the requirements defined in 
    /// ICompanyContact, IAddress, and ICountryPhone.
    /// </summary>
    interface IContactInfo: ICompanyContact, IAddress, ICountryPhone {
    }
}
