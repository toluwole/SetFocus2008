using System;
using System.Collections.Generic;
using System.Text;

namespace AppTypes {

    /// <summary>
    /// Custom Developer attribute to document classes.
    /// </summary>
    [AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class |
        AttributeTargets.Interface | AttributeTargets.Enum, AllowMultiple=true)]
    public class DeveloperInfoAttribute: Attribute {

        #region Fields

        /// <summary>
        /// Required positional field.
        /// </summary>
        private string name;
        /// <summary>
        /// Optional named fields.
        /// </summary>
        private string title, date;

        #endregion

        #region Properties

        /// <summary>
        /// Required positional property
        /// </summary>
        public string Name {
            get { return name; }
            //set { name = value; }
        }  

        /// <summary>
        /// Optional named property
        /// </summary>
        public string Title {
            get { return title; }
            set { title = value; }
        }

        /// <summary>
        /// Optional named property
        /// </summary>
        public string Date {
            get { return date; }
            set { date = value; }
        }

        #endregion


        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="Name">Developer name.</param>
        public DeveloperInfoAttribute(string Name) {
            this.name = Name;
        }

        #endregion


    }
}
