/* Script to create the stored procedures for the data access layer */
/* Temitope Oluwole - 01jul08 */

USE library

/* ADD_ADULT_MEMBER */
-- Drops AddAdultMember procedure if it already exists.
IF OBJECT_ID ('AddAdultMember') IS NOT NULL
	DROP PROCEDURE AddAdultMember;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE AddAdultMember
	@FirstName varchar(15),
	@LastName varchar(15),
	@MiddleInitial char(1)=NULL,
	@Street varchar(15),
	@City varchar(15),
	@State char(2),
	@ZipCode char(10),
	@PhoneNumber char(13)=NULL,
	@MemberID smallint OUTPUT,
	@ExpirationDate datetime OUTPUT
AS
BEGIN

-- Checks that LastName is not NULL.
IF @LastName IS NULL
	BEGIN
		RAISERROR('Last name cannot be NULL.',11,1);
		RETURN;
	END

-- Checks that FirstName is not NULL.
IF @FirstName IS NULL
	BEGIN
		RAISERROR('First name cannot be NULL.',11,1);
		RETURN;
	END

--- Checks that Street is not NULL.
IF @Street IS NULL
	BEGIN
		RAISERROR('Street cannot be NULL.',11,1);
		RETURN;
	END

--- Checks that City is not NULL.
IF @City IS NULL
	BEGIN
		RAISERROR('City cannot be NULL.',11,1);
		RETURN;
	END

--- Checks that State is not NULL.
IF @State IS NULL
	BEGIN
		RAISERROR('State cannot be NULL.',11,1);
		RETURN;
	END
		
--- Checks that ZipCode is not NULL.
IF @ZipCode IS NULL
	BEGIN
		RAISERROR('ZipCode cannot be NULL.',11,1);
		RETURN;
	END


BEGIN TRY -- Try-Catch block to catch any systemic gremlins.

	BEGIN TRANSACTION
		-- Inserts member column values into member table.
		INSERT INTO member(lastname, firstname, middleinitial)
		VALUES(@LastName, @FirstName, @MiddleInitial);

		-- Retrieves new member ID.
		SET @MemberID = scope_identity();
		-- Gets new expiration date.
		SET @ExpirationDate = DATEADD(year, 1, GETDATE());

		-- Inserts adult column values into adult table.
		INSERT INTO adult(member_no, street, city, adult.state, zip,
			phone_no, expr_date)
		VALUES(@MemberID, @Street, @City, @State, @ZipCode, @PhoneNumber,
			@ExpirationDate);	

	COMMIT TRANSACTION

END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	DECLARE @ErrorMessage varchar(512);
	SET @ErrorMessage = ERROR_MESSAGE();	
	RAISERROR(@ErrorMessage, 15, 1);
	RETURN;
END CATCH

END
GO

/* ADD_JUVENILE_MEMBER */

-- Drops AddJuvenileMember procedure if it already exists.
IF OBJECT_ID ('AddJuvenileMember') IS NOT NULL
	DROP PROCEDURE AddJuvenileMember;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE AddJuvenileMember
	@FirstName varchar(15),
	@LastName varchar(15),
	@MiddleInitial char(1)=NULL,
	@AdultMemberID smallint,
	@BirthDate datetime,
	@Street varchar(15) OUTPUT,
	@City varchar(15) OUTPUT,
	@State char(2) OUTPUT,
	@ZipCode char(10) OUTPUT,
	@PhoneNumber char(13) OUTPUT,
	@MemberID smallint OUTPUT,
	@ExpirationDate datetime OUTPUT

AS

BEGIN
-- Checks that LastName is not NULL.
IF @LastName IS NULL
	BEGIN
		RAISERROR('Last name cannot be NULL.',11,1);
		RETURN;
	END

-- Checks that FirstName is not NULL.
IF @FirstName IS NULL
	BEGIN
		RAISERROR('First name cannot be NULL.',11,1);
		RETURN;
	END

-- Checks that AdultMemberID is not NULL and not less than 1
IF (@AdultMemberID IS NULL) OR (@AdultMemberID < 1)
	BEGIN
		RAISERROR('Adult member ID cannot be NULL or less than 1.',11,1);
		RETURN;
	END

-- Checks that AdultMemberID exists in the database.
IF NOT EXISTS
	(SELECT street, city, adult.state, phone_no, expr_date 
		FROM adult 
		WHERE member_no = @AdultMemberID)
		BEGIN
			DECLARE @ErrorMessage1 varchar(512);
			SET @ErrorMessage1 = 'Member ' + CAST(@AdultMemberID AS varchar) + ' not found';
			RAISERROR(@ErrorMessage1, 15,1);
			RETURN;
		END

IF (DATEADD(year, 18, @BirthDate)) < GETDATE()
	BEGIN
			DECLARE @ErrorMessage2 varchar(512);
			SET @ErrorMessage2 = 'Member is not a juvenile';
			RAISERROR(@ErrorMessage2, 15,1);
			RETURN;
	END
BEGIN TRY --Try-Catch block to catch any systemic gremlins.

	BEGIN TRANSACTION

		-- Insertion of data values into member table.
		INSERT INTO member(lastname, firstname, middleinitial)
		VALUES(@LastName, @FirstName, @MiddleInitial);

		SET @MemberID = scope_identity();
		SET @ExpirationDate = DATEADD(year, 1, GETDATE());
		SELECT @Street = street,
			@City = city,
			@State = adult.state,
			@ZipCode = zip,
			@PhoneNumber = phone_no
		FROM adult WHERE member_no = @AdultMemberID;

		-- Insertion of data values into juvenile table.
		INSERT INTO juvenile(member_no, adult_member_no, birth_date)
		VALUES(@MemberID, @AdultMemberID, @BirthDate);

	COMMIT TRANSACTION
	
END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	DECLARE @ErrorMessage varchar(512);
	SET @ErrorMessage = ERROR_MESSAGE();	
	RAISERROR(@ErrorMessage, 15, 1);
	RETURN;
END CATCH

END
GO

/* GET_MEMBER */

-- Drops GetMember procedure if it already exists.
IF OBJECT_ID ('GetMember') IS NOT NULL
	DROP PROCEDURE GetMember;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE GetMember
	@MemberID smallint,
	@FirstName varchar(15) OUTPUT,
	@LastName varchar(15) OUTPUT,
	@MiddleInitial char(1) OUTPUT,
	@Street varchar(15) OUTPUT,
	@City varchar(15) OUTPUT,
	@State char(2) OUTPUT,
	@ZipCode char(10) OUTPUT,
	@PhoneNumber char(13) OUTPUT,
	@ExpirationDate datetime OUTPUT

AS
BEGIN

-- Checks that MemberID is not NULL and not less than 1
IF (@MemberID IS NULL) OR (@MemberID < 1)
	BEGIN
		RAISERROR('member ID cannot be NULL or less than 1.',11,1);
		RETURN;
	END

-- Checks that MemberID exists in the database.
IF NOT EXISTS
	(SELECT member_no FROM member WHERE member_no = @MemberID)
		BEGIN
			DECLARE @ErrorMessage1 varchar(512);
			SET @ErrorMessage1 = 'Member ' + CAST(@MemberID AS varchar) + ' not found';
			RAISERROR(@ErrorMessage1, 15,1);
			RETURN;
		END

BEGIN TRY -- Try-Catch block to catch any systemic gremlins.

	BEGIN TRANSACTION

		-- Output value assignments.
		SELECT @LastName = lastname,
			@FirstName = firstname,
			@MiddleInitial = middleinitial,
			@Street = street,
			@City = city,
			@State = adult.state,
			@ZipCode = zip,
			@PhoneNumber = phone_no,
			@ExpirationDate = expr_date

		FROM member INNER JOIN adult
		ON member.member_no = adult.member_no 
		WHERE member.member_no = @MemberID
		UNION
		SELECT @LastName = lastname,
			@FirstName = firstname,
			@MiddleInitial = middleinitial,
			@Street = street,
			@City = city,
			@State = adult.state,
			@ZipCode = zip,
			@PhoneNumber = phone_no,
			@ExpirationDate = expr_date

		FROM member LEFT JOIN juvenile 
		ON member.member_no = juvenile.member_no INNER JOIN adult
		ON adult.member_no = juvenile.adult_member_no
		WHERE member.member_no = @MemberID;

	COMMIT TRANSACTION

END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	DECLARE @ErrorMessage2 varchar(512);
	SET @ErrorMessage2 = ERROR_MESSAGE();	
	RAISERROR(@ErrorMessage2, 15, 1);
	RETURN;
END CATCH

END
GO

/* GET_ITEM */

-- Drops GetItem procedure if it already exists.
IF OBJECT_ID ('GetItem') IS NOT NULL
	DROP PROCEDURE GetItem;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE GetItem
	@Isbn int,
	@CopyNo smallint,
	@Title varchar(63) OUTPUT, 
	@Author varchar(31) OUTPUT,
	@MemberID smallint OUTPUT,
	@OutDate datetime OUTPUT,
	@DueDate datetime OUTPUT
	
AS
BEGIN

-- Checks that ISBN is not NULL and not less than 1
IF (@Isbn IS NULL) OR (@Isbn < 1)
	BEGIN
		RAISERROR('ISBN cannot be NULL or less than 1.',11,1);
		RETURN;
	END

-- Checks that CopyNo is not NULL and not less than 1
IF (@CopyNo IS NULL) OR (@CopyNo < 1)
	BEGIN
		RAISERROR('Copy Number cannot be NULL or less than 1.',11,1);
		RETURN;
	END

-- Checks that ISBN exists in the database.
IF NOT EXISTS
	(SELECT isbn FROM item)
		BEGIN
			DECLARE @ErrorMessage1 varchar(512);
			SET @ErrorMessage1 = 'ISBN ' + CAST(@Isbn AS varchar) + ' not found';
			RAISERROR(@ErrorMessage1, 15,1);
			RETURN;
		END

BEGIN TRY
	BEGIN TRANSACTION
		
		-- Local variable declaration
		DECLARE @LoanCheck CHAR(1);		

		-- Gets on_loan value
		SELECT @LoanCheck = on_loan FROM copy WHERE @Isbn = isbn AND
			@CopyNo = copy_no

		-- Determines if item is on loan or not
		IF @LoanCheck = 'Y' 
			SELECT 
				@Title = title.title, 
				@Author = title.author, 
				@MemberID = loan.member_no, 
				@OutDate = loan.out_date, 
				@DueDate = loan.due_date
			FROM title INNER JOIN item 
			ON title.title_no = item.title_no INNER JOIN loan
			ON loan.title_no = item.title_no AND loan.isbn = item.isbn
			WHERE item.isbn = @Isbn AND loan.copy_no = @CopyNo
		ELSE
			SELECT
				@Title = title.title, 
				@Author = title.author, 
				@MemberID = 0,
				@OutDate = '1900-01-01', 
				@DueDate = '1900-01-01'
			FROM title INNER JOIN item
			ON title.title_no = item.title_no;

	COMMIT TRANSACTION

END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	DECLARE @ErrorMessage2 varchar(512);
	SET @ErrorMessage2 = ERROR_MESSAGE();	
	RAISERROR(@ErrorMessage2, 15, 1);
	RETURN;
END CATCH

END
GO
 
/* GET_ITEMS */

-- Drops GetItems procedure if it already exists.
IF OBJECT_ID ('GetItems') IS NOT NULL
	DROP PROCEDURE GetItems;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE GetItems
	@MemberID smallint,
	@ErrorMessage varchar(512) OUTPUT
AS
BEGIN

	-- Checks that MemberID is not NULL and not less than 1
	IF (@MemberID IS NULL) OR (@MemberID < 1)
	BEGIN
		SET @ErrorMessage = 'member ID cannot be NULL or less than 1.';
		RAISERROR('member ID cannot be NULL or less than 1.',11,1);
		RETURN;
	END

	-- Checks that MemberID exists in the database.
	IF NOT EXISTS
	(SELECT member_no FROM member)
	BEGIN
		SET @ErrorMessage = 'Member ' + CAST(@MemberID AS varchar) + ' not found';
		RAISERROR(@ErrorMessage, 15,1);
		RETURN;
	END

	BEGIN TRY
		-- Output value assignments
		SELECT DISTINCT
			loan.isbn, loan.copy_no, title.title, title.author, 
			loan.out_date, loan.due_date
		FROM loan INNER JOIN title ON loan.title_no = title.title_no
		WHERE loan.member_no = @MemberID;
	END TRY
	BEGIN CATCH
		ROLLBACK TRANSACTION
		SET @ErrorMessage = ERROR_MESSAGE();	
		RAISERROR(@ErrorMessage, 15, 1);
		RETURN;
	END CATCH
END
GO

/* CHECK_IN_ITEM */

-- Drops CheckInItem procedure if it already exists.
IF OBJECT_ID ('CheckInItem') IS NOT NULL
	DROP PROCEDURE CheckInItem;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE CheckInItem
	@Isbn int,
	@CopyNo smallint

AS
BEGIN

-- Checks that ISBN is not NULL and not less than 1
IF (@Isbn IS NULL) OR (@Isbn < 1)
	BEGIN
		RAISERROR('ISBN cannot be NULL or less than 1.',11,1);
		RETURN;
	END

-- Checks that ISBN exists in the database.
IF NOT EXISTS
	(SELECT isbn FROM item)
		BEGIN
			DECLARE @ErrorMessage1 varchar(512);
			SET @ErrorMessage1 = 'ISBN ' + CAST(@Isbn AS varchar) + ' not found';
			RAISERROR(@ErrorMessage1, 15,1);
			RETURN;
		END

-- Checks that ISBN exists in the loan table.
IF NOT EXISTS
	(SELECT isbn FROM loan)
		BEGIN
			DECLARE @ErrorMessage3 varchar(512);
			SET @ErrorMessage3 = 'ISBN ' + CAST(@Isbn AS varchar) + ' not on loan';
			RAISERROR(@ErrorMessage3, 15,1);
			RETURN;
		END

BEGIN TRY
	BEGIN TRANSACTION

	-- Input variable declarations.
	DECLARE @TitleNo int;
	DECLARE @MemberID smallint;
	DECLARE @OutDate datetime;
	DECLARE @DueDate datetime;
	DECLARE @InDate datetime;

	-- Insert values assignments.
	SELECT
		@TitleNo = loan.title_no,
		@MemberID = loan.member_no,
		@OutDate = loan.out_date,
		@DueDate = loan.due_date,
		@InDate = GETDATE()
	FROM loan
	WHERE (isbn = @Isbn) AND (copy_no = @CopyNo);

	-- Insert record into loanhist table.
	INSERT INTO loanhist(isbn, copy_no, out_date, title_no, member_no, 
		due_date, in_date)
	VALUES(@Isbn, @CopyNo, @OutDate, @TitleNo, @MemberID,
			@DueDate, @InDate);
	
	-- Delete record from loan table
	DELETE FROM loan WHERE (isbn = @Isbn) AND (copy_no = @CopyNo);

	-- Updates on_loan column of copy table record to 'N'
	UPDATE [library].[dbo].[copy]
      SET [on_loan] = 'N'
    WHERE isbn = @Isbn AND copy_no = @CopyNo AND title_no = @TitleNo 

	COMMIT TRANSACTION

END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	DECLARE @ErrorMessage2 varchar(512);
	SET @ErrorMessage2 = ERROR_MESSAGE();	
	RAISERROR(@ErrorMessage2, 15, 1);
	RETURN;
END CATCH

END
GO

/* CHECK_OUT_ITEM */

-- Drops CheckOutItem procedure if it already exists.
IF OBJECT_ID ('CheckOutItem') IS NOT NULL
	DROP PROCEDURE CheckOutItem;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE CheckOutItem
	@MemberID smallint,
	@Isbn int,
	@CopyNo smallint

AS
BEGIN

-- Checks that MemberID is not NULL and not less than 1
IF (@MemberID IS NULL) OR (@MemberID < 1)
	BEGIN
		RAISERROR('member ID cannot be NULL or less than 1.',11,1);
		RETURN;
	END

-- Checks that MemberID exists in the database.
IF NOT EXISTS
	(SELECT member_no FROM member)
		BEGIN
			DECLARE @ErrorMessage varchar(512);
			SET @ErrorMessage = 'Member ' + CAST(@MemberID AS varchar) + ' not found';
			RAISERROR(@ErrorMessage, 15,1);
			RETURN;
		END

-- Checks that ISBN is not NULL and not less than 1
IF (@Isbn IS NULL) OR (@Isbn < 1)
	BEGIN
		RAISERROR('ISBN cannot be NULL or less than 1.',11,1);
		RETURN;
	END

-- Checks that ISBN exists in the database.
IF NOT EXISTS
	(SELECT isbn FROM item)
		BEGIN
			DECLARE @ErrorMessage1 varchar(512);
			SET @ErrorMessage1 = 'ISBN ' + CAST(@Isbn AS varchar) + ' not found';
			RAISERROR(@ErrorMessage1, 15,1);
			RETURN;
		END

-- Checks that ISBN and copy are available for loan.
IF EXISTS
	(SELECT isbn FROM copy WHERE isbn = @Isbn AND copy_no = @CopyNo AND on_loan = 'y')
		BEGIN
			DECLARE @ErrorMessage4 varchar(512);
			SET @ErrorMessage4 = 'Item on loan';
			RAISERROR(@ErrorMessage4, 15,1);
			RETURN;
		END

BEGIN TRY

	BEGIN TRANSACTION

	-- Input variable declarations.
	DECLARE @OutDate datetime;
	DECLARE @DueDate datetime;
	DECLARE @TitleNo int;

	-- Insert values assignments.
	SELECT
		@OutDate = GETDATE(),
		@DueDate = DATEADD(week,2,@OutDate),	
		@TitleNo = copy.title_no
	FROM copy 
	WHERE (isbn = @Isbn) AND (copy_no = @CopyNo);

	-- Insert record into loan table.
	INSERT INTO loan(isbn, copy_no, title_no, member_no, 
		out_date, due_date)
	VALUES(@Isbn, @CopyNo, @TitleNo, @MemberID, @OutDate, 
			@DueDate);	

	-- Updates loanable column of copy table record to 'Y'
	UPDATE [library].[dbo].[copy]
      SET [on_loan] = 'Y'
    WHERE isbn = @Isbn AND copy_no = @CopyNo AND title_no = @TitleNo 

	COMMIT TRANSACTION

END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	DECLARE @ErrorMessage2 varchar(512);
	SET @ErrorMessage2 = ERROR_MESSAGE();	
	RAISERROR(@ErrorMessage2, 15, 1);
	RETURN;
END CATCH

END
GO

/* RENEW_CARD */
-- Drops RenewCard procedure if it already exists.
IF OBJECT_ID ('RenewCard') IS NOT NULL
	DROP PROCEDURE RenewCard;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE RenewCard
	@MemberID smallint
	
AS
BEGIN

BEGIN TRY -- Try-Catch block to catch any systemic gremlins.

	BEGIN TRANSACTION

		-- input variable declarations.
		DECLARE @ExpirationDate datetime;
		DECLARE @RenewalID smallint;

		SELECT 
			@RenewalID = member_no,
			@ExpirationDate = expr_date
		  FROM adult 
		WHERE member_no = @MemberID
		UNION
		SELECT 
			@RenewalID = a.member_no, 
			@ExpirationDate = a.expr_date
		  FROM juvenile AS j INNER JOIN 
			adult AS a 
		  ON a.member_no = j.adult_member_no
		WHERE j.member_no = @MemberID;

		UPDATE adult
		-- Gets new expiration date.
			SET expr_date  = DATEADD(year, 1, @ExpirationDate)
		WHERE member_no = @RenewalID

	COMMIT TRANSACTION

END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	DECLARE @ErrorMessage varchar(512);
	SET @ErrorMessage = ERROR_MESSAGE();	
	RAISERROR(@ErrorMessage, 15, 1);
	RETURN;
END CATCH

END
GO

/* CHECK_ID_JUVENILE */
-- Drops RenewCard procedure if it already exists.
IF OBJECT_ID ('CheckIDJuvenile') IS NOT NULL
	DROP PROCEDURE CheckIDJuvenile;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE CheckIDJuvenile
	@MemberID smallint,
	@ConvertMember smallint OUTPUT
	
AS
BEGIN

BEGIN TRY -- Try-Catch block to catch any systemic gremlins.

	BEGIN TRANSACTION
	
	-- input variable declarations.
	DECLARE	@BirthDate datetime;

	IF EXISTS
	(SELECT member_no FROM juvenile WHERE member_no = @MemberID)
		BEGIN
			-- Gets	juvenile member's date of birth
			SELECT 
				--@MemberAge= (YEAR(GETDATE())-YEAR(birth_date))
				@BirthDate=birth_date
			  FROM juvenile 
			WHERE member_no = @MemberID

			-- Flags juvenile member '1' if convertable to adult
			IF (GETDATE()>=DATEADD(Year,18,@BirthDate))
				BEGIN
					SET @ConvertMember=1
				END
			ELSE
				-- Flags junvenile not eligible for conversion
				SET @ConvertMember=0
		END
     ELSE
		-- Flags all adult members as not eligible for conversion
		SET @ConvertMember=0
	
	COMMIT TRANSACTION

END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	DECLARE @ErrorMessage varchar(512);
	SET @ErrorMessage = ERROR_MESSAGE();	
	RAISERROR(@ErrorMessage, 15, 1);
	RETURN;
END CATCH

END
GO

/* MAKE_JUVENILE_ADULT */
IF OBJECT_ID ('MakeJuvenileAdult') IS NOT NULL
	DROP PROCEDURE MakeJuvenileAdult;
GO

-- Declaration of input and output parameters.
CREATE PROCEDURE MakeJuvenileAdult
	@MemberID smallint,
	@Street varchar(15),
	@City varchar(15),
	@State char(2),
	@ZipCode char(10),
	@PhoneNumber char(13)=NULL,
	@ExpirationDate datetime
AS

BEGIN

BEGIN TRY --Try-Catch block to catch any systemic gremlins.

	BEGIN TRANSACTION

	-- Insertion of data values into juvenile table.
	INSERT INTO adult(member_no, street, city, [state],
		zip, phone_no, expr_date)
	VALUES(@MemberID, @Street, @City, @State, 
		@ZipCode, @PhoneNumber, @ExpirationDate);

	-- Delete record from juvenile table
	DELETE FROM juvenile WHERE (member_no = @MemberID);

	COMMIT TRANSACTION
	
END TRY
BEGIN CATCH
	ROLLBACK TRANSACTION
	DECLARE @ErrorMessage varchar(512);
	SET @ErrorMessage = ERROR_MESSAGE();	
	RAISERROR(@ErrorMessage, 15, 1);
	RETURN;
END CATCH

END
GO