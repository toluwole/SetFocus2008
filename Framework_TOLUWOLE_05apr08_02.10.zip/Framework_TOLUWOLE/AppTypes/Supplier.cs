using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Soap;
using System.Reflection;
using Foundation;
using DataAccess;


namespace AppTypes {
    /// <summary>
    /// The Supplier class holds information about various
    /// suppliers used by the company.
    /// </summary>
    [DeveloperInfoAttribute("Temitope Oluwole", Date = "26mar08", Title = "AppTypes.Supplier Class")]
    [CustomDescriptionAttribute("The Supplier class holds information about various" +
       "suppliers used by the company.")]
    [Serializable]
    public sealed class Supplier : Contact, IComparable, ISerializable {

        #region Fields
        /// <summary>
        /// Field declarations
        /// </summary>
        private string homePage;
        private SupplierTypes type;

        #endregion

        #region Properites
        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public string HomePage {
            get { return homePage; }
            set {
                if (value == null)
                    this.homePage = null;
                else if (((value.Length >= 5) && (value.Length <= 50)))
                    this.homePage = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a HomePage of at least five" +
                        "characters in length and no longer than 50.");
            }
        }


        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public SupplierTypes Type {
            get { return type; }
            set {
                type = (SupplierTypes)value;
            }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public Supplier() {
        }

        /// <summary>
        /// Full parameters override constructor.
        /// </summary>
        /// <param name="ID">Passed ID</param>
        /// <param name="CompanyName">Passed CompanyName</param>
        /// <param name="ContactName">Passed CompanyTitle</param>
        /// <param name="ContactTitle">Passed ContactTitle</param>
        /// <param name="Address">Passed Address</param>
        /// <param name="City">Passed City</param>
        /// <param name="Region">Passed Region</param>
        /// <param name="PostalCode">Passed PostalCode</param>
        /// <param name="Country">Passed Country</param>
        /// <param name="Phone">Passed Phone</param>
        /// <param name="Fax">Passed Fax</param>
        /// <param name="HomePage">Pased HomePage</param>
        /// <param name="Type">Passed Type</param>
        public Supplier(int ID, string CompanyName, string ContactName, string ContactTitle,
            string Address, string City, string Region, string PostalCode, string Country,
            string Phone, string Fax, string HomePage, SupplierTypes Type) {

            this.ID = ID;
            this.CompanyName = CompanyName;
            this.ContactName = ContactName;
            this.ContactTitle = ContactTitle;
            this.Address = Address;
            this.City = City;
            this.Region = Region;
            this.PostalCode = PostalCode;
            this.Country = Country;
            this.Phone = Phone;
            this.Fax = Fax;
            this.HomePage = HomePage;
            this.Type = Type;

        }

        /// <summary>
        /// Serialization constructor.
        /// </summary>
        /// <param name="si">Serialization object.</param>
        /// <param name="context">Describes source and destination of given serialized stream.</param>
        internal Supplier(SerializationInfo si, StreamingContext context) {

            // Adds the instance's property values to the serialization object.
            foreach (PropertyInfo pi in this.GetType().GetProperties()) {
                pi.SetValue(this, si.GetValue(pi.Name, pi.PropertyType), null);
            }
        }

        /// <summary>
        /// SupplierStruct parameter.
        /// </summary>
        /// <param name="s">SupplierStruct object</param>
        public Supplier(SupplierStruct s) {
        }

        #endregion

        #region Methods

        /// <summary>
        /// Override of ToString method.
        /// </summary>
        /// <returns><see cref="System.String"/></returns>
        //String not quite right.  DJL
        public override string ToString() {
            return "Supplier ID:" + ID.ToString() +
                " Type:" + Enum.GetName(typeof(SupplierTypes), Type) +
                " CompanyName:" + CompanyName;
        }

        /// <summary>
        /// Implementation of ContactInfo method.
        /// </summary>
        /// <returns>An instance of<see cref="System.Text.StringBuilder"/></returns>
        public override StringBuilder ContactInfo() {
            StringBuilder myStringBuilder =
                new StringBuilder(ContactName + "\n" + ContactTitle + "\n" + Address +
                "\n" + City + "\n" + Region + "\t" + PostalCode);
            return myStringBuilder;
        } 

        /// <summary>
        /// Returns the ID property value of the Supplier object.
        /// </summary>
        /// <returns>An instance of<see cref="System.Int32"/></returns>
        public override int GetHashCode() {
            return ID;
        } 

        /// <summary>
        /// Overrides the Equals methods to return true if the two objects
        /// have the same ID.
        /// </summary>
        /// <param name="obj">object to be compared</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        public override bool Equals(object obj) {
            //returns false if obj is null or is a type mismatch.
            if (obj == null || GetType() != obj.GetType()) return false;
            // explictly cast obj for comparision.
            Supplier s = (Supplier)obj;
            return this.ID == s.ID;
        }

        /// <summary>
        /// Overloading == operator using the Equals method.
        /// </summary>
        /// <param name="s1">Supplier to compare</param>
        /// <param name="s2">Supplier compared to</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        static public bool operator ==(Supplier s1, Supplier s2) {
            // Return false if s1 is null.
            if ((object)s1 == null) return false;
            // Equals method compares.
            return s1.Equals(s2);
        }

        /// <summary>
        /// Overloading != operator using the Equals method.
        /// </summary>
        /// <param name="s1">Supplier to compare</param>
        /// <param name="s2">Supplier compared to</param>
        /// <returns>An instance of<see cref="System.Boolean"/></returns>
        static public bool operator !=(Supplier s1, Supplier s2) {
            // Return true if s1 is null.
            if ((object)s1 == null) return true;
            // Equals method compares.
            return !s1.Equals(s2);
        }

        /// <summary>
        /// Provides an enumerator that allows for easy enumeration over
        /// a set of string values that provide information about the 
        /// current Supplier object.
        /// </summary>
        /// <returns>An instance of<see cref="System.String"/></returns>
        public IEnumerable PropertyAndValuesCollection() {
            yield return "ID: " + this.ID.ToString();
            yield return "CompanyName: " + this.CompanyName;
            yield return "ContactName: " + this.ContactName;
            yield return "ContactTitle: " + this.ContactTitle;
            yield return "Address: " + this.Address;
            yield return "City: " + this.City;
            yield return "Region: " + this.Region;
            yield return "PostalCode: " + this.PostalCode;
            yield return "Country: " + this.Country;
            yield return "Phone: " + this.Phone;
            yield return "Fax: " + this.Fax;
            yield return "HomePage: " + this.HomePage;
            yield return "Type: " + this.Type.ToString();

        } 

        /// <summary>
        /// Returns a new instance of the nested type SortByCountryRegionCity.
        /// </summary>
        /// <returns>An instance of <see cref="System.Collections.IComparer"/></returns>
        public static IComparer GetSortByCountryRegionCity() {

            return new SortByCountryRegionCity();
        }

        /// <summary>
        /// Returns a new instance of the nested type SortByTypeCompanyName.
        /// </summary>
        /// <returns>An instance of <see cref="System.Collections.IComparer"/></returns>
        public static IComparer GetSortByTypeCompanyName() {

            return new SortByTypeCompanyName();
        }

        #endregion

        #region IComparable Members

        /// <summary>
        /// Implementation of IComparable based on the id field.
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public int CompareTo(object obj) {
            if (obj == null) return 1;
            if (!(obj is Supplier)) {
                throw new ArgumentException("Please provide an obj of type Supplier.");
            }
            Supplier aSupplier = (Supplier)obj;
            if (this.id < aSupplier.id) return -1;
            else {
                if (this.id == aSupplier.id) return 0;
                else return 1;
            }
        }

        #endregion

        /// <summary>
        /// Nested type SortByCountryRegionCity which inherits from IComparer.
        /// </summary>
        public class SortByCountryRegionCity : IComparer {

            #region IComparer Members

            /// <summary>
            /// IComparer implementation.
            /// </summary>
            /// <param name="x">Comparing type parameter.</param>
            /// <param name="y">Compared to parameter.</param>
            /// <returns>An instance of<see cref="System.Int32"/></returns>
            public int Compare(object x, object y) {
                // Determine order if one or both objects are null.
                if (x == null && y == null) { return 0; } else if (x == null && y != null) { return -1; } else if (x != null && y == null) { return 1; }


                // Checks that both are of Supplier type.
                if (!(x is Supplier) || !(y is Supplier)) {
                    throw new ArgumentException("Please provide objs of type Supplier.");
                }

                // Cast both objects to type Suppler.
                Supplier xSupplier = (Supplier)x;
                Supplier ySupplier = (Supplier)y;

                // Compares Country, then Region, then City.
                if (xSupplier.Country != ySupplier.Country) {
                    return xSupplier.Country.CompareTo(ySupplier.Country);
                } else if (xSupplier.Region != ySupplier.Region) {
                    return xSupplier.Region.CompareTo(ySupplier.Region);
                } else {
                    return xSupplier.City.CompareTo(ySupplier.City);
                }
            }
            #endregion
        }

        /// <summary>
        /// Sorts by Type and the CompanyName, ascending
        /// </summary>
        public class SortByTypeCompanyName : IComparer {

            #region IComparer Members

            /// <summary>
            /// IComparer implementation.
            /// </summary>
            /// <param name="x">Comparing type parameter.</param>
            /// <param name="y">Compared to parameter.</param>
            /// <returns>An instance of<see cref="System.Int32"/></returns>
            public int Compare(object x, object y) {
                // Determine order if one or both objects are null.
                if (x == null && y == null) { return 0; } else if (x == null && y != null) { return -1; } else if (x != null && y == null) { return 1; }


                // Checks that both are of Supplier type.
                if (!(x is Supplier) || !(y is Supplier)) {
                    throw new ArgumentException("Please provide objs of type Supplier.");
                }

                // Cast both objects to type Suppler.
                Supplier xSupplier = (Supplier)x;
                Supplier ySupplier = (Supplier)y;

                // Compares Type, then CompanyName.
                if (xSupplier.type != ySupplier.type) {
                    return xSupplier.type.CompareTo(ySupplier.type);
                } else {
                    return xSupplier.CompanyName.CompareTo(ySupplier.CompanyName);
                }
            }
            #endregion
        }


        #region ISerializable Members

        /// <summary>
        /// This method is used during Serialization,
        /// which is a "property bag" that contains the type of the object,
        /// and the name/object pairs for the values that are being serialized.
        /// </summary>
        /// <param name="si">Serialization object.</param>
        /// <param name="context">Describes source and destination of given serialized stream.</param>
        public void GetObjectData(SerializationInfo si, StreamingContext context) {

            foreach (PropertyInfo pi in this.GetType().GetProperties()) {
                si.AddValue(pi.Name, pi.GetValue(this, null), pi.PropertyType);
            }
        }

        #endregion

        /// <summary>
        /// Explicit conversion operator capable of exporting the state of a
        /// supplier instance into a SupplierStruct structure.
        /// </summary>
        /// <param name="s">Supplier</param>
        /// <returns></returns>
        public static explicit operator SupplierStruct(Supplier s) {

            String cType = Enum.GetName(typeof(SupplierTypes), s.Type);
            
                return new SupplierStruct(s.ID, s.CompanyName, s.ContactName, s.ContactTitle,
                    s.Address, s.City, s.Region, s.PostalCode, s.Country,s.Phone,s.Fax,
                    s.HomePage, cType);
       
        }


    }
}

