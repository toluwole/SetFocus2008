using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TO.LibraryWinClient {
    /// <summary>
    /// Class that represents container form.
    /// </summary>
    public partial class MDIParentLibForm : Form {
        //private int childFormNumber = 0;

        /// <summary>
        /// Container form constructor
        /// </summary>
        public MDIParentLibForm() {
            InitializeComponent();
        }

        /// <summary>
        /// Event handler to open ViewMemberForm on MDI parent form Load event
        /// and whenever the ViewMemberForm needs to be shown.
        /// </summary>
        /// <param name="sender">Event triggering object.</param>
        /// <param name="e">Information on object.</param>
        private void ShowViewMemberForm(Object sender, EventArgs e) {

            // Create a new instance of the ViewMemberForm
            ViewMemberForm childForm = new ViewMemberForm();

            // Make it a child of the MDI parent form before showing it.
            childForm.MdiParent = this;
            childForm.Left = 0;
            childForm.Top = 0;
            childForm.Show();

            // Sets status.
            this.toolStripStatusLabel.Text = "Enter Member ID " +
                    "and click View Member Information button";
            
        }

        /// <summary>
        /// Event handler to open CheckOutItemForm on demand.
        /// </summary>
        /// <param name="sender">Event triggering object.</param>
        /// <param name="e">Information on object.</param>
        private void ShowCheckOutItemForm(Object sender, EventArgs e) {

            // Create a new instance of the CheckOutItemForm
            CheckOutItemForm childForm = new CheckOutItemForm();

            // Make it a child of the MDI parent form before showing it.
            childForm.MdiParent = this;
            childForm.Left = 0;
            childForm.Top = 0;
            childForm.Show();

        }


        private void OpenFile(object sender, EventArgs e) {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK) {
                string FileName = openFileDialog.FileName;
                // TODO: Add code here to open the file.
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e) {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK) {
                string FileName = saveFileDialog.FileName;
                // TODO: Add code here to save the current contents of the form to a file.
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e) {
            // TODO: Use System.Windows.Forms.Clipboard to insert the selected text or images into the clipboard
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e) {
            // TODO: Use System.Windows.Forms.Clipboard to insert the selected text or images into the clipboard
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e) {
            // TODO: Use System.Windows.Forms.Clipboard.GetText() or System.Windows.Forms.GetData to retrieve information from the clipboard.
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e) {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e) {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e) {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e) {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e) {
            foreach (Form childForm in MdiChildren) {
                childForm.Close();
            }
        }

        /// <summary>
        /// Opens View Member form from the menu.
        /// </summary>
        /// <param name="sender">Event triggering object</param>
        /// <param name="e">Event data</param>
        private void viewMemberMenuItem_Click(object sender, EventArgs e) {

            // Shows View Member form if not already visible, and disables
            // menu item if already visible.
            if (this.ActiveMdiChild == null) {
                ShowViewMemberForm(sender, e);
            }
            
            // Sets status
            this.toolStripStatusLabel.Text = this.ActiveMdiChild.Text + " Active";
        
        }

        /// <summary>
        /// Enables or disables menu items when MDI child form is activated or
        /// deactivated.
        /// </summary>
        /// <param name="sender">Event triggering object</param>
        /// <param name="e">Event data</param>
        private void MDIParentLibForm_MdiChildActivate(object sender, EventArgs e) {

            // Enables or disables View Member menu item.
            if (this.ActiveMdiChild == null) {
                this.viewMemberMenuItem.Enabled = true;
                this.viewMemberMenuItem.Checked = false;
                this.enrollMemberMenuItem.Enabled = true;
                this.enrollMemberMenuItem.Checked = false;
                this.toolStripStatusLabel.Text = "Ready";
            } else if (this.ActiveMdiChild.Name=="ViewMemberForm") {
                this.viewMemberMenuItem.Enabled = false;
                this.viewMemberMenuItem.Checked = true;
                this.toolStripStatusLabel.Text = this.ActiveMdiChild.Text + " Active";
            } else if (this.ActiveMdiChild.Name == "EnrollMemberForm") {
                this.enrollMemberMenuItem.Enabled = false;
                this.enrollMemberMenuItem.Checked = true;
                this.toolStripStatusLabel.Text = this.ActiveMdiChild.Text + " Active";
            }
        }

        /// <summary>
        /// Check Out Items event.
        /// </summary>
        /// <param name="sender">Event triggering object</param>
        /// <param name="e">Event data</param>
        private void checkOutItemsToolStripMenuItem_Click(object sender, EventArgs e) {

            // Shows View Member form if not already visible, and disables
            // menu item if already visible.
            if (this.ActiveMdiChild == null) {
                ShowViewMemberForm(sender, e);
            }

            // Sets status.
            this.toolStripStatusLabel.Text = this.ActiveMdiChild.Text + " Active";

            // Validates all controls on the View Member form
            //if (!this.ActiveMdiChild.ValidateChildren(ValidationConstraints.Visible)) {

            //    // Keeps View Member form open if controls do not validate.
            //    this.DialogResult = DialogResult.None;
            
            //    this.toolStripStatusLabel.Text = "Enter Member ID " +
            //        "and click View Member Information button";

            //} else {
            //    // Shows Check Out form if all is well.
            //    ShowCheckOutItemForm(sender, e);
            //}
        }

        /// <summary>
        /// Opens Enroll Member form from the MDI menu.
        /// </summary>
        /// <param name="sender">Event triggering object</param>
        /// <param name="e">Event data</param>
        private void viewEnrollMenuItem_Click(object sender, EventArgs e) {
            
            // Shows Enroll Member form if not already visible.
            if (this.ActiveMdiChild == null) {
                ShowEnrollMemberForm(sender, e);
            } else {
                this.ActiveMdiChild.Close();
                ShowEnrollMemberForm(sender, e);
            }
        }

        /// <summary>
        /// Event handler to open EnrollMemberForm on MDI parent form Load event
        /// and whenever the EnrollMemberForm needs to be shown.
        /// </summary>
        /// <param name="sender">Event triggering object.</param>
        /// <param name="e">Information on object.</param>
        private void ShowEnrollMemberForm(Object sender, EventArgs e) {
        
            // Creates a new instance of the EnrollMemberForm.
            EnrollMemberForm childForm = new EnrollMemberForm();

            // Make it a child of the MDI parent form before showing it.
            childForm.MdiParent = this;
            childForm.Left = 0;
            childForm.Top = 0;
            childForm.Show();

            this.toolStripStatusLabel.Text = "Enroll Member";
        }
    }
}
