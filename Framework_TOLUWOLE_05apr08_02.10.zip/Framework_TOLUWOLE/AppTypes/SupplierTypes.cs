using System;
using System.Collections.Generic;
using System.Text;

namespace AppTypes {
    
    /// <summary>
    /// The SupplierTypes enum is provided to insure that the 
    /// type of each Supplier is limited to one of the known types.
    /// </summary>
    [DeveloperInfoAttribute("Temitope Oluwole",Date="20mar08",Title="Enum SupplierTypes")]
    [CustomDescriptionAttribute("This is the declaration of enum SupplerTypes")]
    public enum SupplierTypes {
        /// <summary>
        /// Product supplier type.
        /// </summary>
        Product,
        /// <summary>
        /// Service supplier type.
        /// </summary>
        Service,
        /// <summary>
        /// Supply supplier type.
        /// </summary>
        Supply,

    }

}
