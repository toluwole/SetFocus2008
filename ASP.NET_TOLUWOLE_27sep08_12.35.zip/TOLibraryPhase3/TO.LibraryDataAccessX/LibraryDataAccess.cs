using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Runtime.Serialization;
using TO.LibraryEntities;
using TO.LibraryEntities.ItemsDataSetTableAdapters;

namespace TO.LibraryDataAccess {
    
    /// <summary>
    /// Library Database access class
    /// </summary>
    public class LibraryDataAccess 
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public LibraryDataAccess()
        {

        }
        
        /// <summary>
        /// Data access layer for application.
        /// </summary>
        /// <param name="memberID">Member ID</param>
        /// <returns><see cref="TO.LibraryEntities.ItemsDataSet"/></returns>
        public ItemsDataSet GetItems(short memberID) {
            ItemsDataSet itemDS = new ItemsDataSet();
            ItemsTableAdapter itemsTableAdapter = new ItemsTableAdapter();
            string errorMessage = string.Empty;

            try {
                int returnValue = itemsTableAdapter.Fill(itemDS.Items, memberID,
                           ref errorMessage);
                return itemDS;
            } catch (Exception ex) {

                throw new Exception(errorMessage, ex);

            }

        }

        /// <summary>
        /// Gets the Member, if one exists, with the specified member number. 
        /// </summary>
        /// <param name="memberid">Member ID</param>
        /// <returns><see cref="TO.LibraryEntities.LibraryEntities.Member"/></returns>
        public TO.LibraryEntities.LibraryEntities.Member GetMember(short memberid) {
            // Creates new local instance variable of Member.
            TO.LibraryEntities.LibraryEntities.Member myMember =
                new TO.LibraryEntities.LibraryEntities.Member();

            string connectString = @"Data Source=.;Initial Catalog=library;Integrated Security=True";

            try {
                using (

                    // Establishes connection.
                System.Data.SqlClient.SqlConnection cnn =
                    new System.Data.SqlClient.SqlConnection()) {

                    using (
                        // SQL object to run stored procedure.
                        SqlCommand cmd = new SqlCommand()) {

                        // Determines type of command to be run.
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Specifies stored procedure to run.
                        cmd.CommandText = "GetMember";

                        // Specifies command objects parameters.
                        // Input parameter @MemberID.
                        cmd.Parameters.AddWithValue("@MemberID", memberid);

                        // Output parameter @FirstName. 
                        SqlParameter fnParam = new SqlParameter("@FirstName", SqlDbType.VarChar, 15);
                        fnParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(fnParam);

                        // Output parameter @LastName.
                        SqlParameter lnParam = new SqlParameter("@LastName", SqlDbType.VarChar, 15);
                        lnParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(lnParam);

                        // Output parameter @MiddleInitial.
                        SqlParameter miParam = new SqlParameter("@MiddleInitial", SqlDbType.Char, 1);
                        miParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(miParam);

                        // Output parameter @Street.
                        SqlParameter strParam = new SqlParameter("@Street", SqlDbType.VarChar, 15);
                        strParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(strParam);

                        // Output parameter @City.
                        SqlParameter cityParam = new SqlParameter("@City", SqlDbType.VarChar, 15);
                        cityParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(cityParam);

                        // Output parameter @State.
                        SqlParameter stateParam = new SqlParameter("@State", SqlDbType.VarChar, 2);
                        stateParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(stateParam);

                        // Output parameter @ZipCode.
                        SqlParameter zipParam = new SqlParameter("@ZipCode", SqlDbType.VarChar, 10);
                        zipParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(zipParam);

                        // Output parameter @PhoneNumber.
                        SqlParameter phoneParam = new SqlParameter("@PhoneNumber", SqlDbType.Char, 13);
                        phoneParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(phoneParam);

                        // Output parameter @ExpirationDate.
                        SqlParameter exdateParam = new SqlParameter("@ExpirationDate", SqlDbType.DateTime, 8);
                        exdateParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(exdateParam);

                        // Initializes ConnectionString property.
                        cnn.ConnectionString = connectString;

                        // Opens connection
                        cnn.Open();

                        // Initializes command connection proerty.
                        cmd.Connection = cnn;

                        // Executes stored procedure
                        cmd.ExecuteNonQuery();

                        // Initializes myMember properties from output proc parameters.
                        myMember.FirstName = cmd.Parameters["@FirstName"].Value.ToString();
                        myMember.LastName = cmd.Parameters["@LastName"].Value.ToString();
                        myMember.MiddleInitial = cmd.Parameters["@MiddleInitial"].Value.ToString();
                        myMember.Street = cmd.Parameters["@Street"].Value.ToString();
                        myMember.City = cmd.Parameters["@City"].Value.ToString();
                        myMember.State = cmd.Parameters["@State"].Value.ToString();
                        myMember.ZipCode = cmd.Parameters["@ZipCode"].Value.ToString();
                        myMember.PhoneNumber = cmd.Parameters["@PhoneNumber"].Value.ToString();
                        myMember.ExpirationDate = Convert.ToDateTime(cmd.Parameters["@ExpirationDate"].Value);


                        return myMember;
                    }

                }
            } catch (Exception ex) {

                throw new Exception(ex.Message);

            } 
        }
        /// <summary>
        /// Gets an Item object that contains data about the item whose ISBN and copy number are provided as parameters. 
        /// </summary>
        /// <param name="itemISBN">ISBN</param>
        /// <param name="itemCopyNumber">Copy Number</param>
        /// <returns><see cref="TO.LibraryEntities.LibraryEntities.Item"/></returns>
        public TO.LibraryEntities.LibraryEntities.Item GetItem(int itemISBN, short itemCopyNumber)
        {
            // Creates new local instance variable of Member.
            TO.LibraryEntities.LibraryEntities.Item GetItem =
                new TO.LibraryEntities.LibraryEntities.Item();

            string connectString = @"Data Source=.;Initial Catalog=library;Integrated Security=True";

            try {
                using (

                    // Establishes connection.
                System.Data.SqlClient.SqlConnection cnn =
                    new System.Data.SqlClient.SqlConnection()) {

                    using (
                        // SQL object to run stored procedure.
                        SqlCommand cmd = new SqlCommand()) {

                        // Determines type of command to be run.
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Specifies stored procedure to run.
                        cmd.CommandText = "GetItem";

                        // Specifies command objects parameters.
                        // Input parameter @Isbn, @CopyNo.
                        cmd.Parameters.AddWithValue("@Isbn", itemISBN);
                        cmd.Parameters.AddWithValue("@CopyNo", itemCopyNumber);


                        // Output parameter @TitleNo. 
                        SqlParameter titlenoParam = new SqlParameter("@TitleNo", SqlDbType.Int, 10);
                        titlenoParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(titlenoParam);

                        // Output parameter @Title.
                        SqlParameter titleParam = new SqlParameter("@Title", SqlDbType.VarChar, 63);
                        titleParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(titleParam);

                        // Output parameter @Author.
                        SqlParameter authorParam = new SqlParameter("@Author", SqlDbType.VarChar, 31);
                        authorParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(authorParam);

                        // Output parameter @Translation.
                        SqlParameter transParam = new SqlParameter("@Translation", SqlDbType.Char, 8);
                        transParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(transParam);

                        // Output parameter @Cover.
                        SqlParameter coverParam = new SqlParameter("@Cover", SqlDbType.Char, 8);
                        coverParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(coverParam);

                        // Output parameter @Loanable.
                        SqlParameter loanParam = new SqlParameter("@Loanable", SqlDbType.Char, 1);
                        loanParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(loanParam);

                        // Output parameter @MemberID.
                        SqlParameter memberParam = new SqlParameter("@MemberID", SqlDbType.SmallInt, 2);
                        memberParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(memberParam);

                        // Output parameter @OutDate.
                        SqlParameter outdateParam = new SqlParameter("@OutDate", SqlDbType.DateTime, 8);
                        outdateParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(outdateParam);

                        // Output parameter @DueDate.
                        SqlParameter duedateParam = new SqlParameter("@DueDate", SqlDbType.DateTime, 8);
                        duedateParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(duedateParam);

                        // Initializes ConnectionString property.
                        cnn.ConnectionString = connectString;

                        // Opens connection
                        cnn.Open();

                        // Initializes command connection proerty.
                        cmd.Connection = cnn;

                        // Executes stored procedure
                        cmd.ExecuteNonQuery();

                        // Initializes myMember properties from output proc parameters.
                        GetItem.Title = cmd.Parameters["@Title"].Value.ToString();
                        GetItem.Author = cmd.Parameters["@Author"].Value.ToString();
                        GetItem.MemberNumber = Convert.ToInt16(cmd.Parameters["@MemberId"].Value.ToString());
                        GetItem.CheckoutDate = Convert.ToDateTime(cmd.Parameters["@OutDate"].Value.ToString());
                        GetItem.DueDate = Convert.ToDateTime(cmd.Parameters["@DueDate"].Value.ToString());
             
                        return GetItem;
                    }

                }
            } catch (Exception ex) {

                throw new Exception(ex.Message);

            }
        }

        /// <summary>
        /// Checks out the item whose ISBN and copy number are specified to the Member whose member number (ID) is specified. 
        /// </summary>
        /// <param name="memberID">Member ID</param>
        /// <param name="itemISBN">ISBN</param>
        /// <param name="itemCopyNumber">Copy Number</param>
        public void CheckOutItem(short memberID, int itemISBN, short itemCopyNumber)
        {
        
            string connectString = @"Data Source=.;Initial Catalog=library;Integrated Security=True";

            try {
                using (

                    // Establishes connection.
                System.Data.SqlClient.SqlConnection cnn =
                    new System.Data.SqlClient.SqlConnection()) {

                    using (
                        // SQL object to run stored procedure.
                        SqlCommand cmd = new SqlCommand()) {

                        // Determines type of command to be run.
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Specifies stored procedure to run.
                        cmd.CommandText = "CheckOutItem";

                        // Specifies command objects parameters.
                        // Input parameter @MemberID, @Isbn, @CopyNo.
                        cmd.Parameters.AddWithValue("MemberID", memberID); 
                        cmd.Parameters.AddWithValue("@Isbn", itemISBN);
                        cmd.Parameters.AddWithValue("@CopyNo", itemCopyNumber);

                        // Initializes ConnectionString property.
                        cnn.ConnectionString = connectString;

                        // Opens connection
                        cnn.Open();

                        // Initializes command connection proerty.
                        cmd.Connection = cnn;

                        // Executes stored procedure
                        cmd.ExecuteNonQuery();

                    }

                }
            } catch (Exception ex) {

                throw new Exception(ex.Message);

            }
        }

        /// <summary>
        /// Checks in the item whose ISBN and copy number are specified. 
        /// </summary>
        /// <param name="itemISBN">ISBN</param>
        /// <param name="itemCopyNumber">Copy Number</param>
        public void CheckInItem(int itemISBN, short itemCopyNumber)
        {
            string connectString = @"Data Source=.;Initial Catalog=library;Integrated Security=True";

            try {
                using (

                    // Establishes connection.
                System.Data.SqlClient.SqlConnection cnn =
                    new System.Data.SqlClient.SqlConnection()) {

                    using (
                        // SQL object to run stored procedure.
                        SqlCommand cmd = new SqlCommand()) {

                        // Determines type of command to be run.
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Specifies stored procedure to run.
                        cmd.CommandText = "CheckInItem";

                        // Specifies command objects parameters.
                        // Input parameter @Isbn, @CopyNo.
                        cmd.Parameters.AddWithValue("@Isbn", itemISBN);
                        cmd.Parameters.AddWithValue("@CopyNo", itemCopyNumber);

                        // Initializes ConnectionString property.
                        cnn.ConnectionString = connectString;

                        // Opens connection
                        cnn.Open();

                        // Initializes command connection proerty.
                        cmd.Connection = cnn;

                        // Executes stored procedure
                        cmd.ExecuteNonQuery();

                    }

                }
            } catch (Exception ex) {

                throw new Exception(ex.Message);

            }
        }

        /// <summary>
        /// Adds the specified Adult Member to the database. 
        /// </summary>
        /// <param name="myMember">Member ID</param>
        public void AddMember(TO.LibraryEntities.LibraryEntities.AdultMember myMember)
        {
            string connectString = @"Data Source=.;Initial Catalog=library;Integrated Security=True";

            try {
                using (

                    // Establishes connection.
                System.Data.SqlClient.SqlConnection cnn =
                    new System.Data.SqlClient.SqlConnection()) {

                    using (
                        // SQL object to run stored procedure.
                        SqlCommand cmd = new SqlCommand()) {

                        // Determines type of command to be run.
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Specifies stored procedure to run.
                        cmd.CommandText = "AddAdultMember";

                        // Specifies command objects parameters.
                        // Input parameters for myMember properties.
                        cmd.Parameters.AddWithValue("@FirstName", myMember.FirstName);
                        cmd.Parameters.AddWithValue("@LastName", myMember.LastName);
                        cmd.Parameters.AddWithValue("@MiddleInitial", myMember.MiddleInitial);
                        cmd.Parameters.AddWithValue("@Street", myMember.Street);
                        cmd.Parameters.AddWithValue("@City", myMember.City);
                        cmd.Parameters.AddWithValue("@State", myMember.State);
                        cmd.Parameters.AddWithValue("@ZipCode", myMember.ZipCode);
                        cmd.Parameters.AddWithValue("@PhoneNumber", myMember.PhoneNumber);

                        // Output parameter @MemberID. 
                        SqlParameter memberParam = new SqlParameter("@MemberID", SqlDbType.SmallInt, 2);
                        memberParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(memberParam);

                        // Output parameter @ExpirationDate.
                        SqlParameter exdateParam = new SqlParameter("@ExpirationDate", SqlDbType.DateTime, 8);
                        exdateParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(exdateParam);

                        // Initializes ConnectionString property.
                        cnn.ConnectionString = connectString;

                        // Opens connection
                        cnn.Open();

                        // Initializes command connection proerty.
                        cmd.Connection = cnn;

                        // Executes stored procedure
                        cmd.ExecuteNonQuery();

                        // Initializes myMember properties from output proc parameters.
                        myMember.MemberID = Convert.ToInt16(cmd.Parameters["@MemberID"].Value.ToString());
                        myMember.ExpirationDate = Convert.ToDateTime(cmd.Parameters["@ExpirationDate"].Value);

                    }

                }
            } catch (Exception ex) {

                throw new Exception(ex.Message);

            }
        }

        /// <summary>
        /// Adds the specified Adult Member to the database. 
        /// </summary>
        /// <param name="memberID">Member ID</param>
        public void RenewCard(short memberID) {
            string connectString = @"Data Source=.;Initial Catalog=library;Integrated Security=True";

            try {
                using (

                    // Establishes connection.
                System.Data.SqlClient.SqlConnection cnn =
                    new System.Data.SqlClient.SqlConnection()) {

                    using (
                        // SQL object to run stored procedure.
                        SqlCommand cmd = new SqlCommand()) {

                        // Determines type of command to be run.
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Specifies stored procedure to run.
                        cmd.CommandText = "RenewCard";

                        // Specifies command objects parameters.
                        // Input parameters for myMember properties.
                        cmd.Parameters.AddWithValue("MemberID", memberID); 

                        // Initializes ConnectionString property.
                        cnn.ConnectionString = connectString;

                        // Opens connection
                        cnn.Open();

                        // Initializes command connection proerty.
                        cmd.Connection = cnn;

                        // Executes stored procedure
                        cmd.ExecuteNonQuery();
      
                    }

                }
            } catch (Exception ex) {

                throw new Exception(ex.Message);

            }
        }

        /// <summary>
        /// Adds the specified Juvenile Member to the database. 
        /// </summary>
        /// <param name="myMember">Member ID</param>
        public void AddMember(TO.LibraryEntities.LibraryEntities.JuvenileMember myMember)
        {
            string connectString = @"Data Source=.;Initial Catalog=library;Integrated Security=True";

            try {
                using (

                    // Establishes connection.
                System.Data.SqlClient.SqlConnection cnn =
                    new System.Data.SqlClient.SqlConnection()) {

                    using (
                        // SQL object to run stored procedure.
                        SqlCommand cmd = new SqlCommand()) {

                        // Determines type of command to be run.
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Specifies stored procedure to run.
                        cmd.CommandText = "AddJuvenileMember";

                        // Specifies command objects parameters.
                        // Input parameters for myMember properties.
                        cmd.Parameters.AddWithValue("@FirstName", myMember.FirstName);
                        cmd.Parameters.AddWithValue("@LastName", myMember.LastName);
                        cmd.Parameters.AddWithValue("@MiddleInitial", myMember.MiddleInitial);
                        cmd.Parameters.AddWithValue("@AdultMemberID", myMember.AdultMemberID);
                        cmd.Parameters.AddWithValue("@BirthDate", myMember.BirthDate);

                        // Output parameter @Street.
                        SqlParameter strParam = new SqlParameter("@Street", SqlDbType.VarChar, 15);
                        strParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(strParam);

                        // Output parameter @City.
                        SqlParameter cityParam = new SqlParameter("@City", SqlDbType.VarChar, 15);
                        cityParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(cityParam);

                        // Output parameter @State.
                        SqlParameter stateParam = new SqlParameter("@State", SqlDbType.VarChar, 2);
                        stateParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(stateParam);

                        // Output parameter @ZipCode.
                        SqlParameter zipParam = new SqlParameter("@ZipCode", SqlDbType.VarChar, 10);
                        zipParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(zipParam);

                        // Output parameter @PhoneNumber.
                        SqlParameter phoneParam = new SqlParameter("@PhoneNumber", SqlDbType.Char, 2);
                        phoneParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(phoneParam);

                        // Output parameter @MemberID. 
                        SqlParameter memberParam = new SqlParameter("@MemberID", SqlDbType.SmallInt, 2);
                        memberParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(memberParam);

                        // Output parameter @ExpirationDate.
                        SqlParameter exdateParam = new SqlParameter("@ExpirationDate", SqlDbType.DateTime, 8);
                        exdateParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(exdateParam);

                        // Initializes ConnectionString property.
                        cnn.ConnectionString = connectString;

                        // Opens connection
                        cnn.Open();

                        // Initializes command connection proerty.
                        cmd.Connection = cnn;

                        // Executes stored procedure
                        cmd.ExecuteNonQuery();

                        // Initializes myMember properties from output proc parameters.
                        myMember.MemberID = Convert.ToInt16(cmd.Parameters["@MemberID"].Value.ToString());
                        myMember.Street = cmd.Parameters["@Street"].Value.ToString();
                        myMember.City = cmd.Parameters["@City"].Value.ToString();
                        myMember.State = cmd.Parameters["@State"].Value.ToString();
                        myMember.ZipCode = cmd.Parameters["@ZipCode"].Value.ToString();
                        myMember.PhoneNumber = cmd.Parameters["@PhoneNumber"].Value.ToString();
                        myMember.ExpirationDate = Convert.ToDateTime(cmd.Parameters["@ExpirationDate"].Value);

                    }

                }
            } catch (Exception ex) {

                throw new Exception(ex.Message);

            }
        }

        /// <summary>
        /// Converts a Juvenile member to an Adult member
        /// </summary>
        /// <param name="myMember">Member ID</param>
        public void Juvenile2Adult(TO.LibraryEntities.LibraryEntities.Member myMember) {

            string connectString = @"Data Source=.;Initial Catalog=library;Integrated Security=True";

            try {
                using (

                    // Establishes connection.
                System.Data.SqlClient.SqlConnection cnn =
                    new System.Data.SqlClient.SqlConnection()) {

                    using (
                        // SQL object to run stored procedure.
                        SqlCommand cmd = new SqlCommand()) {

                        // Determines type of command to be run.
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Specifies stored procedure to run.
                        cmd.CommandText = "MakeJuvenileAdult";

                        // Specifies command objects parameters.
                        // Input parameters for myMember properties.
                        cmd.Parameters.AddWithValue("@MemberID", myMember.MemberID);
                        cmd.Parameters.AddWithValue("@Street", myMember.Street);
                        cmd.Parameters.AddWithValue("@City", myMember.City);
                        cmd.Parameters.AddWithValue("@State", myMember.State);
                        cmd.Parameters.AddWithValue("@ZipCode", myMember.ZipCode);
                        cmd.Parameters.AddWithValue("@PhoneNumber", myMember.PhoneNumber);
                        cmd.Parameters.AddWithValue("@ExpirationDate", myMember.ExpirationDate);

                        // Initializes ConnectionString property.
                        cnn.ConnectionString = connectString;

                        // Opens connection
                        cnn.Open();

                        // Initializes command connection proerty.
                        cmd.Connection = cnn;

                        // Executes stored procedure
                        cmd.ExecuteNonQuery();

                    }

                }
            } catch (Exception ex) {

                throw new Exception(ex.Message);

            }
        }

        /// <summary>
        /// Checks if member is a juvenile
        /// </summary>
        /// <param name="memberId">Member ID</param>
        /// <returns><see cref="System.Boolean"/>Boolean</returns>
        public int CheckIDJuvenile(short memberId) {
            string connectString = @"Data Source=.;Initial Catalog=library;Integrated Security=True";

            int myMemberAge;

            try {
                using (

                    // Establishes connection.
                System.Data.SqlClient.SqlConnection cnn =
                    new System.Data.SqlClient.SqlConnection()) {

                    using (
                        // SQL object to run stored procedure.
                        SqlCommand cmd = new SqlCommand()) {

                        // Determines type of command to be run.
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Specifies stored procedure to run.
                        cmd.CommandText = "CheckIDJuvenile";

                        // Specifies command objects parameters.
                        // Input parameters for myMember properties.
                        cmd.Parameters.AddWithValue("MemberID",memberId);

                        // Output parameter @MemberAge.
                        SqlParameter memberageParam = new SqlParameter("@MemberAge", SqlDbType.SmallInt);
                        memberageParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(memberageParam);

                        // Initializes ConnectionString property.
                        cnn.ConnectionString = connectString;

                        // Opens connection
                        cnn.Open();

                        // Initializes command connection proerty.
                        cmd.Connection = cnn;

                        // Executes stored procedure
                        cmd.ExecuteNonQuery();

                        // Captures member's age
                        myMemberAge = Convert.ToInt16(cmd.Parameters["@MemberAge"].Value);

                        // Returns member age.
                        return myMemberAge;
                    }

                }
            } catch (Exception ex) {

                throw new Exception(ex.Message);

            }
        }
    }
}