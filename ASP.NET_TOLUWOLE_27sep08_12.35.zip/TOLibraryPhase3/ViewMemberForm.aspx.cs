using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using TO.LibraryBusiness;
using TO.LibraryEntities;
using System.Drawing;
using System.Text;


public partial class ViewMemberForm : System.Web.UI.Page {

    /// <summary>
    /// Event handler for when the View Member form loads.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Object info.</param>
    protected void Page_Load(object sender, EventArgs e) {

        // Hides Check Out Item text box objects on form load.
        this.textboxISBN.Visible = true;
        this.textboxCopyNumber.Visible = true;
        this.btnRenew.Visible = false;
    }

    #region MyEvents


    /// <summary>
    /// Event handler for when View Member button is clicked.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Object info.</param>
    protected void buttonViewMemberInfo_Click(object sender, EventArgs e) {

        // Validates all controls on the View Member page.
        if (this.IsValid == true) {

            // Casts text of MemberID to short
            short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

            // Creates the object that provides data.
            LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            try {
                // Gets member data.
                LibraryEntities.Member foundMember = lbl.GetInformation(validMemberID);

                // Checks if member is a Juvenile.
                bool checkjuv18 = lbl.IsJuvenile(validMemberID);

                if (checkjuv18 == true) {
                    // Convert member to adult if juvenile's age >=18.
                    lbl.MakeAdult(foundMember);
                }

                // Populates View Member form with property values.
                this.textboxExpiryDate.Text = foundMember.ExpirationDate.ToString("d");
                this.textboxFirstName.Text = foundMember.FirstName;
                this.textboxMiddleInit.Text = foundMember.MiddleInitial;
                this.textboxLastName.Text = foundMember.LastName;
                this.textboxStreet.Text = foundMember.Street;
                this.textboxCity.Text = foundMember.City;
                this.textboxState.Text = foundMember.State;
                this.textboxZipCode.Text = foundMember.ZipCode;
                this.textboxPhone.Text = foundMember.PhoneNumber;

                //// Enables Check Out Item button if Disabled.
                //if (this.buttonCheckOutItem.Enabled == false) {
                //    this.buttonCheckOutItem.Enabled = true;
                //}

                //// Hides Check Out Item text box objects if visible.
                //if (this.textboxISBN.Visible == true) {

                //    this.textboxISBN.Visible = false;
                //    this.textboxCopyNumber.Visible = false;
                //}

                // Alerts user if Member card is expired highlighting expired date.
                if (foundMember.ExpirationDate <= DateTime.Now) {
                    this.labelMemberAlert.Text = "message board:\n\n " + this.textboxFirstName.Text + " " +
                    this.textboxLastName.Text + "'s card has expired. Please renew to check out items.";
                    this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;
                    this.textboxExpiryDate.ReadOnly = false;
                    this.textboxExpiryDate.BackColor = SystemColors.InactiveCaptionText;
                    this.textboxExpiryDate.ReadOnly = true;

                    // Show renew and do not renew button so librarian can decide
                    this.btnRenew.Visible = true;

                    // Enables Check Out Item button.
                    this.buttonCheckOutItem.Enabled = true;

                } else {
                    this.labelMemberAlert.Text = "message board";
                    this.labelMemberAlert.ForeColor = SystemColors.ButtonShadow;
                    this.textboxExpiryDate.ReadOnly = false;
                    this.textboxExpiryDate.BackColor = SystemColors.ActiveCaptionText;
                    this.textboxExpiryDate.ReadOnly = true;

                }

                // Gets member's checked out items data
                ItemsDataSet foundItemsDataSet = lbl.GetViewMemberGrid(validMemberID);



            } catch (FormatException fe) {

                DisplayInMessageBoard("\n" + fe.Message);

            } catch (ArgumentOutOfRangeException ae) {

                DisplayInMessageBoard("\n" + ae.Message);

            } catch (LibraryException le) {

                DisplayInMessageBoard("\n" + le.Message + " " +
                    le.LibraryErrorCode.ToString() + ".");

            } catch (Exception ex) {

                DisplayInMessageBoard("\n" + ex.Message);
            }
        }
    }

    /// <summary>
    /// Event handler for when the Check Out Item button is clicked.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Object info.</param>
    protected void buttonCheckOutItem_Click(object sender, EventArgs e) {

           // Makes sure the the member ID entered matches the member data
            // in case the user has entered a new Member ID but has not 
            // clicked the View Member Information button to update the form
            buttonViewMemberInfo_Click(sender, e);

            // Re-validates that the member record is valid for item check out.
            buttonCheckOutItem_MouseHover(sender, e);

            
            // Validates all controls on the View Member form
            if (this.IsValid==true) {

                try {
                    // Casts text of Member ID to short.
                    short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

                    // Casts text of Copy Number to int.
                    int validISBN = Convert.ToInt32(this.textboxISBN.Text);

                    // Casts text of Copy Number to short.
                    short validCopyNumber = Convert.ToInt16(this.textboxCopyNumber.Text);

                    

                    // Creates the object that provides data.
                    LibraryBusinessLayer lbl = new LibraryBusinessLayer();

                    // Checks to see if user wants to check item out. 
                    // If user says no, operation is cancelled.
                    // If user says yes, checks if book is listed as on-loan
                    // If on-loan, let user check item in first before checking out.
                    // If not on-loan let's user check out.
                    //if (MessageBox.Show("Do you still want to check out this item?",
                    //    "Item Check Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {

                        DisplayInMessageBoard("Attempting to check out item.");

                        try {

                            // Attempts to checkout item.
                            lbl.GetCheckOutItem(validMemberID, validISBN, validCopyNumber);

                            // Refreshes Member information.
                            buttonViewMemberInfo_Click(sender, e);
                                                        
                            DisplayInMessageBoard("Item checked out.");

                        } catch (ArgumentOutOfRangeException ae) {

                            DisplayInMessageBoard(ae.Message);

                        } catch (LibraryException le) {

                            DisplayInMessageBoard(le.Message + " " +
                               le.LibraryErrorCode.ToString() + " by Member " +
                               le.OtherMemberID + ". Item must be checked in first.");

                            // Disables Check Out Item button.
                            buttonCheckOutItem.Enabled = false;

                        //    if (MessageBox.Show("Would you like to check in this item first?",
                        //"Item Check Out", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {

                        //        // Attempts to check in item.
                        //        lbl.SetCheckInItem(validISBN, validCopyNumber);

                        //        // Attempts to check out item.
                        //        lbl.GetCheckOutItem(validMemberID, validISBN, validCopyNumber);

                        //        // Refreshes Member information.
                        //        buttonViewMemberInfo_Click(sender, e);

                        //        DisplayInMessageBoard("Item checked in, and then checked out.");

                           
                                DisplayInMessageBoard("Item not checked out.");
                            
                        } catch (Exception ex) {

                            DisplayInMessageBoard("\n" + ex.Message);
                        }
                         

                    //} else {
                    //    DisplayInMessageBoard("Item not checked out.");
                    //}
   

                } catch (FormatException fe) {

                    DisplayInMessageBoard("\n" + fe.Message);
                
                } catch (ArgumentOutOfRangeException ae) {

                    DisplayInMessageBoard(ae.Message);

                } catch (LibraryException le) {

                    DisplayInMessageBoard("\n" + le.Message + " " +
                       le.LibraryErrorCode.ToString() + ".");

                } catch (Exception ex) {

                    DisplayInMessageBoard("\n" + ex.Message);
                }
            }


        }

        /// <summary>
        /// Event handler for when the mouse pointer is over the Check In Item button.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        protected void buttonCheckInItems_MouseHover(object sender, EventArgs e) {


            // Hides Member ID text box and label until needed.
            this.labelMemberID.Visible=false;
            this.textboxMemberID.Visible=false;
            this.textboxMemberID.Text = "1";

            // Shows ISBN and Copy Number text box objects.
            this.textboxISBN.Visible = true;
            this.textboxCopyNumber.Visible = true;

            DisplayInMessageBoard("Enter ISBN and Copy Number below.");

        }

        /// <summary>
        /// Event handler for when the Check In Item button is clicked.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
    protected void buttonCheckInItems_Click(object sender, EventArgs e) {
        // Validates all controls on the View Member form
        if (this.IsValid) {

            try {
                // Casts text of Member ID to short.
                //short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

                // Casts text of Copy Number to int.
                int validISBN = Convert.ToInt32(this.textboxISBN.Text);

                // Casts text of Copy Number to short.
                short validCopyNumber = Convert.ToInt16(this.textboxCopyNumber.Text);


                // Creates the object that provides data.
                LibraryBusinessLayer lbl = new LibraryBusinessLayer();

                // Gets item data.
                TO.LibraryEntities.LibraryEntities.Item foundItem = lbl.GetItemInfo(validISBN, validCopyNumber);

                // Throw LibraryException if item not on loan, and
                // If on loan, checks item in.
                if (foundItem.MemberNumber == 0) {

                    // Shows Member ID text box and label.
                    this.textboxMemberID.Text = "";
                    this.labelMemberID.Visible = true;
                    this.textboxMemberID.Visible = true;

                    // Disables Check Out Item button.
                    this.buttonCheckOutItem.Enabled = true;

                    throw new LibraryException(ErrorCode.ItemNotOnLoan);

                } else {
                    // Hides Member ID text box and label.
                    this.labelMemberID.Visible = false;
                    this.textboxMemberID.Visible = false;

                    // Places Member ID into text box after converting.
                    this.textboxMemberID.Text = Convert.ToString(foundItem.MemberNumber);

                    // Shows Member ID text box and label.
                    this.labelMemberID.Visible = true;
                    this.textboxMemberID.Visible = true;

                    // Shows item and member info based on ISBN and Copy Number if 
                    // item is on loan.
                    buttonViewMemberInfo_Click(sender, e);

                    // Get item.
                    StringBuilder myPreCheckInItem = new StringBuilder("");

                    myPreCheckInItem.Append(validISBN + ",");
                    myPreCheckInItem.Append(validCopyNumber + ",");
                    myPreCheckInItem.Append(foundItem.Title + ",");
                    myPreCheckInItem.Append(foundItem.Author);


                    // Attempts to check in item.
                    lbl.SetCheckInItem(validISBN, validCopyNumber);

                    // Refreshes Member information.
                    buttonViewMemberInfo_Click(sender, e);

                    DisplayInMessageBoard("Item checked in.");

                }


            } catch (ArgumentOutOfRangeException ae) {

                DisplayInMessageBoard(ae.Message);

            } catch (LibraryException le) {

                DisplayInMessageBoard(le.Message + " " +
                           le.LibraryErrorCode.ToString());
            } catch (Exception ex) {

                DisplayInMessageBoard("\n" + ex.Message);
            }

        }
    }

        /// <summary>
        /// Event handler for when the mouse pointer is over the Check Out Item button.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        protected void buttonCheckOutItem_MouseHover(object sender, EventArgs e) {
            // Validates all controls on the View Member form
            if (!this.IsValid) {

                // Disables Check Out Item button.
                this.buttonCheckOutItem.Enabled = false;

                // Check if Expiry Date field is blank.
            } else if (this.textboxExpiryDate.Text == "") {


                this.labelMemberAlert.Text = "message board:\n\n Enter Member ID " +
                   "and click View Member Information button.";
                this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;

                // Disables Check Out Item button.
                this.buttonCheckOutItem.Enabled = false;


                // Check if Member's card has expired.
            } else if (this.textboxExpiryDate.BackColor == SystemColors.InactiveCaptionText) {

                this.labelMemberAlert.Text = "message board:\n\n Member card expired. " +
                    "Please renew for check out.";
                this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;

                // Show renew and do not renew button so librarian can decide
                this.btnRenew.Visible = true;


                // Disables Check Out Item button.
                this.buttonCheckOutItem.Enabled = false;

            } else {

                // Number of items member can check out.
                int bookCheckOutable = 4 - viewmemberGridView.Rows.Count;

                // Lets user know how many items member can check out.
                if (bookCheckOutable == 0) {
                    DisplayInMessageBoard("Member cannot check out anymore items.");

                    // Disables Check Out Item button.
                    this.buttonCheckOutItem.Enabled = false;
                } else {

                    // Shows ISBN and Copy Number text box objects.
                    this.textboxISBN.Visible = true;
                    this.textboxCopyNumber.Visible = true;
                    DisplayInMessageBoard("Member can check out up to " + bookCheckOutable +
                        " item(s). Enter ISBN and Copy Number below.");

                }
            }
        }

    /// <summary>
    /// Renews member card.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Event data</param>
    protected void btnRenew_Click(object sender, EventArgs e) {

        // Creates the object that captures data.
        LibraryBusinessLayer lbl = new LibraryBusinessLayer();

        try {
            // Create object for current member.
            LibraryEntities.Member currentMember = new LibraryEntities.Member();

            // Renew member card expiration date
            lbl.SetExpiryDate(currentMember.MemberID);

            DisplayInMessageBoard("Card renewed.");

            // Hide renew button once complete.
            this.btnRenew.Visible = false;

        } catch (FormatException fe) {
            
           DisplayInMessageBoard("\n" + fe.Message);

        } catch (ArgumentOutOfRangeException ae) {

            DisplayInMessageBoard("\n" + ae.Message);

        } catch (LibraryException le) {

            DisplayInMessageBoard("\n" + le.Message + " " +
                le.LibraryErrorCode.ToString() + ".");

        } catch (Exception ex) {

            DisplayInMessageBoard("\n" + ex.Message);
        }

    }

#endregion

        #region MyMethods

        /// <summary>
        /// Changes the View Member form's messageboard label text.
        /// </summary>
        /// <param name="myCaption">String representing text to change.</param>
        public void DisplayInMessageBoard (string myCaption){
            this.labelMemberAlert.Text = "message board:\n " + myCaption;
            // Brightens the text color.
            this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;
        }

        #endregion
    }             
    

