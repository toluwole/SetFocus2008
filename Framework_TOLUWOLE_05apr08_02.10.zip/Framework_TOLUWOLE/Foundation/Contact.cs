using System;
using System.Collections.Generic;
using System.Text;

namespace Foundation {
    /// <summary>
    /// Base class for abstractions with contact information.
    /// </summary>
    public abstract class Contact : IContactInfo {

        #region Field members

        /// <summary>
        /// Integer field declaration.
        /// </summary>
        protected int id;

        /// <summary>
        /// String field declaration.
        /// </summary>
        protected string companyName, contactName, contactTitle,
            address, city, region, postalCode, country, phone, fax;



        #endregion

        #region ICompanyContact Members
        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        //Try ... Catch blocks not correct for properties.  DJL
        public virtual int ID {
            get { return id; }
            set {
                if ((value >= 1) && (value <= 99999))
                    id = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a value from 1 to 99999 for ID.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string CompanyName {
            get { return companyName; }
            set {
                if (value == null)
                    throw new NullReferenceException("CompanyName cannot be null");
                if ((value.Length >= 1) && (value.Length <= 40))
                    companyName = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a CompanyName of at least one " +
                    "character and no longer than 40.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string ContactName {
            get { return contactName; }
            set {
                if (value == null)
                    throw new NullReferenceException("ContactName cannot be null");
                if ((value.Length >= 1) && (value.Length <= 30))
                    contactName = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a ContactName of at least one " +
                        "character and no longer than 30.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string ContactTitle {
            get { return contactTitle; }
            set {
                if (value == null)
                    throw new NullReferenceException("ContactTitle cannot be null");
                if ((value.Length >= 1) && (value.Length <= 30))
                    contactTitle = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a ContactTitle of at least one " +
                     "character and no longer than 30.");
            }
        }

        #endregion

        #region IAddress Members

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string Address {
            get { return address; }
            set {
                if (value == null)
                    throw new NullReferenceException("Address cannot be null");
                if ((value.Length >= 1) && (value.Length <= 60))
                    address = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide an Address of at least one " +
                        "character and no longer than 60.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string City {
            get { return city; }
            set {
                if (value == null)
                    throw new NullReferenceException("City cannot be null");
                if ((value.Length >= 1) && (value.Length <= 15))
                    city = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a City of at least one " +
                        "character and no longer than 15.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string Region {
            get { return region; }
            set {
                if (value == null)
                    throw new NullReferenceException("Region cannot be null");
                if ((value.Length >= 1) && (value.Length <= 15))
                    region = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a Region of at least one " +
                        "character and no longer than 15.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string PostalCode {
            get { return postalCode; }
            set {
                if (value == null)
                    throw new NullReferenceException("PostalCode cannot be null");
                if ((value.Length >= 1) && (value.Length <= 10))
                    postalCode = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a PostalCode of at least one " +
                        "character and no longer than 10.");
            }
        }

        #endregion

        #region ICountryPhone Members

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string Country {
            get { return country; }
            set {
                if (value == null)
                    throw new NullReferenceException("Country cannot be null");
                if ((value.Length >= 1) && (value.Length <= 15))
                    country = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a Country of at least one " +
                        "character and no longer than 15.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range
        /// </summary>.
        public virtual string Phone {
            get { return phone; }
            set {
                if (value == null)
                    throw new NullReferenceException("Phone cannot be null");
                if ((value.Length >= 1) && (value.Length <= 24))
                    phone = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a Phone of at least one " +
                        "character and no longer than 24.");
            }
        }

        /// <summary>
        /// Property definition that throw ArgumentOutOfRangeException if property input is out 
        /// of range.
        /// </summary>
        public virtual string Fax {
            get { return fax; }
            set {
                if (value == null)
                    throw new NullReferenceException("Fax cannot be null");
                if ((value.Length >= 1) && (value.Length <= 24))
                    fax = value;
                else
                    throw new ArgumentOutOfRangeException("Please provide a Fax of at least one " +
                        "character and no longer than 24.");
            }
        }

        #endregion

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public Contact() {

        }

        /// <summary>
        /// Overriding constructor
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="CompanyName">CompanyName</param>
        /// <param name="ContactName">ContactName</param>
        /// <param name="ContactTitle">ContactTitle</param>
        /// <param name="Address">Address</param>
        /// <param name="City">City</param>
        /// <param name="Region">Region</param>
        /// <param name="PostalCode">PostalCode</param>
        /// <param name="Country">Country</param>
        /// <param name="Phone">Phone</param>
        /// <param name="Fax">Fax</param>
        public Contact(int ID, string CompanyName, string ContactName,
            string ContactTitle, string Address, string City, string Region,
            string PostalCode, string Country, string Phone, string Fax) {

            this.ID = ID;
            this.CompanyName = CompanyName;
            this.ContactName = ContactName;
            this.ContactTitle = ContactTitle;
            this.Address = Address;
            this.City = City;
            this.Region = Region;
            this.PostalCode = PostalCode;
            this.Country = Country;
            this.Phone = Phone;
            this.Fax = Fax;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Abstract method ContactInfo.
        /// </summary>
        /// <returns>An instance of <see cref="System.Text.StringBuilder"/></returns>
        public abstract StringBuilder ContactInfo();

        #endregion
    }
}


