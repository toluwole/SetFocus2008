using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.Services.Protocols;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//using TO.LibraryBusiness;
//using TO.LibraryEntities;
using System.Drawing;
using System.Text;
using System.Threading;
using LibraryWR;


public partial class ViewMemberForm : System.Web.UI.Page {

    /// <summary>
    /// Event handler for when the View Member form loads.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Object info.</param>
    protected void Page_Load(object sender, EventArgs e) {

        // Hides certain textbox and button objects on form load.
        this.textboxISBN.Visible = true;
        this.textboxCopyNumber.Visible = true;
        this.btnRenew.Visible = false;
        this.buttonNo.Visible = false;
        this.buttonYes.Visible = false;
    }

    #region MyEvents


    /// <summary>
    /// Event handler for when View Member button is clicked.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Object info.</param>
    protected void buttonViewMemberInfo_Click(object sender, EventArgs e) {

        // Validates all controls on the View Member page.
        if ((reqfldvalidatorMemberID.IsValid == true) && (rangevalidatorMemberID.IsValid == true)) {

            // Casts text of MemberID to short
            short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

            // Creates the object that provides data.
            //LibraryBusinessLayer lbl = new LibraryBusinessLayer();

            // Creates instance of proxy object.
            LibraryWR.Service myLibraryService = new LibraryWR.Service();

            try {
                // Gets member data.
                //LibraryEntities.Member foundMember = lbl.GetInformation(validMemberID);
                Member foundMember =  myLibraryService.wsGetInformation(validMemberID);
                
                // Checks if member is a Juvenile.
                //bool change2Adult = lbl.IsJuvenile(validMemberID);
                bool change2Adult = myLibraryService.wsIsJuvenile(validMemberID);

                if (change2Adult == true) {
                    // Convert member to adult if juvenile's age >=18.
                    //lbl.MakeAdult(foundMember);
                    myLibraryService.wsMakeAdult(foundMember);
                }

                // Populates View Member form with property values.
                this.textboxExpiryDate.Text = foundMember.ExpirationDate.ToString("d");
                this.textboxFirstName.Text = foundMember.FirstName;
                this.textboxMiddleInit.Text = foundMember.MiddleInitial;
                this.textboxLastName.Text = foundMember.LastName;
                this.textboxStreet.Text = foundMember.Street;
                this.textboxCity.Text = foundMember.City;
                this.textboxState.Text = foundMember.State;
                this.textboxZipCode.Text = foundMember.ZipCode;
                this.textboxPhone.Text = foundMember.PhoneNumber;

                // Alerts user if Member card is expired highlighting expired date.
                if (foundMember.ExpirationDate <= DateTime.Now) {
                    this.labelMemberAlert.Text = "message board:\n\n " + this.textboxFirstName.Text + " " +
                    this.textboxLastName.Text + "'s card has expired. Please renew to check out items.";
                    this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;
                    this.textboxExpiryDate.ReadOnly = false;
                    this.textboxExpiryDate.BackColor = SystemColors.InactiveCaptionText;
                    this.textboxExpiryDate.ReadOnly = true;

                    // Show renew and do not renew button so librarian can decide
                    this.btnRenew.Visible = true;

                    // Enables Check Out Item button.
                    this.buttonCheckOutItem.Enabled = true;

                } else {
                    this.labelMemberAlert.Text = "message board";
                    this.labelMemberAlert.ForeColor = SystemColors.ButtonShadow;
                    this.textboxExpiryDate.ReadOnly = false;
                    this.textboxExpiryDate.BackColor = SystemColors.ActiveCaptionText;
                    this.textboxExpiryDate.ReadOnly = true;

                }

                // Gets member's checked out items data
                //ItemsDataSet foundItemsDataSet = lbl.GetViewMemberGrid(validMemberID);
                ItemsDataSet foundItemsDataSet = myLibraryService.wsGetViewMemberGrid(validMemberID);

                // Binds items to grid
                viewmemberGridView.DataBind();
                // Highlights late items
                if (viewmemberGridView.Rows.Count>0) {
                    HighlightLateItem();
                }

            } catch (FormatException fe) {

                DisplayInMessageBoard("\n" + fe.Message);

            } catch (ArgumentOutOfRangeException ae) {

                DisplayInMessageBoard("\n" + ae.Message);

            } catch (SoapException se) {

                DisplayInMessageBoard("\n" + se.Message + " " +
                    se.InnerException.Message + ".");

            } catch (Exception ex) {

                DisplayInMessageBoard("\n" + ex.Message);
            }
        } else {
            DisplayInMessageBoard("\n" + "Member ID required and must inbetween 1 and 32767");
        }
    }


/// <summary>
    /// Event handler for when the Check Out Item button is clicked.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Object info.</param>
    protected void buttonCheckOutItem_Click(object sender, EventArgs e) {

           // Makes sure the the member ID entered matches the member data
            // in case the user has entered a new Member ID but has not 
            // clicked the View Member Information button to update the form
            buttonViewMemberInfo_Click(sender, e);

  
            // Validates all controls on the View Member form
            if (this.IsValid==true) {

                try {
                    // Casts text of Member ID to short.
                    short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

                    // Casts text of Copy Number to int.
                    int validISBN = Convert.ToInt32(this.textboxISBN.Text);

                    // Casts text of Copy Number to short.
                    short validCopyNumber = Convert.ToInt16(this.textboxCopyNumber.Text);

                    

                    // Creates the object that provides data.
                    //LibraryBusinessLayer lbl = new LibraryBusinessLayer();
                    // Creates instance of proxy object.
                    LibraryWR.Service myLibraryService = new LibraryWR.Service();
           
                        DisplayInMessageBoard("Attempting to check out item.");

                        try {

                            // Attempts to checkout item.
                            //lbl.GetCheckOutItem(validMemberID, validISBN, validCopyNumber);
                            myLibraryService.wsGetCheckOutItem(validMemberID, validISBN, validCopyNumber);

                            // Refreshes Member information.
                            buttonViewMemberInfo_Click(sender, e);
                                                        
                            DisplayInMessageBoard("Item checked out.");

                        } catch (ArgumentOutOfRangeException ae) {

                            DisplayInMessageBoard(ae.Message);

                        } catch (SoapException se) {

                            DisplayInMessageBoard(se.Message + " " +
                               se.InnerException.Message + ". Item must be checked in first.");

                            // Disables Check Out Item button.
                            buttonCheckOutItem.Enabled = false;
                          
                            DisplayInMessageBoard("Item not checked out.");
                            
                        } catch (Exception ex) {

                            DisplayInMessageBoard("\n" + ex.Message);
                        }
                        
                } catch (FormatException fe) {

                    DisplayInMessageBoard("\n" + fe.Message);
                
                } catch (ArgumentOutOfRangeException ae) {

                    DisplayInMessageBoard(ae.Message);

                } catch (SoapException se) {

                    DisplayInMessageBoard("\n" + se.Message + " " +
                        se.InnerException.Message + ".");

                } catch (Exception ex) {

                    DisplayInMessageBoard("\n" + ex.Message);
                }
            }
            
        }

        /// <summary>
        /// Event handler for when the mouse pointer is over the Check In Item button.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        protected void buttonCheckInItems_MouseHover(object sender, EventArgs e) {


            // Hides Member ID text box and label until needed.
            this.labelMemberID.Visible=false;
            this.textboxMemberID.Visible=false;
            this.textboxMemberID.Text = "1";

            // Shows ISBN and Copy Number text box objects.
            this.textboxISBN.Visible = true;
            this.textboxCopyNumber.Visible = true;

            DisplayInMessageBoard("Enter ISBN and Copy Number below.");

        }

        /// <summary>
        /// Event handler for when the Check In Item button is clicked.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
    protected void buttonCheckInItems_Click(object sender, EventArgs e) {
        // Validates all controls on the View Member form
        if (this.IsValid) {

            try {
                // Casts text of Member ID to short.
                //short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

                // Casts text of Copy Number to int.
                int validISBN = Convert.ToInt32(this.textboxISBN.Text);

                // Casts text of Copy Number to short.
                short validCopyNumber = Convert.ToInt16(this.textboxCopyNumber.Text);


                // Creates the object that provides data.
                //LibraryBusinessLayer lbl = new LibraryBusinessLayer();

                // Creates instance of proxy object.
                LibraryWR.Service myLibraryService = new LibraryWR.Service();


                // Gets item data.
                //TO.LibraryEntities.LibraryEntities.Item foundItem = lbl.GetItemInfo(validISBN, validCopyNumber);
                Item foundItem = myLibraryService.wsGetItemInfo(validISBN, validCopyNumber);

                // Throw LibraryException if item not on loan, and
                // If on loan, checks item in.
                if (foundItem.membernumber == 0) {

                    throw new SoapException("Item not on loan", SoapException.ClientFaultCode,
                        Context.Request.Url.AbsoluteUri);

                } else {
                    // Hides Member ID text box and label.
                    this.labelMemberID.Visible = false;
                    this.textboxMemberID.Visible = false;

                    // Places Member ID into text box after converting.
                    this.textboxMemberID.Text = Convert.ToString(foundItem.membernumber);

                    // Shows Member ID text box and label.
                    this.labelMemberID.Visible = true;
                    this.textboxMemberID.Visible = true;

                    // Shows item and member info based on ISBN and Copy Number if 
                    // item is on loan.
                    buttonViewMemberInfo_Click(sender, e);

                    // Get item.
                    StringBuilder myPreCheckInItem = new StringBuilder("");

                    myPreCheckInItem.Append(validISBN + ",");
                    myPreCheckInItem.Append(validCopyNumber + ",");
                    myPreCheckInItem.Append(foundItem.Title + ",");
                    myPreCheckInItem.Append(foundItem.Author);


                    // Attempts to check in item.
                    //lbl.SetCheckInItem(validISBN, validCopyNumber);
                    myLibraryService.wsSetCheckInItem(validISBN, validCopyNumber);

                    // Refreshes Member information.
                    buttonViewMemberInfo_Click(sender, e);

                    DisplayInMessageBoard("Item checked in.");

                }


            } catch (ArgumentOutOfRangeException ae) {

                DisplayInMessageBoard(ae.Message);

            } catch (SoapException se) {

                DisplayInMessageBoard("\n" + se.Message + " " +
                    se.InnerException.Message + ".");

            } catch (Exception ex) {

                DisplayInMessageBoard("\n" + ex.Message);
            }

        }
    }

    /// <summary>
    /// Event handler for when the mouse pointer is over the Check Out Item button.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Object info.</param>
    protected void buttonCheckOutItem_MouseHover(object sender, EventArgs e) {
        
            // Validates all controls on the View Member form
            if (!this.IsValid) {

                // Check if Expiry Date field is blank.
            } else if (this.textboxExpiryDate.Text == "") {


                this.labelMemberAlert.Text = "message board:\n\n Enter Member ID " +
                   "and click View Member Information button.";
                this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;

                // Check if Member's card has expired.
            } else if (this.textboxExpiryDate.BackColor == SystemColors.InactiveCaptionText) {

                this.labelMemberAlert.Text = "message board:\n\n Member card expired. " +
                    "Please renew for check out.";
                this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;

                // Show renew and do not renew button so librarian can decide
                this.btnRenew.Visible = true;

            } else {

                // Number of items member can check out.
                int bookCheckOutable = 4 - viewmemberGridView.Rows.Count;

                // Lets user know how many items member can check out.
                if (bookCheckOutable <= 0) {

                    DisplayInMessageBoard("Member cannot check out anymore items.");

                } else {

                    try {
                        // Casts text of Member ID to short.
                        short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);

                        // Casts text of Copy Number to int.
                        int validISBN = Convert.ToInt32(this.textboxISBN.Text);

                        // Casts text of Copy Number to short.
                        short validCopyNumber = Convert.ToInt16(this.textboxCopyNumber.Text);

                        // Creates the object that provides data.
                        //LibraryBusinessLayer lbl = new LibraryBusinessLayer();

                        // Creates instance of proxy object.
                        LibraryWR.Service myLibraryService = new LibraryWR.Service();

                        // Gets item data.
                        //TO.LibraryEntities.LibraryEntities.Item foundItem = lbl.GetItemInfo(validISBN, validCopyNumber);
                        Item foundItem = myLibraryService.wsGetItemInfo(validISBN, validCopyNumber);

                        // Build a string for UI messageboard area.
                        StringBuilder myPreCheckOutItem = new StringBuilder("");
                        myPreCheckOutItem.Append(foundItem.Title + " by ");
                        myPreCheckOutItem.Append(foundItem.Author);

                        // Propts user book is available for check-out if desired, or on loan by another member.
                        if (foundItem.membernumber == 0) {
                            
                            DisplayInMessageBoard("Member can check out up to " + bookCheckOutable +
                                " item(s). Would you like to check out: " + myPreCheckOutItem + "?" +
                                " Click Yes or No.");

                            // Makes Yes and No buttons visible.
                            this.buttonNo.Visible = true;
                            this.buttonYes.Visible = true;

                        } else {
                            DisplayInMessageBoard(myPreCheckOutItem + " is on loan by member id " +
                               foundItem.membernumber + ".");
                        }

                    } catch (Exception ex) {
                        DisplayInMessageBoard(ex.Message);
                    }
                }
            }
    }

    /// <summary>
    /// Renews member card.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Event data</param>
    protected void btnRenew_Click(object sender, EventArgs e) {

        // Creates the object that captures data.
        //LibraryBusinessLayer lbl = new LibraryBusinessLayer();

        // Creates instance of proxy object.
        LibraryWR.Service myLibraryService = new LibraryWR.Service();

        try {
            // Create object for current member.
            //LibraryEntities.Member currentMember = new LibraryEntities.Member();
            Member currentMember = new Member();
            
            // Captures current member id
            currentMember.memberid = Convert.ToInt16(this.textboxMemberID.Text);

            // Renew member card expiration date
            //lbl.SetExpiryDate(currentMember.MemberID);
            myLibraryService.wsSetExpiryDate(currentMember.memberid);

            // Refreshes view
            buttonViewMemberInfo_Click(sender, e);

            DisplayInMessageBoard("Card renewed.");

            // Hide renew button once complete.
            this.btnRenew.Visible = false;

        } catch (FormatException fe) {
            
           DisplayInMessageBoard("\n" + fe.Message);

        } catch (ArgumentOutOfRangeException ae) {

            DisplayInMessageBoard("\n" + ae.Message);

        } catch (SoapException se) {

            DisplayInMessageBoard("\n" + se.Message + " " +
                se.InnerException.Message + ".");

        } catch (Exception ex) {

            throw new Exception(ex.Message,ex);
        }

    }

    /// <summary>
    /// No button. Discontinues current procedure.
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Event data</param>
    protected void buttonNo_Click(object sender, EventArgs e) {

        // Hides Yes and No buttons.
        this.buttonNo.Visible = false;
        this.buttonYes.Visible = false;
    }

    /// <summary>
    /// Yes button. 
    /// </summary>
    /// <param name="sender">Event causing object</param>
    /// <param name="e">Event data</param>
    protected void buttonYes_Click(object sender, EventArgs e) {

        // Checks out item.
        buttonCheckOutItem_Click(sender, e);

        // Hides Yes and No buttons.
        this.buttonNo.Visible = false;
        this.buttonYes.Visible = false;

    }
#endregion

        #region MyMethods

        /// <summary>
        /// Changes the View Member form's messageboard label text.
        /// </summary>
        /// <param name="myCaption">String representing text to change.</param>
        public void DisplayInMessageBoard (string myCaption){
            this.labelMemberAlert.Text = "message board:\n " + myCaption;
            // Brightens the text color.
            this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;
        }

        /// <summary>
        /// High grid items that are overdue.
        /// </summary>
        private void HighlightLateItem() {

            // Runs through the rows
            foreach (GridViewRow currRow in viewmemberGridView.Rows)
			{
                // Highlights row if item overdue
                if (Convert.ToDateTime(currRow.Cells[6].Text) < DateTime.Now ) {
                     //viewmemberGridView.RowStyle.BackColor=SystemColors.HotTrack;
                    currRow.BackColor = SystemColors.Highlight;
                }              
			}
            
        }
        #endregion


}             
    

