using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace AppTypes {
    /// <summary>
    /// This class will provide a generic template for creating
    /// strongly-typed collection classes.
    /// </summary>
    [DeveloperInfoAttribute("Temitope Oluwole", Date = "05mar08", Title = "AppTypes.GenericCollection<T> Class")]
    [CustomDescriptionAttribute("This class will provide a generic template for creating" +
     "strongly-typed collection classes.")]
    [Serializable]
    class GenericCollection<T>: IList<T> {

        #region Fields

        /// <summary>
        /// Generic field.
        /// </summary>
        protected List<T> items;

        #endregion

        /// <summary>
        /// Generic constructor.
        /// </summary>
        public GenericCollection() {
            items = new List<T>();
        }

        #region IList<T> Members

        /// <summary>
        /// Determines the index of a specific object in the collection.
        /// </summary>
        /// <param name="item">item</param>
        /// <returns>An instance of <see cref="System.Int32"/></returns>
        public int IndexOf(T item) {
            throw new Exception("The method or operation is not implemented.");
        }

        /// <summary>
        /// Inserts an object into the collection at the specified index.
        /// </summary>
        /// <param name="index">index</param>
        /// <param name="item">item</param>
        public void Insert(int index, T item) {
            throw new Exception("The method or operation is not implemented.");
        }

        /// <summary>
        /// Removes object at specified index.
        /// </summary>
        /// <param name="index">index</param>
        public void RemoveAt(int index) {
            throw new Exception("The method or operation is not implemented.");
        }

        /// <summary>
        /// this property.
        /// </summary>
        /// <param name="index">index</param>
        /// <returns>An instance of T</returns>
        public T this[int index] {
            get {
                throw new NotSupportedException("This property is not supported.");
            }
            set {
                throw new NotSupportedException("This property is not supported.");
            }
        }

        #endregion

        #region ICollection<T> Members

        public void Add(T item) {
            throw new Exception("The method or operation is not implemented.");
        }

        /// <summary>
        /// Removes all objects from the Collection.
        /// </summary>
        public void Clear() {
            items.Clear();
        }

        /// <summary>
        /// Determines whether the collection contains a specific object.
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public bool Contains(T item) {
            throw new Exception("The method or operation is not implemented.");
        }

        public void CopyTo(T[] array, int arrayIndex) {
            throw new Exception("The method or operation is not implemented.");
        }

        /// <summary>
        /// Returns the number of elements currently in the collection.
        /// </summary>
        public int Count {
            get { return items.Count; }
        }

        /// <summary>
        /// IsReadOnly propery.
        /// </summary>
        public bool IsReadOnly {
            get { return false; }
        }

        /// <summary>
        /// Removes items from the collection.
        /// </summary>
        /// <param name="item">item</param>
        /// <returns>An instance of <see cref="System.Boolean"/></returns>
        public bool Remove(T item) {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        #region IEnumerable<T> Members

        /// <summary>
        /// IEnumerator<T> GetEnumerator.
        /// </summary>
        /// <returns>An instance of IEnumerator_T</returns>
        public IEnumerator<T> GetEnumerator() {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        #region IEnumerable Members

        /// <summary>
        /// IEnumerator GetEnumerator.
        /// </summary>
        /// <returns>An instance of <see cref="IEnumerator"/></returns>
        IEnumerator IEnumerable.GetEnumerator() {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
