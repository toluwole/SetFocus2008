using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using TO.LibraryBusiness;
//using SetFocus.Library.Entities;


namespace TO.LibraryWinClient {
    /// <summary>
    /// Class used to build EnrollMemberForm.
    /// </summary>
    public partial class EnrollMemberForm : Form {
        /// <summary>
        /// Initializes form.
        /// </summary>
        public EnrollMemberForm() {
            InitializeComponent();

            try {
                // create a Dataset containing the data from the States.xml file
                DataSet statesDS = StatesData.GetStates();            
                
                // bind the State table in statesDS to the testComboBox
                this.comboboxState.DataSource = statesDS.Tables["State"];

            } catch (FileNotFoundException fne) {

                DisplayInMessageBoard(fne.Message);
            }

            // Displays the states' Abbreviations...
            this.comboboxState.DisplayMember = "Abbreviation";

            // ... and also use the states' Abbreviations as the value member of the ComboBox
            this.comboboxState.ValueMember = "Abbreviation";

           
        }


        #region MyEvents
        /// <summary>
        /// Validation test for First Name
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Data for cancelable event</param>
        private void textboxFirstName_Validating(object sender, CancelEventArgs e) {

            // Makes sure First Name is entered.
            if (this.textboxFirstName.Text == "") {
                e.Cancel = true;
                errorproviderEnrollMember.SetError(textboxFirstName,
                    "This is a required field.");
            } else {
                // Places text of First Name into an array.
                char[] myArrayFirstName = this.textboxFirstName.Text.ToCharArray();

                // Checks if any part of First Name is not alphabetic.
                for (int i = 0; i < myArrayFirstName.Length; i++) {
                    if (!Char.IsLetter(myArrayFirstName[i])) {
                        e.Cancel = true;
                        errorproviderEnrollMember.SetError(textboxFirstName,
                            "First name must be alphabetic, and the first letter upper case.");
                    }
                    // Provides error if first character is not uppercase
                    if (this.textboxFirstName.Text.Substring(0, 1).Equals(
                       this.textboxFirstName.Text.Substring(0, 1).ToLower())) {

                        e.Cancel = true;
                        errorproviderEnrollMember.SetError(textboxFirstName,
                            "First name must be alphabetic, and the first letter upper case.");
                    }
                }
            }
        }



        /// <summary>
        /// Event handler for valid First Name entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxFirstName_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);

        }

        /// <summary>
        /// Validation test for Last Name
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Data for cancelable event</param>
        private void textboxLastName_Validating(object sender, CancelEventArgs e) {

            // Makes sure Last Name is entered.  
            if (this.textboxLastName.Text == "") {
                e.Cancel = true;
                errorproviderEnrollMember.SetError(textboxLastName,
                    "This is a required field.");
            } else {
                
                // Places text of First Name into an array.
                char[] myArrayLastName = this.textboxLastName.Text.ToCharArray();

                // Checks if any part of First Name is not alphabetic.
                for (int i = 0; i < myArrayLastName.Length; i++) {
                    if (!Char.IsLetter(myArrayLastName[i])) {
                        e.Cancel = true;
                        errorproviderEnrollMember.SetError(textboxLastName,
                            "Last name must be alphabetic, and the first letter upper case.");
                    }
                    // Provides error if first character is not uppercase
                    if (this.textboxLastName.Text.Substring(0, 1).Equals(
                       this.textboxLastName.Text.Substring(0, 1).ToLower())) {

                        e.Cancel = true;
                        errorproviderEnrollMember.SetError(textboxLastName,
                            "Last name must be alphabetic, and the first letter upper case.");
                    }
                }
            }
        }

        /// <summary>
        /// Event handler for valid Last Name entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxLastName_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Check that if entered, Middle Initial is one character and upper case.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxMiddleInit_Validating(object sender, CancelEventArgs e) {
            if (this.textboxMiddleInit.Text.Length == 1) {
                try {
                    if (Char.IsLetter(Convert.ToChar(this.textboxMiddleInit.Text)) &&
                        this.textboxMiddleInit.Text.Equals(this.textboxMiddleInit.Text.ToUpper())) {
                    } else {
                        e.Cancel = true;
                        errorproviderEnrollMember.SetError(textboxFirstName,
                            "Middle initial must be alphabetic, and upper case.");
                    }
                } catch (FormatException) {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxFirstName,
                        "Middle initial must be alphabetic");
                }
            }
        }

        /// <summary>
        /// Event handler for valid Middle Initial entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxMiddleInit_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }

        #region Juvenile Name Events - Probably Won't Be Used Any More

        /// <summary>
        /// Validation test for Juvenile First Name
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Data for cancelable event</param>
        private void textboxJuvenileFirstName_Validating(object sender, CancelEventArgs e) {
            // Places text of First Name into an array.
            char[] myArrayFirstName = this.textboxJuvenileFirstName.Text.ToCharArray();

            // Checks if any part of First Name is not alphabetic.
            for (int i = 0; i < myArrayFirstName.Length; i++) {
                if (!Char.IsLetter(myArrayFirstName[i])) {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxJuvenileFirstName,
                        "Juvenile first name must be alphabetic, and the first letter upper case.");
                }
                // Provides error if first character is not uppercase
                if (this.textboxJuvenileFirstName.Text.Substring(0, 1).Equals(
                   this.textboxJuvenileFirstName.Text.Substring(0, 1).ToLower())) {

                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxJuvenileFirstName,
                        "Juvenile first name must be alphabetic, and the first letter upper case.");
                }
            }
        }

        /// <summary>
        /// Event handler for valid Juvenile First Name entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxJuvenileFirstName_Validated(object sender, EventArgs e) {

            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);


        }

        private void textboxJuvenileLastName_Validating(object sender, CancelEventArgs e) {
            // Places text of First Name into an array.
            char[] myArrayLastName = this.textboxJuvenileLastName.Text.ToCharArray();

            // Checks if any part of First Name is not alphabetic.
            for (int i = 0; i < myArrayLastName.Length; i++) {
                if (!Char.IsLetter(myArrayLastName[i])) {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxJuvenileLastName,
                        "Last name must be alphabetic, and the first letter upper case.");
                }
                // Provides error if first character is not uppercase
                if (this.textboxJuvenileLastName.Text.Substring(0, 1).Equals(
                   this.textboxJuvenileLastName.Text.Substring(0, 1).ToLower())) {

                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxJuvenileLastName,
                        "Last name must be alphabetic, and the first letter upper case.");
                }
            }
        }

        /// <summary>
        /// Event handler for valid Juvenile Last Name entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxJuvenileLastName_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Check that if entered, Middle Initial is one character and upper case.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxJuvenileMidInitial_Validating(object sender, CancelEventArgs e) {
            if (this.textboxJuvenileMidInitial.Text.Length == 1) {
                try {
                    if (Char.IsLetter(Convert.ToChar(this.textboxJuvenileMidInitial.Text)) &&
                        this.textboxJuvenileMidInitial.Text.Equals(this.textboxJuvenileMidInitial.Text.ToUpper())) {
                    } else {
                        e.Cancel = true;
                        errorproviderEnrollMember.SetError(textboxJuvenileFirstName,
                            "Middle initial must be alphabetic, and upper case.");
                    }
                } catch (FormatException) {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxJuvenileFirstName,
                        "Middle initial must be alphabetic");
                }
            }
        }

        /// <summary>
        /// Event handler for valid Juvenile Middle Initial entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxJuvenileMidInitial_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }
        
        #endregion

        /// <summary>
        /// Checks that if entered, Telephone is in (###)###-#### format.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxPhone_Validating(object sender, CancelEventArgs e) {

            // Checks is anything is entered into the field.
            if (this.textboxPhone.Text.Length >= 1) {
                try {
                    // Checks the text formatting.
                    if ((this.textboxPhone.Text.Substring(0, 1) == "(") &&
                        (this.textboxPhone.Text.Substring(4, 1) == ")") &&
                        (this.textboxPhone.Text.Substring(8, 1) == "-")) {
                        try {
                            Convert.ToInt16(this.textboxPhone.Text.Substring(1, 3));
                            Convert.ToInt16(this.textboxPhone.Text.Substring(5, 3));
                            Convert.ToInt16(this.textboxPhone.Text.Substring(9, 4));
                        } catch (FormatException) {
                            e.Cancel = true;
                            errorproviderEnrollMember.SetError(textboxPhone,
                                "Phone number must be in (###)###-#### format, where # is a digit from " +
                                "0 through 9");
                        } catch (ArgumentOutOfRangeException) {
                            e.Cancel = true;
                            errorproviderEnrollMember.SetError(textboxPhone,
                                "Phone number must be in (###)###-#### format, where # is a digit from " +
                                "0 through 9");
                        }
                    } else {
                        e.Cancel = true;
                        errorproviderEnrollMember.SetError(textboxPhone,
                            "Phone number must be in (###)###-#### format, where # is a digit from " +
                            "0 through 9");
                    }
                } catch (ArgumentOutOfRangeException) {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxPhone,
                        "Phone number must be in (###)###-#### format, where # is a digit from " +
                        "0 through 9");
                }

            }
        }

        /// <summary>
        /// Event handler for valid Phone Number entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxPhone_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Checks that, Zip Code is in ##### or #####-#### format.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxZipCode_Validating(object sender, CancelEventArgs e) {

            // Validates only if Adult member is being added.
            if (checkboxJuvenileMember.Checked != true) {
            try {
                    // Checks the text formatting
                    Convert.ToInt32(this.textboxZipCode.Text.Substring(0, 5));
                    if ((this.textboxZipCode.Text.Substring(0, 5)) == (this.textboxZipCode.Text.Trim())) {
                    } else if (this.textboxZipCode.Text.Substring(5, 1) == "-") {
                        Convert.ToInt16(this.textboxZipCode.Text.Substring(6, 4));
                    }
                } catch (FormatException) {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxZipCode,
                        "Zip Code must be in ##### or #####-#### format, where # is a digit from " +
                        "0 through 9");
                } catch (ArgumentOutOfRangeException) {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxZipCode,
                        "Zip Code must be in ##### or #####-#### format, where # is a digit from " +
                        "0 through 9");
                }
            }
                    
        }

        /// <summary>
        /// Event handler for valid Zip Code entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxZipCode_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Checks that, Juvenile Date of Birth is in MM/DD/YYYY format,
        /// and no more than eighteen years prior to the current date.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxDateOfBirth_Validating(object sender, CancelEventArgs e) {

            // Validates only if Juvenile member is being added.
            if (this.checkboxJuvenileMember.Checked == true) {
                try {
                    // Check that date entered is in the correct format.
                    DateTime myJuvenileDOB = Convert.ToDateTime(this.textboxDateOfBirth.Text);

                    // Checks that date length reflects MM/DD/YYYY versus other (e.g. M/D/YY)
                    if (this.textboxDateOfBirth.Text.Length == 10) {
                        // Checks that date entered no more than eighteen years
                        // prior to the current date.
                        if (myJuvenileDOB.AddYears(18) > DateTime.Today) {
                        } else {
                            e.Cancel = true;
                            errorproviderEnrollMember.SetError(textboxDateOfBirth,
                                "Member is over 18 years of age, and cannot be a juvenile member");
                        }
                    } else {
                        e.Cancel = true;
                        errorproviderEnrollMember.SetError(textboxDateOfBirth,
                            "Date must be in in MM/DD/YYYY format");
                    }

                } catch (FormatException) {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxDateOfBirth,
                        "Date must be in in MM/DD/YYYY format");

                } catch (InvalidCastException) {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxDateOfBirth,
                        "Date must be in in MM/DD/YYYY format");
                }
            } else {
                e.Cancel = true;
                errorproviderEnrollMember.SetError(textboxDateOfBirth,
                    "Date must be in in MM/DD/YYYY format");
            }
        }

        /// <summary>
        /// Event handler for valid Juvenile Member Date of Birth entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxDateOfBirth_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Event for when Enroll Member button is clicked.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void buttonEnrollMember_Click(object sender, EventArgs e) {

            // Validates all controls on the View Member form
            if (!this.ValidateChildren(ValidationConstraints.Visible)) {

                // Keeps View Member form open if controls do not validate.
                this.DialogResult = DialogResult.None;



            } else {
                try {
                    // Creates the object that provides data.
                    LibraryBusinessLayer lbl = new LibraryBusinessLayer();

                    if (checkboxJuvenileMember.Checked == true) {

                        // Casts text of MemberID to short
                        short validAdultMemberID = Convert.ToInt16(this.textboxMemberID.Text);

                        DateTime validDateOfBirth = Convert.ToDateTime(this.textboxDateOfBirth.Text);

                        // Adds Juvenile Member.
                        TO.LibraryEntities.LibraryEntities.JuvenileMember enrolledJuvenile = lbl.AddJuvenileMember(
                            validAdultMemberID,
                            this.textboxFirstName.Text,
                            this.textboxLastName.Text,
                            this.textboxMiddleInit.Text,
                            validDateOfBirth);

                        // Displays added member's Member ID.
                        DisplayInMessageBoard(this.textboxFirstName.Text +
                            " " + this.textboxLastName.Text + "'s Member ID is " +
                            enrolledJuvenile.MemberID);

                    } else {

                        // Adds Adult Member.
                        TO.LibraryEntities.LibraryEntities.AdultMember enrolledAdult = lbl.AddAdultMember(
                            this.textboxFirstName.Text,
                            this.textboxLastName.Text,
                            this.textboxMiddleInit.Text,
                            this.textboxStreet.Text,
                            this.textboxCity.Text,
                            this.comboboxState.Text,
                            this.textboxZipCode.Text,
                            this.textboxPhone.Text);

                        // Displays added member's Member ID.
                        DisplayInMessageBoard(this.textboxFirstName.Text +
                            " " + this.textboxLastName.Text + "'s Member ID is " +
                            enrolledAdult.MemberID);
                    }
                    

                } catch (FormatException fe) {

                    DisplayInMessageBoard("\n" + fe.Message);

                } catch (ArgumentOutOfRangeException ae) {

                    DisplayInMessageBoard("\n" + ae.Message);

                } catch (LibraryException le) {

                   DisplayInMessageBoard("\n" + le.Message + " " + 
                       le.LibraryErrorCode.ToString() + ".");

               } catch (Exception ex) {

                   DisplayInMessageBoard("\n" + ex.Message);
               }
            }
        }

        /// <summary>
        /// Checks that Adult Member ID is entered for a Juvenile Member.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxMemberID_Validating(object sender, CancelEventArgs e) {

            if (checkboxJuvenileMember.Checked==true) {
                if (this.textboxMemberID.Text == "") {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxMemberID,
                        "This is a required field.");
                } else {
                    try {
                        // Casts text of MemberID to short
                        short validMemberID = Convert.ToInt16(this.textboxMemberID.Text);
                    } catch (FormatException) {
                        e.Cancel = true;
                        errorproviderEnrollMember.SetError(textboxMemberID,
                            "Member ID must be a number from 1 to 32767.");
                    } catch (LibraryException le) {

                        DisplayInMessageBoard("\n" + le.Message + " " +
                            le.LibraryErrorCode.ToString() + ".");
                    } catch (Exception ex) {

                        DisplayInMessageBoard("\n" + ex.Message);
                    }
                }
            }
        }

        /// <summary>
        /// Event handler for valid Member ID entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxMemberID_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Validation test for City entry
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Data for cancelable event</param>
        private void textboxCity_Validating(object sender, CancelEventArgs e) {
            
            // Makes sure City is entered for Adult member. 
            if (checkboxJuvenileMember.Checked != true) {
                if (this.textboxCity.Text == "") {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxCity,
                        "This is a required field.");
                } else {

                    // Places text of City into an array.
                    char[] myArrayCity = this.textboxCity.Text.ToCharArray();

                    // Checks if any part of City is not alphabetic.
                    for (int i = 0; i < myArrayCity.Length; i++) {
                        if (!Char.IsLetter(myArrayCity[i])) {
                            e.Cancel = true;
                            errorproviderEnrollMember.SetError(textboxCity,
                                "City must be alphabetic, and the first letter upper case.");
                        }
                        // Provides error if first character is not uppercase
                        if (this.textboxCity.Text.Substring(0, 1).Equals(
                           this.textboxCity.Text.Substring(0, 1).ToLower())) {

                            e.Cancel = true;
                            errorproviderEnrollMember.SetError(textboxCity,
                                "City must be alphabetic, and the first letter upper case.");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Event handler for valid City entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxCity_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Validation test for Street entry
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Data for cancelable event</param>
        private void textboxStreet_Validating(object sender, CancelEventArgs e) {
            // Makes sure Street is entered for Adult member. 
            if (checkboxJuvenileMember.Checked != true) {
                if (this.textboxStreet.Text == "") {
                    e.Cancel = true;
                    errorproviderEnrollMember.SetError(textboxStreet,
                        "This is a required field.");
                } //else {

                //    // Places text of Street into an array.
                //    char[] myArrayStreet = this.textboxStreet.Text.ToCharArray();

                //    // Checks if any part of Street is not alphabetic.
                //    for (int i = 0; i < myArrayStreet.Length; i++) {
                //        if (!Char.IsLetter(myArrayStreet[i])) {
                //            e.Cancel = true;
                //            errorproviderEnrollMember.SetError(textboxStreet,
                //                "Street must be alphabetic, and the first letter upper case.");
                //        }
                //        // Provides error if first character is not uppercase
                //        if (this.textboxStreet.Text.Substring(0, 1).Equals(
                //           this.textboxStreet.Text.Substring(0, 1).ToLower())) {

                //            e.Cancel = true;
                //            errorproviderEnrollMember.SetError(textboxStreet,
                //                "Street must be alphabetic, and the first letter upper case.");
                //        }
                //    }
                //}
            }
        }

        /// <summary>
        /// Event handler for valid Street entry.
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void textboxStreet_Validated(object sender, EventArgs e) {
            // clear out errors on a given control
            errorproviderEnrollMember.SetError((Control)sender, string.Empty);
        }

        /// <summary>
        /// Event handler for the Juvenile member checkbox
        /// </summary>
        /// <param name="sender">Event causing object</param>
        /// <param name="e">Object info.</param>
        private void checkboxJuvenileMember_CheckedChanged(object sender, EventArgs e) {

            // Determines state of check box.
            if (checkboxJuvenileMember.CheckState==CheckState.Checked) {

                // Hides non-required and non-option fields.
                textboxExpiryDate.Visible = false;
                labelExpiryDate.Visible = false;
                textboxStreet.Visible = false;
                labelStreet.Visible = false;
                textboxCity.Visible = false;
                labelCity.Visible = false;
                comboboxState.Visible = false;
                labelState.Visible = false;
                textboxZipCode.Visible = false;
                labelZipCode.Visible = false;
                textboxPhone.Visible = false;
                labelPhone.Visible = false;

                // Shows required and optional fields.
                textboxMemberID.Visible = true;
                labelMemberID.Visible = true;
                groupboxJuvenile.Visible = true;
                textboxDateOfBirth.Visible = true;
                labelDateOfBirth.Visible = true;

            } else {

                // Hides non-required and non-option fields.
                textboxMemberID.Visible = false;
                labelMemberID.Visible = false;
                groupboxJuvenile.Visible = false;
                textboxDateOfBirth.Visible = false;
                labelDateOfBirth.Visible = false;

                // Shows required and optional fields.
                textboxExpiryDate.Visible = true;
                labelExpiryDate.Visible = true;
                textboxStreet.Visible = true;
                labelStreet.Visible = true;
                textboxCity.Visible = true;
                labelCity.Visible = true;
                comboboxState.Visible = true;
                labelState.Visible = true;
                textboxZipCode.Visible = true;
                labelZipCode.Visible = true;
                textboxPhone.Visible = true;
                labelPhone.Visible = true;

            }
        }


        #endregion

        #region MyMethods

        /// <summary>
        /// Changes the View Member form's messageboard label text.
        /// </summary>
        /// <param name="myCaption">String representing text to change.</param>
        private void DisplayInMessageBoard(string myCaption) {
            this.labelMemberAlert.Text = "message board:\n " + myCaption;
            // Brightens the text color.
            this.labelMemberAlert.ForeColor = SystemColors.ActiveCaption;
        }


        #endregion



    }
}