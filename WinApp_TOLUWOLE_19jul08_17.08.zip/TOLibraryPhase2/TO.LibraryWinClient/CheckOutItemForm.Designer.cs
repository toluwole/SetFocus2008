namespace TO.LibraryWinClient {
    partial class CheckOutItemForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.buttonAddToMemberCart = new System.Windows.Forms.Button();
            this.textboxISBN1 = new System.Windows.Forms.TextBox();
            this.labelISBN = new System.Windows.Forms.Label();
            this.textboxCopyNumber1 = new System.Windows.Forms.TextBox();
            this.textboxCopyNumber2 = new System.Windows.Forms.TextBox();
            this.textboxISBN2 = new System.Windows.Forms.TextBox();
            this.textboxCopyNumber3 = new System.Windows.Forms.TextBox();
            this.textboxISBN3 = new System.Windows.Forms.TextBox();
            this.textboxCopyNumber4 = new System.Windows.Forms.TextBox();
            this.textboxISBN4 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonAddToMemberCart
            // 
            this.buttonAddToMemberCart.Location = new System.Drawing.Point(22, 142);
            this.buttonAddToMemberCart.Name = "buttonAddToMemberCart";
            this.buttonAddToMemberCart.Size = new System.Drawing.Size(189, 23);
            this.buttonAddToMemberCart.TabIndex = 9;
            this.buttonAddToMemberCart.Text = "Add To Member Cart";
            this.buttonAddToMemberCart.UseVisualStyleBackColor = true;
            // 
            // textboxISBN1
            // 
            this.textboxISBN1.Location = new System.Drawing.Point(22, 38);
            this.textboxISBN1.Name = "textboxISBN1";
            this.textboxISBN1.Size = new System.Drawing.Size(118, 20);
            this.textboxISBN1.TabIndex = 1;
            // 
            // labelISBN
            // 
            this.labelISBN.AutoSize = true;
            this.labelISBN.Location = new System.Drawing.Point(19, 22);
            this.labelISBN.Name = "labelISBN";
            this.labelISBN.Size = new System.Drawing.Size(200, 13);
            this.labelISBN.TabIndex = 0;
            this.labelISBN.Text = "Enter Up To 4 ISBNs and Copy Numbers";
            // 
            // textboxCopyNumber1
            // 
            this.textboxCopyNumber1.Location = new System.Drawing.Point(147, 38);
            this.textboxCopyNumber1.Name = "textboxCopyNumber1";
            this.textboxCopyNumber1.Size = new System.Drawing.Size(64, 20);
            this.textboxCopyNumber1.TabIndex = 2;
            // 
            // textboxCopyNumber2
            // 
            this.textboxCopyNumber2.Location = new System.Drawing.Point(147, 64);
            this.textboxCopyNumber2.Name = "textboxCopyNumber2";
            this.textboxCopyNumber2.Size = new System.Drawing.Size(64, 20);
            this.textboxCopyNumber2.TabIndex = 4;
            // 
            // textboxISBN2
            // 
            this.textboxISBN2.Location = new System.Drawing.Point(22, 64);
            this.textboxISBN2.Name = "textboxISBN2";
            this.textboxISBN2.Size = new System.Drawing.Size(118, 20);
            this.textboxISBN2.TabIndex = 3;
            // 
            // textboxCopyNumber3
            // 
            this.textboxCopyNumber3.Location = new System.Drawing.Point(147, 90);
            this.textboxCopyNumber3.Name = "textboxCopyNumber3";
            this.textboxCopyNumber3.Size = new System.Drawing.Size(64, 20);
            this.textboxCopyNumber3.TabIndex = 6;
            // 
            // textboxISBN3
            // 
            this.textboxISBN3.Location = new System.Drawing.Point(22, 90);
            this.textboxISBN3.Name = "textboxISBN3";
            this.textboxISBN3.Size = new System.Drawing.Size(118, 20);
            this.textboxISBN3.TabIndex = 5;
            // 
            // textboxCopyNumber4
            // 
            this.textboxCopyNumber4.Location = new System.Drawing.Point(147, 116);
            this.textboxCopyNumber4.Name = "textboxCopyNumber4";
            this.textboxCopyNumber4.Size = new System.Drawing.Size(64, 20);
            this.textboxCopyNumber4.TabIndex = 8;
            // 
            // textboxISBN4
            // 
            this.textboxISBN4.Location = new System.Drawing.Point(22, 116);
            this.textboxISBN4.Name = "textboxISBN4";
            this.textboxISBN4.Size = new System.Drawing.Size(118, 20);
            this.textboxISBN4.TabIndex = 7;
            // 
            // formMemberCheckOut
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(240, 198);
            this.Controls.Add(this.textboxCopyNumber4);
            this.Controls.Add(this.textboxISBN4);
            this.Controls.Add(this.textboxCopyNumber3);
            this.Controls.Add(this.textboxISBN3);
            this.Controls.Add(this.textboxCopyNumber2);
            this.Controls.Add(this.textboxISBN2);
            this.Controls.Add(this.textboxCopyNumber1);
            this.Controls.Add(this.labelISBN);
            this.Controls.Add(this.textboxISBN1);
            this.Controls.Add(this.buttonAddToMemberCart);
            this.Name = "formMemberCheckOut";
            this.Text = "Check Out Item";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAddToMemberCart;
        private System.Windows.Forms.TextBox textboxISBN1;
        private System.Windows.Forms.Label labelISBN;
        private System.Windows.Forms.TextBox textboxCopyNumber1;
        private System.Windows.Forms.TextBox textboxCopyNumber2;
        private System.Windows.Forms.TextBox textboxISBN2;
        private System.Windows.Forms.TextBox textboxCopyNumber3;
        private System.Windows.Forms.TextBox textboxISBN3;
        private System.Windows.Forms.TextBox textboxCopyNumber4;
        private System.Windows.Forms.TextBox textboxISBN4;
    }
}