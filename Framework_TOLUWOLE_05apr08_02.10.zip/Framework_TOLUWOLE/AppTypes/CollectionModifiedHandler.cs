using System;
using System.Collections.Generic;
using System.Text;

namespace AppTypes {
    /// <summary>
    /// A delegate used to define the event type to be raised
    /// anytime the collection is modified.
    /// </summary>
    /// <param name="sender">An object reference indicating the class raising the exception</param>
    /// <param name="args">An instance of ModificationEventArgs</param>
    delegate void CollectionModifiedHandler(object sender, ModificationEventArgs args);

}
