using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TO.LibraryWinClient {
    /// <summary>
    /// Class used to build Member Check Out form.
    /// </summary>
    public partial class CheckOutItemForm : Form {
        
        /// <summary>
        /// Constructor to build form.
        /// </summary>
        public CheckOutItemForm() {
            InitializeComponent();
        }
    }
}